const zs = {
  // For PrimeVue version 3
  accordiontab: {
    root: {
      class: ["mb-0", "border-b border-surface-200 dark:border-surface-700"]
    },
    header: ({ props: e }) => ({
      class: [
        // State
        { "select-none pointer-events-none cursor-default opacity-60": e == null ? void 0 : e.disabled }
      ]
    }),
    headerAction: {
      class: [
        //Font
        "font-semibold",
        "leading-none",
        // Alignments
        "flex justify-between items-center",
        "flex-row-reverse",
        "relative",
        // Sizing
        "p-[1.125rem]",
        // Shape
        "rounded-md",
        "border-0",
        // Color
        "bg-surface-0 dark:bg-surface-900",
        "text-surface-600 dark:text-surface-0/80",
        // Transition
        "transition duration-200 ease-in-out",
        "transition-shadow duration-200",
        // States
        "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
        // Focus
        // Misc
        "cursor-pointer no-underline select-none"
      ]
    },
    headerIcon: ({ context: e }) => ({
      class: ["inline-block ml-2", { "text-surface-900 dark:text-surface-0": e.active }]
    }),
    headerTitle: {
      class: "leading-none"
    },
    content: {
      class: [
        // Spacing
        "p-[1.125rem] pt-0",
        //Shape
        "border-0 rounded-none",
        // Color
        "bg-surface-0 dark:bg-surface-900",
        "text-surface-600 dark:text-surface-0/70"
      ]
    },
    transition: {
      enterFromClass: "max-h-0",
      enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
      enterToClass: "max-h-[1000px]",
      leaveFromClass: "max-h-[1000px]",
      leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
      leaveToClass: "max-h-0"
    }
  }
}, Ls = {
  content: "p-5 pt-0 bg-surface-0 dark:bg-surface-900 text-surface-600 dark:text-surface-0/70"
}, Es = {
  root: ({ context: e }) => ({
    class: [
      "flex items-center justify-between bg-surface-0 dark:bg-surface-900 text-surface-600 dark:text-surface-0/70 p-[1.125rem] font-semibold outline-transparent",
      {
        "focus-visible:outline-offset-2 focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400": !e.disabled
      },
      {
        "hover:text-surface-700 dark:hover:text-surface-0": !e.disabled
      }
    ]
  }),
  toggleIcon: "inline-block text-surface-900 dark:text-surface-0 w-4 h-4"
}, Ns = {
  root: ({ props: e, context: t }) => ({
    class: [
      "flex flex-col border-b border-surface-200 dark:border-surface-700",
      {
        "[&>[data-pc-name=accordionheader]]:select-none [&>[data-pc-name=accordionheader]]:pointer-events-none [&>[data-pc-name=accordionheader]]:cursor-default [&>[data-pc-name=accordionheader]]:opacity-60": e == null ? void 0 : e.disabled,
        "[&>[data-pc-name=accordionheader]]:text-surface-700 dark:[&>[data-pc-name=accordionheader]]:text-surface-100 hover:[&>[data-pc-name=accordionheader]]:text-surface-800 dark:hover:[&>[data-pc-name=accordionheader]]:text-surface-0": !e.disabled && t.active,
        "[&>[data-pc-section=toggleicon]]:text-surface-700 dark:[&>[data-pc-section=toggleicon]]:text-surface-100 hover:[&>[data-pc-section=toggleicon]]:text-surface-800 dark:hover:[&>[data-pc-section=toggleicon]]:text-surface-0": !e.disabled && t.active,
        "[&:last-child>[data-pc-name=accordioncontent]>[data-pc-section=content]]:rounded-b-md": !e.disabled && t.active,
        "[&:last-child>[data-pc-name=accordionheader]]:rounded-b-md": !e.disabled && !t.active
      },
      "[&:nth-child(n+2)>[data-pc-name=accordionheader]]:border-t-0",
      "[&:first-child>[data-pc-name=accordionheader]]:rounded-t-md"
    ]
  })
}, Rs = {
  root: ({ props: e }) => ({
    class: [
      "relative",
      // Flex
      {
        flex: e.fluid,
        "inline-flex": !e.fluid
      },
      // Size
      { "w-full": e.multiple },
      { "[&>input]:!rounded-r-none": e.dropdown },
      // Color
      "text-surface-900 dark:text-surface-0",
      //States
      {
        "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled
      }
    ]
  }),
  inputMultiple: ({ props: e, state: t }) => ({
    class: [
      // Font
      "leading-none",
      // Flex
      "flex items-center flex-wrap",
      "gap-2",
      // Spacing
      "m-0 list-none",
      "py-1 px-1",
      // Size
      "w-full",
      // Shape
      "appearance-none rounded-md",
      // Color
      "text-surface-700 dark:text-white/80",
      "placeholder:text-surface-400 dark:placeholder:text-surface-500",
      { "bg-surface-0 dark:bg-surface-950": !e.disabled },
      "border",
      { "border-surface-300 dark:border-surface-700": !e.invalid },
      // Invalid State
      "invalid:focus:ring-red-200",
      "invalid:hover:border-red-500",
      { "border-red-500 dark:border-red-400": e.invalid },
      // States
      { "hover:border-surface-400 dark:hover:border-surface-700": !e.invalid },
      { "outline-none outline-offset-0 z-10 ring-1 ring-primary-500 dark:ring-primary-400": t.focused },
      // Transition
      "transition duration-200 ease-in-out",
      // Misc
      "cursor-text overflow-hidden"
    ]
  }),
  inputToken: {
    class: ["py-1 px-0 ml-2", "inline-flex flex-auto"]
  },
  inputChip: {
    class: "flex-auto inline-flex pt-1 pb-1"
  },
  input: {
    class: "border-none outline-none bg-transparent m-0 p-0 shadow-none rounded-none w-full"
  },
  dropdown: {
    class: [
      "relative",
      // Alignments
      "items-center inline-flex justify-center text-center align-bottom",
      // Shape
      "rounded-r-md",
      // Size
      "py-2 leading-none",
      "w-10",
      // Colors
      "text-primary-contrast",
      "bg-primary",
      "border border-primary",
      // States
      "focus:outline-none focus:outline-offset-0 focus:ring-1 ",
      "hover:bg-primary-emphasis hover:border-primary-emphasis",
      "focus:ring-primary-500 dark:focus:ring-primary-400"
    ]
  },
  loader: {
    class: ["text-surface-500 dark:text-surface-0/70", "absolute top-[50%] right-[0.5rem] -mt-2 animate-spin"]
  },
  overlay: {
    class: [
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      // Shape
      "border border-surface-300 dark:border-surface-700",
      "rounded-md",
      "shadow-md",
      // Size
      "overflow-auto"
    ]
  },
  list: {
    class: "p-1 list-none m-0"
  },
  option: ({ context: e }) => ({
    class: [
      "relative",
      // Font
      "leading-none",
      // Spacing
      "m-0 px-3 py-2",
      "first:mt-0 mt-[2px]",
      // Shape
      "border-0 rounded",
      // Colors
      {
        "bg-surface-200 dark:bg-surface-600/60": e.focused && !e.selected,
        "text-surface-700 dark:text-white/80": e.focused && !e.selected,
        "bg-highlight": e.selected
      },
      //States
      { "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.focused && !e.selected },
      { "hover:bg-highlight-emphasis": e.selected },
      { "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": e.focused && !e.selected },
      // Transition
      "transition-shadow duration-200",
      // Misc
      "cursor-pointer overflow-hidden whitespace-nowrap"
    ]
  }),
  optionGroup: {
    class: [
      "font-semibold",
      // Spacing
      "m-0 py-2 px-3",
      // Colors
      "text-surface-400 dark:text-surface-500",
      // Misc
      "cursor-auto"
    ]
  },
  emptyMessage: {
    class: [
      // Font
      "leading-none",
      // Spacing
      "py-2 px-3",
      // Color
      "text-surface-800 dark:text-white/80",
      "bg-transparent"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Fs = {
  root: ({ props: e, parent: t }) => {
    var r, n, o;
    return {
      class: [
        // Font
        {
          "text-xl": e.size == "large",
          "text-2xl": e.size == "xlarge"
        },
        // Alignments
        "inline-flex items-center justify-center",
        "relative",
        // Sizes
        {
          "h-8 w-8": e.size == null || e.size == "normal",
          "w-12 h-12": e.size == "large",
          "w-16 h-16": e.size == "xlarge"
        },
        { "-ml-4": ((r = t.instance.$style) == null ? void 0 : r.name) == "avatargroup" },
        // Shapes
        {
          "rounded-lg": e.shape == "square",
          "rounded-full": e.shape == "circle"
        },
        { "border-2": ((n = t.instance.$style) == null ? void 0 : n.name) == "avatargroup" },
        // Colors
        "bg-surface-300 dark:bg-surface-700",
        { "border-white dark:border-surface-800": ((o = t.instance.$style) == null ? void 0 : o.name) == "avatargroup" }
      ]
    };
  },
  image: ({ props: e }) => ({
    class: [
      "h-full w-full",
      {
        "rounded-lg": e.shape == "square",
        "rounded-full": e.shape == "circle"
      }
    ]
  })
}, Vs = {
  root: {
    class: "flex items-center"
  }
}, Ms = {
  root: ({ props: e }) => {
    var t, r;
    return {
      class: [
        // Font
        "font-bold",
        {
          "text-xs leading-[1.5rem]": e.size === null,
          "text-[0.625rem] leading-[1.25rem]": e.size === "small",
          "text-lg leading-[2.25rem]": e.size === "large",
          "text-2xl leading-[3rem]": e.size === "xlarge"
        },
        // Alignment
        "text-center inline-block",
        // Size
        "p-0 px-1",
        {
          "w-2 h-2": e.value === null,
          "min-w-[1.5rem] h-[1.5rem]": e.value !== null && e.size === null,
          "min-w-[1.25rem] h-[1.25rem]": e.size === "small",
          "min-w-[2.25rem] h-[2.25rem]": e.size === "large",
          "min-w-[3rem] h-[3rem]": e.size === "xlarge"
        },
        // Shape
        {
          "rounded-full": ((t = e.value) == null ? void 0 : t.length) === 1,
          "rounded-[0.71rem]": ((r = e.value) == null ? void 0 : r.length) !== 1
        },
        // Color
        "text-primary-contrast",
        {
          "bg-primary": e.severity == null || e.severity === "primary",
          "bg-surface-500 dark:bg-surface-400": e.severity === "secondary",
          "bg-green-500 dark:bg-green-400": e.severity === "success",
          "bg-blue-500 dark:bg-blue-400": e.severity === "info",
          "bg-orange-500 dark:bg-orange-400": e.severity === "warn",
          "bg-purple-500 dark:bg-purple-400": e.severity === "help",
          "bg-red-500 dark:bg-red-400": e.severity === "danger",
          "text-surface-0 dark:text-surface-900 bg-surface-900 dark:bg-surface-0": e.severity === "contrast"
        }
      ]
    };
  }
}, Bs = {
  root: ({ context: e }) => ({
    class: [
      // Font
      "font-bold",
      "text-xs leading-5",
      // Alignment
      "flex items-center justify-center",
      "text-center",
      // Position
      "absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 origin-top-right",
      // Size
      "m-0",
      {
        "p-0": e.nogutter || e.dot,
        "px-2": !e.nogutter && !e.dot,
        "min-w-[0.5rem] w-2 h-2": e.dot,
        "min-w-[1.5rem] h-6": !e.dot
      },
      // Shape
      {
        "rounded-full": e.nogutter || e.dot,
        "rounded-[10px]": !e.nogutter && !e.dot
      },
      // Color
      "text-primary-contrast",
      {
        "bg-primary": !e.info && !e.success && !e.warning && !e.danger && !e.help && !e.secondary,
        "bg-surface-500 dark:bg-surface-400": e.secondary,
        "bg-green-500 dark:bg-green-400": e.success,
        "bg-blue-500 dark:bg-blue-400": e.info,
        "bg-orange-500 dark:bg-orange-400": e.warning,
        "bg-purple-500 dark:bg-purple-400": e.help,
        "bg-red-500 dark:bg-red-400": e.danger
      }
    ]
  })
}, Ds = {
  root: "relative",
  mask: "bg-black/40 rounded-md"
}, Hs = {
  root: {
    class: [
      // Shape
      "rounded-md",
      // Spacing
      "p-4",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      // Misc
      "overflow-x-auto"
    ]
  },
  list: {
    class: [
      // Flex & Alignment
      "flex items-center flex-nowrap",
      // Spacing
      "m-0 p-0 list-none leading-none"
    ]
  },
  itemLink: {
    class: [
      // Flex & Alignment
      "flex items-center gap-2",
      // Shape
      "rounded-md",
      // Color
      "text-surface-600 dark:text-white/70",
      // States
      "focus-visible:outline-none focus-visible:outline-offset-0",
      "focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
      // Transitions
      "transition-shadow duration-200",
      // Misc
      "text-decoration-none"
    ]
  },
  itemIcon: {
    class: "text-surface-600 dark:text-white/70"
  },
  separator: {
    class: [
      // Flex & Alignment
      "flex items-center",
      // Spacing
      "mx-2",
      // Color
      "text-surface-600 dark:text-white/70"
    ]
  }
}, Us = {
  root: ({ props: e, context: t, parent: r, instance: n }) => ({
    class: [
      "relative",
      // Fluid
      { "w-full": e.fluid },
      // Alignments
      "items-center inline-flex text-center align-bottom justify-center",
      { "flex-col": (e.iconPos === "top" || e.iconPos === "bottom") && e.label },
      // Sizes & Spacing
      "leading-[normal]",
      {
        "px-3 py-2": e.size === null,
        "text-sm py-1.5 px-3": e.size === "small",
        "text-xl py-3 px-4": e.size === "large"
      },
      { "gap-2": e.label !== null },
      {
        "w-10 px-0 py-2": e.label == null && e.icon !== null
      },
      {
        "w-10 px-0 gap-0": n.hasIcon && !e.label && !e.badge,
        "rounded-[50%] h-10 [&>[data-pc-section=label]]:w-0 [&>[data-pc-section=label]]:invisible": n.hasIcon && !e.label && !e.badge && e.rounded
      },
      // Shapes
      { "shadow-lg": e.raised },
      { "rounded-md": !e.rounded, "rounded-full": e.rounded },
      { "rounded-none first:rounded-l-md last:rounded-r-md": r.instance.$name == "InputGroup" },
      // Link Button
      { "text-primary-600 bg-transparent border-transparent": e.link },
      // Plain Button
      { "text-white bg-gray-500 border border-gray-500": e.plain && !e.outlined && !e.text },
      // Plain Text Button
      { "text-surface-500": e.plain && e.text },
      // Plain Outlined Button
      { "text-surface-500 border border-gray-500": e.plain && e.outlined },
      // Text Button
      { "bg-transparent border-transparent": e.text && !e.plain },
      // Outlined Button
      { "bg-transparent border": e.outlined && !e.plain },
      // --- Severity Buttons ---
      // Primary Button
      {
        "text-surface-0": !e.link && e.severity === null && !e.text && !e.outlined && !e.plain,
        "bg-primary-700": !e.link && e.severity === null && !e.text && !e.outlined && !e.plain,
        "border border-primary-700": !e.link && e.severity === null && !e.text && !e.outlined && !e.plain
      },
      // Primary Text Button
      { "text-primary-600": e.text && e.severity === null && !e.plain },
      // Primary Outlined Button
      { "text-primary-700 border border-primary-700": e.outlined && e.severity === null && !e.plain },
      // Secondary Button
      {
        "text-surface-900 dark:text-white": e.severity === "secondary" && !e.text && !e.outlined && !e.plain,
        "bg-surface-100 dark:bg-surface-700": e.severity === "secondary" && !e.text && !e.outlined && !e.plain,
        "border border-surface-100 dark:border-surface-700": e.severity === "secondary" && !e.text && !e.outlined && !e.plain
      },
      // Secondary Text Button
      { "text-surface-500 dark:text-surface-300": e.text && e.severity === "secondary" && !e.plain },
      // Secondary Outlined Button
      { "text-surface-500 dark:text-surface-300 border border-surface-500 hover:bg-surface-300/10": e.outlined && e.severity === "secondary" && !e.plain },
      // Success Button
      {
        "text-white dark:text-success-900": e.severity === "success" && !e.text && !e.outlined && !e.plain,
        "bg-success-500 dark:bg-success-400": e.severity === "success" && !e.text && !e.outlined && !e.plain,
        "border border-success-500 dark:border-success-400": e.severity === "success" && !e.text && !e.outlined && !e.plain
      },
      // Success Text Button
      { "text-success-500 dark:text-success-400": e.text && e.severity === "success" && !e.plain },
      // Success Outlined Button
      { "text-success-500 border border-success-500 hover:bg-success-300/10": e.outlined && e.severity === "success" && !e.plain },
      // Info Button
      {
        "text-white dark:text-surface-900": e.severity === "info" && !e.text && !e.outlined && !e.plain,
        "bg-blue-500 dark:bg-info-400": e.severity === "info" && !e.text && !e.outlined && !e.plain,
        "border border-blue-500 dark:border-info-400": e.severity === "info" && !e.text && !e.outlined && !e.plain
      },
      // Info Text Button
      { "text-info-400 dark:text-info-400": e.text && e.severity === "info" && !e.plain },
      // Info Outlined Button
      { "text-info-400 border border-info-400 hover:bg-info-300/10 ": e.outlined && e.severity === "info" && !e.plain },
      // Warning Button
      {
        "text-white dark:text-surface-900": e.severity === "warn" && !e.text && !e.outlined && !e.plain,
        "bg-orange-500 dark:bg-orange-400": e.severity === "warn" && !e.text && !e.outlined && !e.plain,
        "border border-orange-500 dark:border-orange-400": e.severity === "warn" && !e.text && !e.outlined && !e.plain
      },
      // Warning Text Button
      { "text-orange-500 dark:text-orange-400": e.text && e.severity === "warn" && !e.plain },
      // Warning Outlined Button
      { "text-orange-500 border border-orange-500 hover:bg-orange-300/10": e.outlined && e.severity === "warn" && !e.plain },
      // Help Button
      {
        "text-white dark:text-surface-900": e.severity === "help" && !e.text && !e.outlined && !e.plain,
        "bg-purple-500 dark:bg-purple-400": e.severity === "help" && !e.text && !e.outlined && !e.plain,
        "border border-purple-500 dark:border-purple-400": e.severity === "help" && !e.text && !e.outlined && !e.plain
      },
      // Help Text Button
      { "text-purple-500 dark:text-purple-400": e.text && e.severity === "help" && !e.plain },
      // Help Outlined Button
      { "text-purple-500 border border-purple-500 hover:bg-purple-300/10": e.outlined && e.severity === "help" && !e.plain },
      // Danger Button
      {
        "text-white dark:text-surface-900": e.severity === "danger" && !e.text && !e.outlined && !e.plain,
        "bg-danger-500 dark:bg-danger-400": e.severity === "danger" && !e.text && !e.outlined && !e.plain,
        "border border-danger-500 dark:border-danger-400": e.severity === "danger" && !e.text && !e.outlined && !e.plain
      },
      // Danger Text Button
      { "text-danger-400 dark:text-danger-400": e.text && e.severity === "danger" && !e.plain },
      // Danger Outlined Button
      { "text-danger-400 border border-danger-400 hover:bg-danger-300/10": e.outlined && e.severity === "danger" && !e.plain },
      // Contrast Button
      {
        "text-white dark:text-surface-900": e.severity === "contrast" && !e.text && !e.outlined && !e.plain,
        "bg-surface-900 dark:bg-surface-300": e.severity === "contrast" && !e.text && !e.outlined && !e.plain,
        "border border-surface-900 dark:border-surface-300": e.severity === "contrast" && !e.text && !e.outlined && !e.plain
      },
      // Contrast Text Button
      { "text-surface-900 dark:text-surface-300": e.text && e.severity === "contrast" && !e.plain },
      // Contrast Outlined Button
      { "text-surface-900 dark:text-surface-300 border border-surface-900 dark:border-surface-300": e.outlined && e.severity === "contrast" && !e.plain },
      // --- Severity Button States ---
      "focus:outline-none focus:outline-offset-0 focus:ring-1",
      // Link
      { "focus:ring-primary-400": e.link },
      // Plain
      { "hover:bg-gray-600 hover:border-gray-600": e.plain && !e.outlined && !e.text },
      // Text & Outlined Button
      { "hover:bg-surface-300/10": e.plain && (e.text || e.outlined) },
      // Primary
      { "hover:bg-primary-600/80 hover:border-primary-600/80": !e.link && e.severity === null && !e.text && !e.outlined && !e.plain },
      { "focus:ring-primary-300": e.severity === null },
      // Text & Outlined Button
      { "hover:bg-primary-300/10": (e.text || e.outlined) && e.severity === null && !e.plain },
      // Secondary
      { "hover:bg-surface-200 dark:hover:bg-surface-600 hover:border-surface-200 dark:hover:border-surface-600": e.severity === "secondary" && !e.text && !e.outlined && !e.plain },
      { "focus:ring-surface-500 dark:focus:ring-surface-400": e.severity === "secondary" },
      // Text & Outlined Button
      { "hover:bg-surface-300/10": (e.text || e.outlined) && e.severity === "secondary" && !e.plain },
      // Success
      { "hover:bg-success-600 dark:hover:bg-success-300 hover:border-success-600 dark:hover:border-success-300": e.severity === "success" && !e.text && !e.outlined && !e.plain },
      { "focus:ring-success-500 dark:focus:ring-success-400": e.severity === "success" },
      // Text & Outlined Button
      { "hover:bg-success-300/10": (e.text || e.outlined) && e.severity === "success" && !e.plain },
      // Info
      { "hover:bg-blue-600 dark:hover:bg-info-300 hover:border-blue-600 dark:hover:border-info-300": e.severity === "info" && !e.text && !e.outlined && !e.plain },
      { "focus:ring-blue-400 dark:focus:ring-info-300": e.severity === "info" },
      // Text & Outlined Button
      { "hover:bg-info-300/10": (e.text || e.outlined) && e.severity === "info" && !e.plain },
      // Warning
      { "hover:bg-orange-600 dark:hover:bg-orange-300 hover:border-orange-600 dark:hover:border-orange-300": e.severity === "warn" && !e.text && !e.outlined && !e.plain },
      { "focus:ring-orange-500 dark:focus:ring-orange-400": e.severity === "warn" },
      // Text & Outlined Button
      { "hover:bg-orange-300/10": (e.text || e.outlined) && e.severity === "warn" && !e.plain },
      // Help
      { "hover:bg-purple-600 dark:hover:bg-purple-300 hover:border-purple-600 dark:hover:border-purple-300": e.severity === "help" && !e.text && !e.outlined && !e.plain },
      { "focus:ring-purple-500 dark:focus:ring-purple-400": e.severity === "help" },
      // Text & Outlined Button
      { "hover:bg-purple-300/10": (e.text || e.outlined) && e.severity === "help" && !e.plain },
      // Danger
      { "hover:bg-danger-600 dark:hover:bg-danger-300 hover:border-danger-600 dark:hover:border-danger-300": e.severity === "danger" && !e.text && !e.outlined && !e.plain },
      { "focus:ring-danger-500 dark:focus:ring-danger-400": e.severity === "danger" },
      // Text & Outlined Button
      { "hover:bg-danger-300/10": (e.text || e.outlined) && e.severity === "danger" && !e.plain },
      // Contrast
      { "hover:bg-surface-800 dark:hover:bg-surface-200 hover:border-surface-800 dark:hover:border-surface-200": e.severity === "contrast" && !e.text && !e.outlined && !e.plain },
      { "focus:ring-surface-500 dark:focus:ring-surface-0": e.severity === "contrast" },
      // Text & Outlined Button
      { "hover:bg-surface-900/10 dark:hover:bg-[rgba(255,255,255,0.03)]": (e.text || e.outlined) && e.severity === "contrast" && !e.plain },
      // Disabled
      { "opacity-60 pointer-events-none cursor-default": t.disabled },
      // Transitions
      "transition duration-200 ease-in-out",
      // Misc
      "cursor-pointer overflow-hidden select-none",
      // Badge
      "[&>[data-pc-name=badge]]:min-w-4 [&>[data-pc-name=badge]]:h-4 [&>[data-pc-name=badge]]:leading-4"
    ]
  }),
  label: ({ props: e }) => ({
    class: [
      "duration-200",
      "font-medium",
      {
        "hover:underline": e.link
      },
      { "flex-1": e.label !== null, "invisible w-0": e.label == null }
    ]
  }),
  icon: ({ props: e }) => ({
    class: [
      "text-base leading-4",
      "mx-0",
      {
        "mr-2": e.iconPos == "left" && e.label != null,
        "ml-2 order-1": e.iconPos == "right" && e.label != null,
        "order-2": e.iconPos == "bottom" && e.label != null
      }
    ]
  }),
  loadingIcon: ({ props: e }) => ({
    class: [
      "h-4 w-4",
      "mx-0",
      {
        "mr-2": e.iconPos == "left" && e.label != null,
        "ml-2 order-1": e.iconPos == "right" && e.label != null,
        "mb-2": e.iconPos == "top" && e.label != null,
        "mt-2": e.iconPos == "bottom" && e.label != null
      },
      "animate-spin"
    ]
  }),
  badge: ({ props: e }) => ({
    class: [{ "ml-2 w-4 h-4 leading-none flex items-center justify-center": e.badge }]
  })
}, Ks = {
  root: {
    class: [
      "[&>[data-pc-name=button]]:m-0",
      "[&>[data-pc-name=button]]:border-r-none",
      "[&>[data-pc-name=button]:nth-last-child(n+2)]:rounded-tr-none",
      "[&>[data-pc-name=button]:nth-last-child(n+2)]:rounded-br-none",
      "[&>[data-pc-name=button]:nth-child(n+2)]:rounded-tl-none",
      "[&>[data-pc-name=button]:nth-child(n+2)]:rounded-bl-none"
    ]
  }
}, Ws = {
  root: {
    class: [
      //Flex
      "flex flex-col",
      //Shape
      "rounded-[0.25rem]",
      "shadow-md",
      //Color
      "bg-surface-0 dark:bg-surface-800",
      "text-surface-700 dark:text-surface-0"
    ]
  },
  body: {
    class: [
      //Flex
      "flex flex-col",
      "gap-4",
      "p-6"
    ]
  },
  caption: {
    class: [
      //Flex
      "flex flex-col",
      "gap-2"
    ]
  },
  title: {
    class: "text-xl font-semibold mb-0"
  },
  subtitle: {
    class: [
      //Font
      "font-normal",
      //Spacing
      "mb-0",
      //Color
      "text-surface-600 dark:text-surface-0/60"
    ]
  },
  content: {
    class: "p-0"
  },
  footer: {
    class: "p-0"
  }
}, Gs = {
  root: {
    class: [
      // Flexbox
      "flex flex-col"
    ]
  },
  contentContainer: {
    class: [
      // Flexbox & Overflow
      "flex flex-col overflow-auto"
    ]
  },
  content: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex",
      // Orientation
      {
        "flex-row": e.orientation !== "vertical",
        "flex-col": e.orientation == "vertical"
      },
      "[&>[data-pc-extend=button]]:self-center"
    ]
  }),
  viewport: {
    class: [
      // Overflow & Width
      "overflow-hidden w-full"
    ]
  },
  itemList: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex",
      // Orientation & Sizing
      {
        "flex-row": e.orientation !== "vertical",
        "flex-col h-full": e.orientation == "vertical"
      }
    ]
  }),
  item: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex shrink-0 grow ",
      // Size
      {
        "w-full sm:w-[50%] md:w-[33.333333333333336%]": e.orientation !== "vertical",
        "w-full h-full": e.orientation == "vertical"
      }
    ]
  }),
  itemClone: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex shrink-0 grow",
      "unvisible",
      // Size
      {
        "w-full sm:w-[50%] md:w-[33.333333333333336%]": e.orientation !== "vertical",
        "w-full h-full": e.orientation == "vertical"
      }
    ]
  }),
  indicatorList: {
    class: [
      // Flexbox & Alignment
      "flex flex-row justify-center flex-wrap"
    ]
  },
  indicator: {
    class: [
      // Spacing
      "mr-2 mb-2"
    ]
  },
  indicatorButton: ({ context: e }) => ({
    class: [
      // Sizing & Shape
      "w-8 h-2 rounded-md",
      // Transitions
      "transition duration-200",
      // Focus Styles
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Color & Background
      {
        "bg-surface-200 hover:bg-surface-300 dark:bg-surface-700 dark:hover:bg-surface-600": !e.highlighted,
        "bg-primary hover:bg-primary-emphasis": e.highlighted
      }
    ]
  })
}, qs = {
  root: ({ props: e, state: t }) => ({
    class: [
      "relative",
      // Flex
      {
        flex: e.fluid,
        "inline-flex": !e.fluid
      },
      // Shape
      "rounded-md",
      // Color and Background
      { "bg-surface-0 dark:bg-surface-950": !e.disabled },
      "border",
      { "border-surface-300 dark:border-surface-600": !e.invalid },
      // Invalid State
      "invalid:focus:ring-red-200",
      "invalid:hover:border-red-500",
      { "border-red-500 dark:border-red-400": e.invalid },
      // Transitions
      "transition-all",
      "duration-200",
      // States
      { "hover:border-surface-400 dark:hover:border-surface-600": !e.invalid },
      { "outline-none outline-offset-0 ring-1 ring-primary-500 dark:ring-primary-400": t.focused },
      // Misc
      "cursor-pointer",
      "select-none",
      { "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  label: ({ props: e, parent: t }) => {
    var r, n, o, a;
    return {
      class: [
        //Font
        "leading-[normal]",
        // Display
        "block",
        "flex-auto",
        // Color and Background
        "bg-transparent",
        "border-0",
        { "text-surface-800 dark:text-white/80": e.modelValue != null, "text-surface-400 dark:text-surface-500": e.modelValue == null },
        {
          "placeholder:text-transparent dark:placeholder:text-transparent": ((r = t.instance) == null ? void 0 : r.$name) == "FloatLabel",
          "!text-transparent dark:!text-transparent": ((n = t.instance) == null ? void 0 : n.$name) == "FloatLabel" && e.modelValue == null || ((o = e.modelValue) == null ? void 0 : o.length) == 0
        },
        // Sizing and Spacing
        "w-[1%]",
        "py-2 px-3",
        { "pr-7": e.showClear },
        //Shape
        "rounded-none",
        // Transitions
        "transition",
        "duration-200",
        // States
        "focus:outline-none focus:shadow-none",
        // Filled State *for FloatLabel
        { filled: ((a = t.instance) == null ? void 0 : a.$name) == "FloatLabel" && e.modelValue !== null },
        // Misc
        "relative",
        "cursor-pointer",
        "overflow-hidden overflow-ellipsis",
        "whitespace-nowrap",
        "appearance-none"
      ]
    };
  },
  dropdown: {
    class: [
      // Flexbox
      "flex items-center justify-center",
      "shrink-0",
      // Color and Background
      "bg-transparent",
      "text-surface-500",
      // Size
      "w-12",
      // Shape
      "rounded-r-md"
    ]
  },
  overlay: {
    class: [
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      // Shape
      "border border-surface-300 dark:border-surface-700",
      "rounded-md",
      "shadow-md"
    ]
  },
  list: {
    class: "flex flex-col list-none p-0 m-0 gap-[2px] min-w-full"
  },
  option: ({ context: e }) => ({
    class: [
      //Shape
      "rounded-[4px]",
      // Spacing
      "first:mt-0 mt-[2px]",
      // Colors
      {
        "text-surface-500 dark:text-white/70": !e.focused && !e.active,
        "text-surface-500 dark:text-white/70 bg-surface-200 dark:bg-surface-600/90": e.focused && !e.active,
        "bg-highlight text-highlight-contrast": e.focused && e.active || e.active || !e.focused && e.active
      },
      // Transitions
      "transition-shadow",
      "duration-200",
      // States
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.active,
        "hover:bg-highlight-emphasis": e.active
      },
      // Disabled
      { "opacity-60 pointer-events-none cursor-default": e.disabled }
    ]
  }),
  optionContent: {
    class: [
      "relative",
      "leading-[normal]",
      // Flexbox
      "flex",
      "items-center",
      // Spacing
      "py-2",
      "px-3",
      // Misc
      "no-underline",
      "overflow-hidden",
      "cursor-pointer",
      "select-none"
    ]
  },
  groupIcon: {
    class: [
      // Alignment
      "ml-auto"
    ]
  },
  optionList: {
    class: [
      "min-w-full",
      // Spacing
      "p-1",
      "m-0",
      "list-none",
      // Shape
      "shadow-none sm:shadow-md",
      "rounded-md",
      "border border-surface-200 dark:border-surface-700",
      // Position
      "static sm:absolute",
      "z-10",
      // Color
      "bg-surface-0 dark:bg-surface-900"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Ys = {
  root: {
    class: [
      "relative",
      // Alignment
      "inline-flex",
      "align-bottom",
      // Size
      "w-5",
      "h-5",
      // Misc
      "cursor-pointer",
      "select-none"
    ]
  },
  box: ({ props: e, context: t }) => ({
    class: [
      // Alignment
      "flex",
      "items-center",
      "justify-center",
      // Size
      "w-5",
      "h-5",
      // Shape
      "rounded",
      "border",
      // Colors
      {
        "border-surface-300 dark:border-surface-700": !t.checked && !e.invalid,
        "bg-surface-0 dark:bg-surface-950": !t.checked && !e.invalid && !e.disabled,
        "border-secondary-400 bg-secondary-400": t.checked
      },
      // Invalid State
      "invalid:focus:ring-danger-400",
      "invalid:hover:border-danger-400",
      { "border-danger-400 dark:border-danger-400": e.invalid },
      // States
      {
        "peer-hover:border-surface-400 dark:peer-hover:border-surface-600": !e.disabled && !t.checked && !e.invalid,
        "peer-hover:bg-primary-emphasis peer-hover:border-primary-emphasis": !e.disabled && t.checked,
        "peer-focus-visible:z-10 peer-focus-visible:outline-none peer-focus-visible:outline-offset-0 peer-focus-visible:ring-1 peer-focus-visible:ring-primary-500 dark:peer-focus-visible:ring-secondary-200": !e.disabled,
        "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled
      },
      { "[&>svg]:text-primary-contrast [&>svg]:w-[0.875rem] [&>svg]:h-[0.875rem]": t.checked },
      // Transitions
      "transition-colors",
      "duration-200"
    ]
  }),
  input: {
    class: [
      "peer",
      // Size
      "w-full ",
      "h-full",
      // Position
      "absolute",
      "top-0 left-0",
      "z-10",
      // Spacing
      "p-0",
      "m-0",
      // Shape
      "opacity-0",
      "rounded",
      "outline-none",
      "border border-surface-300 dark:border-surface-700",
      // Misc
      "appearance-none",
      "cursor-pointer"
    ]
  },
  icon: ({ context: e, state: t }) => ({
    class: [
      // Size
      "w-[0.875rem]",
      "h-[0.875rem]",
      // Colors
      {
        "text-primary-contrast": e.checked,
        "text-primary": t.d_indeterminate
      },
      // Transitions
      "transition-all",
      "duration-200"
    ]
  })
}, Js = {
  root: {
    class: [
      // Flexbox
      "inline-flex items-center",
      // Spacing
      "px-3 py-1 gap-2",
      // Shape
      "rounded-[16px]",
      // Colors
      "text-surface-700 dark:text-white",
      "bg-surface-100 dark:bg-surface-700"
    ]
  },
  label: {
    class: "leading-6 m-0"
  },
  icon: {
    class: "leading-6 mr-2"
  },
  image: {
    class: ["w-8 h-8 -ml-2 mr-2", "rounded-full"]
  },
  removeIcon: {
    class: [
      "inline-block",
      // Shape
      "rounded-md leading-6",
      // Size
      "w-4 h-4",
      // Transition
      "transition duration-200 ease-in-out",
      // Misc
      "cursor-pointer"
    ]
  }
}, Qs = {
  root: ({ props: e }) => ({
    class: [
      // Display
      "inline-block",
      // Misc
      { "opacity-60 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  preview: {
    class: [
      // Font
      "text-base leading-none",
      // Spacing
      "m-0",
      "p-0",
      //Size
      "w-6 h-6",
      // Shape
      "rounded-md",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "border border-surface-300 dark:border-surface-700",
      // States
      "hover:border-surface-400 dark:hover:border-surface-600",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
      // Transition
      "transition-colors duration-200",
      // Misc
      "cursor-pointer"
    ]
  },
  panel: ({ props: e }) => ({
    class: [
      // Position & Size
      {
        "relative h-[166px] w-[193px]": e.inline,
        "absolute h-[166px] w-[193px]": !e.inline
      },
      // Shape
      "shadow-md border",
      // Colors
      "bg-surface-800 dark:bg-surface-900 border-surface-600 dark:border-surface-700"
    ]
  }),
  colorSelector: {
    class: [
      // Position
      "absolute top-[8px] left-[8px]",
      // Size
      "h-[150px] w-[150px]"
    ]
  },
  colorbackground: {
    class: [
      // Size
      "h-[150px] w-[150px]"
    ],
    style: "background:linear-gradient(to top,#000 0%,rgba(0,0,0,0) 100%),linear-gradient(to right,#fff 0%,rgba(255,255,255,0) 100%)"
  },
  colorHandle: {
    class: [
      "absolute",
      // Shape
      "rounded-full border border-solid",
      // Size
      "h-[10px] w-[10px]",
      // Spacing
      "-ml-[5px] -mt-[5px]",
      // Colors
      "border-white",
      // Misc
      "cursor-pointer opacity-85"
    ]
  },
  hue: {
    class: [
      // Position
      "absolute top-[8px] left-[167px]",
      // Size
      "h-[150px] w-[17px]",
      // Opacity
      "opacity-85"
    ],
    style: "background: linear-gradient(0deg, red 0, #ff0 17%, #0f0 33%, #0ff 50%, #00f 67%, #f0f 83%, red)"
  },
  hueHandle: {
    class: [
      // Position
      "absolute left-0 -ml-[2px] -mt-[5px]",
      // Size
      "h-[10px] w-[21px]",
      // Shape
      "border-solid border-2",
      // Misc
      "cursor-pointer opacity-85"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Zs = {
  icon: "w-8 h-8 text-[2rem] mr-2"
}, Xs = {
  root: {
    class: [
      // Shape
      "rounded-lg",
      "shadow-lg",
      "border-0",
      // Positioning
      "z-40 transform origin-center",
      "mt-3 absolute left-0 top-0",
      '[&[data-p-confirmpopup-flipped="true"]]:mb-3 [&[data-p-confirmpopup-flipped="true"]]:-mt-3',
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-surface-0/80",
      // Before: Arrow
      "before:absolute before:w-0 before:-top-3 before:h-0 before:border-transparent before:border-solid before:ml-[10px] before:border-x-[10px] before:border-b-[10px] before:border-t-0 before:border-b-surface-200 dark:before:border-b-surface-700",
      "after:absolute after:w-0 after:-top-[0.54rem] after:left-[4px] after:h-0 after:border-transparent after:border-solid after:ml-[8px] after:border-x-[8px] after:border-b-[8px] after:border-t-0 after:border-b-surface-0 dark:after:border-b-surface-900",
      // Flipped: Arrow
      '[&[data-p-confirmpopup-flipped="true"]]:before:-bottom-3 [&[data-p-confirmpopup-flipped="true"]]:before:top-auto [&[data-p-confirmpopup-flipped="true"]]:before:border-b-0 [&[data-p-confirmpopup-flipped="true"]]:before:border-t-[10px] [&[data-p-confirmpopup-flipped="true"]]:before:border-t-surface-200 dark:[&[data-p-confirmpopup-flipped="true"]]:before:border-t-surface-700',
      '[&[data-p-confirmpopup-flipped="true"]]:after:-bottom-[0.54rem] [&[data-p-confirmpopup-flipped="true"]]:after:top-auto [&[data-p-confirmpopup-flipped="true"]]:after:border-b-0 [&[data-p-confirmpopup-flipped="true"]]:after:border-t-[8px] [&[data-p-confirmpopup-flipped="true"]]:after:border-t-surface-0 dark:[&[data-p-confirmpopup-flipped="true"]]:after:border-t-surface-900'
    ]
  },
  content: {
    class: ["p-4 items-center flex", "rounded-t-lg", "border-x border-t last:border-b border-surface-200 dark:border-surface-700"]
  },
  icon: {
    class: "text-2xl mr-4"
  },
  footer: {
    class: [
      // Flexbox and Alignment
      "flex items-center justify-end",
      "shrink-0",
      "text-right",
      "gap-2",
      // Spacing
      "px-4",
      "pb-4",
      // Shape
      "border-t-0",
      "rounded-b-lg",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-surface-0/80",
      "border-x border-b border-surface-200 dark:border-surface-700"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, ei = {
  root: {
    class: [
      // Sizing and Shape
      "min-w-[12.5rem]",
      "rounded-md",
      "shadow-md",
      // Spacing
      "p-1",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      "border border-surface-200 dark:border-surface-700"
    ]
  },
  rootList: {
    class: [
      // Spacings and Shape
      "flex flex-col",
      "list-none",
      "m-0",
      "p-0",
      "outline-none"
    ]
  },
  item: {
    class: "relative my-[2px] [&:first-child]:mt-0"
  },
  itemContent: ({ context: e }) => ({
    class: [
      //Shape
      "rounded-[4px]",
      // Colors
      {
        "text-surface-500 dark:text-white/70": !e.focused && !e.active,
        "text-surface-500 dark:text-white/70 bg-surface-200 dark:bg-surface-600/90": e.focused && !e.active,
        "bg-highlight text-highlight-contrast": e.focused && e.active || e.active || !e.focused && e.active
      },
      // Transitions
      "transition-shadow",
      "duration-200",
      // States
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.active,
        "hover:bg-highlight-emphasis": e.active
      },
      // Disabled
      { "opacity-60 pointer-events-none cursor-default": e.disabled }
    ]
  }),
  itemLink: {
    class: [
      "relative",
      // Flexbox
      "flex",
      "items-center",
      // Spacing
      "py-2",
      "px-3",
      // Misc
      "no-underline",
      "overflow-hidden",
      "cursor-pointer",
      "select-none"
    ]
  },
  itemIcon: {
    class: [
      // Spacing
      "mr-2"
    ]
  },
  itemLabel: {
    class: ["leading-none"]
  },
  submenu: ({ props: e }) => ({
    class: [
      "flex flex-col",
      // Size
      "w-full sm:w-48",
      // Spacing
      "p-1",
      "m-0",
      "list-none",
      // Shape
      "shadow-md",
      "rounded-md",
      "dark:border dark:border-surface-700",
      // Position
      "static sm:absolute",
      "z-10",
      { "sm:absolute sm:left-full sm:top-0": e.level > 1 },
      // Color
      "bg-surface-0 dark:bg-surface-900"
    ]
  }),
  submenuIcon: {
    class: ["ml-auto"]
  },
  separator: {
    class: "border-t border-surface-200 dark:border-surface-700"
  },
  transition: {
    enterFromClass: "opacity-0",
    enterActiveClass: "transition-opacity duration-250"
  }
}, ti = {
  root: ({ props: e }) => ({
    class: [
      "relative",
      // Flex & Alignment
      { "flex flex-col": e.scrollable && e.scrollHeight === "flex" },
      // Size
      { "h-full": e.scrollable && e.scrollHeight === "flex" }
    ]
  }),
  mask: {
    class: [
      // Position
      "absolute",
      "top-0 left-0",
      "z-20",
      // Flex & Alignment
      "flex items-center justify-center",
      // Size
      "w-full h-full",
      // Color
      "bg-surface-100/40 dark:bg-surface-900/40",
      // Transition
      "transition duration-200"
    ]
  },
  loadingIcon: {
    class: "w-8 h-8 animate-spin"
  },
  tableContainer: ({ props: e }) => ({
    class: [
      { relative: e.scrollable, "flex flex-col grow": e.scrollable && e.scrollHeight === "flex" },
      // Size
      { "h-full": e.scrollable && e.scrollHeight === "flex" }
    ]
  }),
  header: ({ props: e }) => ({
    class: [
      "font-bold",
      // Shape
      e.showGridlines ? "border-x border-t border-b-0" : "border-y border-x-0",
      // Spacing
      "p-4",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-200 dark:border-surface-700",
      "text-surface-700 dark:text-white/80"
    ]
  }),
  table: {
    class: "w-full border-spacing-0 border-separate"
  },
  thead: ({ context: e }) => ({
    class: [
      {
        "bg-surface-0 dark:bg-surface-900 top-0 z-40 sticky": e.scrollable
      }
    ]
  }),
  tbody: ({ instance: e, context: t }) => ({
    class: [
      {
        "sticky z-20": e.frozenRow && t.scrollable
      },
      "bg-surface-0 dark:bg-surface-800"
    ]
  }),
  tfoot: ({ context: e }) => ({
    class: [
      {
        "bg-surface-0 bottom-0 z-0": e.scrollable
      }
    ]
  }),
  footer: {
    class: [
      "font-bold",
      // Shape
      "border-t-0 border-b border-x-0 dark:border-b-0",
      // Spacing
      "p-4",
      // Color
      "bg-surface-0 dark:bg-surface-800",
      "border-surface-200 dark:border-surface-700",
      "text-surface-700 dark:text-white/80"
    ]
  },
  column: {
    headerCell: ({ context: e, props: t }) => ({
      class: [
        "font-semibold dark:font-normal",
        "leading-[normal]",
        // Position
        { "sticky z-20 border-b": t.frozen || t.frozen === "" },
        { relative: e.resizable },
        // Alignment
        "text-left",
        // Shape
        { "first:border-l border-y border-r": e == null ? void 0 : e.showGridlines },
        "border-x-0 border-y-2 border-solid",
        // Spacing
        (e == null ? void 0 : e.size) === "small" ? "py-[0.375rem] px-2" : (e == null ? void 0 : e.size) === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
        // Color
        (t.sortable === "" || t.sortable) && e.sorted ? "bg-highlight" : "bg-surface-50 text-surface-700 dark:text-surface-0/50 dark:bg-surface-800/50",
        "border-surface-200 dark:border-surface-900",
        // States
        { "hover:bg-surface-100 dark:hover:bg-surface-800/50": (t.sortable === "" || t.sortable) && !(e != null && e.sorted) },
        "focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
        // Transition
        { "transition duration-200": t.sortable === "" || t.sortable },
        // Misc
        { "cursor-pointer": t.sortable === "" || t.sortable },
        {
          "overflow-hidden whitespace-nowrap border-y bg-clip-padding": e == null ? void 0 : e.resizable
          // Resizable
        }
      ]
    }),
    columnHeaderContent: {
      class: "flex items-center gap-2"
    },
    sort: ({ context: e }) => ({
      class: [e.sorted ? "text-primary-500" : "text-surface-700", e.sorted ? "dark:text-primary-400" : "dark:text-white/80"]
    }),
    bodyCell: ({ props: e, context: t, state: r, parent: n }) => {
      var o, a, s;
      return {
        class: [
          // Font
          "leading-[normal]",
          //Position
          { "sticky box-border border-b": n.instance.frozenRow },
          { "sticky box-border border-b z-20": e.frozen || e.frozen === "" },
          // Alignment
          "text-left",
          // Shape
          "border-0 border-b dark:border-b-0 border-solid",
          { "first:border-l border-r border-b": t == null ? void 0 : t.showGridlines },
          { "bg-surface-0 dark:bg-surface-900": n.instance.frozenRow || e.frozen || e.frozen === "" },
          // Spacing
          { "py-[0.375rem] px-2": (t == null ? void 0 : t.size) === "small" && !r.d_editing },
          { "py-[0.9375rem] px-5": (t == null ? void 0 : t.size) === "large" && !r.d_editing },
          { "py-3 px-4": (t == null ? void 0 : t.size) !== "large" && (t == null ? void 0 : t.size) !== "small" && !r.d_editing },
          { "py-[0.6rem] px-2": r.d_editing },
          // Color
          "border-surface-200 dark:border-surface-700",
          {
            "overflow-hidden whitespace-nowrap border-y bg-clip-padding": (s = (a = (o = n.instance) == null ? void 0 : o.$parentInstance) == null ? void 0 : a.$parentInstance) == null ? void 0 : s.resizableColumns
            // Resizable
          }
        ]
      };
    },
    footerCell: ({ context: e }) => ({
      class: [
        // Font
        "font-bold",
        // Alignment
        "text-left",
        // Shape
        "border-0 border-b border-solid",
        { "border-x border-y": e == null ? void 0 : e.showGridlines },
        // Spacing
        (e == null ? void 0 : e.size) === "small" ? "p-2" : (e == null ? void 0 : e.size) === "large" ? "p-5" : "p-4",
        // Color
        "border-surface-200 dark:border-surface-700",
        "text-surface-700 dark:text-white/80",
        "bg-surface-0 dark:bg-surface-900"
      ]
    }),
    sortIcon: ({ context: e }) => ({
      class: ["ml-2", e.sorted ? "text-inherit" : "text-surface-700 dark:text-white/70"]
    }),
    columnFilter: {
      class: "inline-flex items-center ml-auto font-normal"
    },
    filterOverlay: {
      class: [
        "flex flex-col gap-2",
        // Position
        "absolute top-0 left-0",
        // Shape
        "border-0 dark:border",
        "rounded-md",
        "shadow-md",
        // Size
        "min-w-[12.5rem]",
        // Color
        "bg-surface-0 dark:bg-surface-900",
        "text-surface-800 dark:text-white/80",
        "dark:border-surface-700"
      ]
    },
    filterConstraintList: {
      class: "m-0 p-0 py-3 list-none"
    },
    filterConstraint: ({ context: e }) => ({
      class: [
        // Font
        "font-normal",
        "leading-none",
        // Position
        "relative",
        // Shape
        "border-0",
        "rounded-none",
        // Spacing
        "m-0",
        "py-3 px-5",
        // Color
        { "text-surface-700 dark:text-white/80": !(e != null && e.highlighted) },
        { "bg-surface-0 dark:bg-surface-900 text-surface-700 dark:text-white/80": !(e != null && e.highlighted) },
        { "bg-highlight": e == null ? void 0 : e.highlighted },
        //States
        { "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !(e != null && e.highlighted) },
        { "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": !(e != null && e.highlighted) },
        "focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
        // Transitions
        "transition-shadow",
        "duration-200",
        // Misc
        "cursor-pointer",
        "overflow-hidden",
        "whitespace-nowrap"
      ]
    }),
    filterOperator: {
      class: [
        // Shape
        "rounded-t-md",
        // Color
        "text-surface-700 dark:text-white/80",
        "bg-surface-0 dark:bg-surface-700",
        "[&>[data-pc-name=pcfilteroperatordropdown]]:w-full"
      ]
    },
    filter: ({ instance: e }) => ({
      class: [{ "flex items-center w-full gap-2": e.display === "row", "inline-flex ml-auto": e.display === "menu" }]
    }),
    filterRule: "flex flex-col gap-2",
    filterButtonbar: "flex items-center justify-between p-0",
    filterAddButtonContainer: "[&>[data-pc-name=pcfilteraddrulebutton]]:w-full",
    rowToggleButton: {
      class: [
        "relative",
        // Flex & Alignment
        "inline-flex items-center justify-center",
        "text-left",
        // Spacing
        "m-0 p-0",
        // Size
        "w-8 h-8",
        // Shape
        "border-0 rounded-full",
        // Color
        "text-surface-500 dark:text-white/70",
        "bg-transparent",
        "focus-visible:outline-none focus-visible:outline-offset-0",
        "focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
        // Transition
        "transition duration-200",
        // Misc
        "overflow-hidden",
        "cursor-pointer select-none"
      ]
    },
    columnResizer: {
      class: [
        "block",
        // Position
        "absolute top-0 right-0",
        // Sizing
        "w-2 h-full",
        // Spacing
        "m-0 p-0",
        // Color
        "border border-transparent",
        // Misc
        "cursor-col-resize"
      ]
    },
    transition: {
      class: "p-4 flex flex-col gap-2",
      enterFromClass: "opacity-0 scale-y-[0.8]",
      enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
      leaveActiveClass: "transition-opacity duration-100 ease-linear",
      leaveToClass: "opacity-0"
    }
  },
  bodyRow: ({ context: e, props: t, parent: r }) => ({
    class: [
      // Color
      { "bg-highlight": e.selected },
      { "bg-surface-0 text-surface-600 dark:text-white/80 dark:bg-surface-900": !e.selected },
      { "font-bold bg-surface-0 dark:bg-surface-900 z-20": t.frozenRow },
      { "odd:bg-surface-0 odd:text-surface-600 dark:odd:text-surface-0 dark:even:text-surface-0 dark:odd:bg-surface-800 even:bg-surface-50 even:text-surface-600 dark:even:bg-surface-900": e.stripedRows },
      // State
      { "hover:bg-surface-300/20 dark:hover:bg-surface-700/50": t.selectionMode && !e.selected || r.instance.rowHover },
      // Transition
      { "transition duration-200": t.selectionMode && !e.selected || t.rowHover },
      // Misc
      { "cursor-pointer": t.selectionMode || r.instance.rowHover }
    ]
  }),
  rowExpansion: {
    class: "bg-surface-0 dark:bg-surface-900 text-surface-600 dark:text-white/80"
  },
  rowGroupHeader: {
    class: ["sticky z-20", "bg-surface-0 text-surface-600 dark:text-white/70", "dark:bg-surface-900"]
  },
  rowGroupFooter: {
    class: ["sticky z-20", "bg-surface-0 text-surface-600 dark:text-white/70", "dark:bg-surface-900"]
  },
  rowToggleButton: {
    class: [
      "relative",
      // Flex & Alignment
      "inline-flex items-center justify-center",
      "text-left",
      // Spacing
      "m-0 p-0",
      // Size
      "w-8 h-8",
      // Shape
      "border-0 rounded-full",
      // Color
      "text-surface-500 dark:text-white/70",
      "bg-transparent",
      "focus-visible:outline-none focus-visible:outline-offset-0",
      "focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
      // Transition
      "transition duration-200",
      // Misc
      "overflow-hidden",
      "cursor-pointer select-none"
    ]
  },
  rowToggleIcon: {
    class: "inline-block w-4 h-4"
  },
  columnResizeIndicator: {
    class: "absolute hidden w-[2px] z-20 bg-primary"
  }
}, ri = {
  content: {
    class: [
      // Spacing
      "p-0",
      // Shape
      "border-0",
      // Color
      "text-surface-700 dark:text-white/80",
      "bg-surface-0 dark:bg-surface-900"
    ]
  },
  header: {
    class: [
      "font-semibold",
      // Spacing
      "py-3 px-4",
      // Color
      "text-surface-800 dark:text-white/80",
      "bg-surface-00 dark:bg-surface-900",
      "border-b border-surface-200 dark:border-surface-700"
    ]
  }
}, Qn = {
  root: ({ props: e }) => ({
    class: [
      // Display and Position
      {
        flex: e.fluid,
        "inline-flex": !e.fluid
      },
      "max-w-full",
      "relative"
    ]
  }),
  pcInput: ({ props: e, parent: t }) => {
    var r;
    return {
      root: {
        class: [
          // Display
          "flex-auto w-[1%]",
          // Font
          "leading-none",
          // Colors
          "text-surface-600 dark:text-surface-200",
          "placeholder:text-surface-400 dark:placeholder:text-surface-500",
          { "bg-surface-0 dark:bg-surface-950": !e.disabled },
          "border",
          { "border-surface-300 dark:border-surface-600": !e.invalid },
          // Invalid State
          "invalid:focus:ring-red-200",
          "invalid:hover:border-red-500",
          { "border-red-500 dark:border-red-400": e.invalid },
          // Spacing
          "m-0 py-2 px-3",
          // Shape
          "appearance-none",
          { "rounded-md": !e.showIcon || e.iconDisplay == "input" },
          { "rounded-l-md  flex-1 pr-9": e.showIcon && e.iconDisplay !== "input" },
          { "rounded-md flex-1 pr-9": e.showIcon && e.iconDisplay === "input" },
          // Transitions
          "transition-colors",
          "duration-200",
          // States
          {
            "hover:border-surface-400 dark:hover:border-surface-600": !e.disabled && !e.invalid,
            "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10": !e.disabled,
            "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled
          },
          // Filled State *for FloatLabel
          { filled: ((r = t.instance) == null ? void 0 : r.$name) == "FloatLabel" && e.modelValue !== null }
        ]
      }
    };
  },
  dropdownIcon: {
    class: ["absolute top-1/2 -mt-2", "text-surface-600 dark:text-surface-200", "right-3"]
  },
  dropdown: {
    class: [
      "relative",
      // Alignments
      "items-center inline-flex text-center align-bottom justify-center",
      // Shape
      "rounded-r-md",
      // Size
      "py-2 px-0",
      "w-10",
      "leading-[normal]",
      // Colors
      "border border-l-0 border-surface-300 dark:border-surface-600",
      // States
      "focus:outline-none focus:outline-offset-0 focus:ring-1",
      "hover:bg-primary-hover hover:border-primary-hover",
      "focus:ring-primary-500 dark:focus:ring-primary-400"
    ]
  },
  inputIconContainer: "absolute cursor-pointer top-1/2 right-3 -mt-3",
  inputIcon: "inline-block text-base",
  panel: ({ props: e }) => ({
    class: [
      // Display & Position
      {
        absolute: !e.inline,
        "inline-block": e.inline
      },
      // Size
      { "w-auto p-3 ": !e.inline },
      { "min-w-[80vw] w-auto p-3 ": e.touchUI },
      { "p-3 min-w-full": e.inline },
      // Shape
      "border rounded-lg",
      {
        "shadow-md": !e.inline
      },
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-200 dark:border-surface-700",
      //misc
      { "overflow-x-auto": e.inline }
    ]
  }),
  header: {
    class: [
      //Font
      "font-medium",
      // Flexbox and Alignment
      "flex items-center justify-between",
      // Spacing
      "p-0 pb-2",
      "m-0",
      // Shape
      "border-b",
      "rounded-t-md",
      // Colors
      "text-surface-700 dark:text-white/80",
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-200 dark:border-surface-700"
    ]
  },
  title: {
    class: [
      // Text
      "leading-7",
      "mx-auto my-0"
    ]
  },
  selectMonth: {
    class: [
      // Font
      "text-base leading-[normal]",
      "font-medium",
      //shape
      "rounded-md",
      // Colors
      "text-surface-700 dark:text-white/80",
      // Transitions
      "transition duration-200",
      // Spacing
      "p-1",
      "m-0 mr-2",
      // States
      "hover:text-primary-500 dark:hover:text-primary-400",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
      // Misc
      "cursor-pointer"
    ]
  },
  selectYear: {
    class: [
      // Font
      "text-base leading-[normal]",
      "font-medium",
      //shape
      "rounded-md",
      // Colors
      "text-surface-700 dark:text-white/80",
      // Transitions
      "transition duration-200",
      // Spacing
      "p-1",
      "m-0 mr-2",
      // States
      "hover:text-primary-500 dark:hover:text-primary-400",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
      // Misc
      "cursor-pointer"
    ]
  },
  table: {
    class: [
      // Font
      "text-base leading-[normal]",
      // Size & Shape
      "border-collapse",
      "w-full",
      // Spacing
      "m-0 mt-2"
    ]
  },
  tableHeaderCell: {
    class: [
      // Spacing
      "p-1",
      "font-medium"
    ]
  },
  weekHeader: {
    class: ["leading-5", "text-surface-600 dark:text-white/70", "opacity-60 cursor-default"]
  },
  weekNumber: {
    class: ["text-surface-600 dark:text-white/70", "opacity-60 cursor-default"]
  },
  weekday: {
    class: [
      // Colors
      "text-surface-500 dark:text-white/60",
      "p-1"
    ]
  },
  dayCell: {
    class: [
      // Spacing
      "p-1"
    ]
  },
  weekLabelContainer: {
    class: [
      // Flexbox and Alignment
      "flex items-center justify-center",
      "mx-auto",
      // Shape & Size
      "w-8 h-8",
      "rounded-full",
      "border-transparent border",
      "leading-[normal]",
      // Colors
      "opacity-60 cursor-default"
    ]
  },
  dayView: "w-full",
  day: ({ context: e }) => ({
    class: [
      // Flexbox and Alignment
      "flex items-center justify-center",
      "mx-auto",
      // Shape & Size
      "w-8 h-8",
      "rounded-full",
      "border-transparent border",
      "leading-[normal]",
      // Colors
      {
        "bg-surface-100 dark:bg-surface-800 text-surface-600 dark:text-white/70": e.date.today && !e.selected && !e.disabled,
        "bg-transparent text-surface-600 dark:text-white/70": !e.selected && !e.disabled && !e.date.today,
        "bg-highlight": e.selected && !e.disabled
      },
      // States
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
      {
        "hover:bg-surface-50 dark:hover:bg-surface-500/10": !e.selected && !e.disabled
      },
      {
        "opacity-60 cursor-default": e.disabled,
        "cursor-pointer": !e.disabled
      }
    ]
  }),
  monthView: {
    class: [
      // Spacing
      "mt-2"
    ]
  },
  month: ({ context: e }) => ({
    class: [
      // Flexbox and Alignment
      "inline-flex items-center justify-center",
      // Size
      "w-1/3",
      "p-1",
      // Shape
      "rounded-md",
      // Colors
      {
        "text-surface-600 dark:text-white/70 bg-transparent": !e.selected && !e.disabled,
        "bg-highlight": e.selected && !e.disabled
      },
      // States
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.selected && !e.disabled
      },
      // Misc
      "cursor-pointer"
    ]
  }),
  yearView: {
    class: [
      // Spacing
      "mt-2"
    ]
  },
  year: ({ context: e }) => ({
    class: [
      // Flexbox and Alignment
      "inline-flex items-center justify-center",
      // Size
      "w-1/2",
      "p-1",
      // Shape
      "rounded-md",
      // Colors
      {
        "text-surface-600 dark:text-white/70 bg-transparent": !e.selected && !e.disabled,
        "bg-highlight": e.selected && !e.disabled
      },
      // States
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10",
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.selected && !e.disabled
      },
      // Misc
      "cursor-pointer"
    ]
  }),
  timePicker: {
    class: [
      // Flexbox
      "flex",
      "justify-center items-center",
      // Borders
      "border-t-1",
      "border-solid border-surface-200",
      // Spacing
      "pt-2 mt-2"
    ]
  },
  separatorContainer: {
    class: [
      // Flexbox and Alignment
      "flex",
      "items-center",
      "flex-col",
      // Spacing
      "px-2"
    ]
  },
  separator: {
    class: [
      // Text
      "text-xl"
    ]
  },
  hourPicker: {
    class: [
      // Flexbox and Alignment
      "flex",
      "items-center",
      "flex-col",
      // Spacing
      "px-2"
    ]
  },
  minutePicker: {
    class: [
      // Flexbox and Alignment
      "flex",
      "items-center",
      "flex-col",
      // Spacing
      "px-2"
    ]
  },
  secondPicker: {
    class: [
      // Flexbox and Alignment
      "flex",
      "items-center",
      "flex-col",
      // Spacing
      "px-2"
    ]
  },
  ampmPicker: {
    class: [
      // Flexbox and Alignment
      "flex",
      "items-center",
      "flex-col",
      // Spacing
      "px-2"
    ]
  },
  calendarContainer: "flex",
  calendar: "flex-auto border-l first:border-l-0 border-surface-200",
  buttonbar: {
    class: [
      // Flexbox
      "flex justify-between items-center",
      // Spacing
      "pt-2",
      // Shape
      "border-t border-surface-200 dark:border-surface-700"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, ni = {
  root: {}
}, oi = {
  root: ({ state: e }) => ({
    class: [
      // Shape
      "rounded-lg",
      "shadow-lg",
      "border-0",
      // Size
      "max-h-[90vh]",
      "m-0",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "[&:last-child]:border-b",
      "border-surface-200 dark:border-surface-700",
      // Transitions
      "transform",
      "scale-100",
      // Maximized State
      {
        "transition-none": e.maximized,
        "transform-none": e.maximized,
        "!w-screen": e.maximized,
        "!h-screen": e.maximized,
        "!max-h-full": e.maximized,
        "!top-0": e.maximized,
        "!left-0": e.maximized
      }
    ]
  }),
  header: {
    class: [
      // Flexbox and Alignment
      "flex items-center justify-between",
      "shrink-0",
      // Spacing
      "p-6",
      // Shape
      "rounded-tl-lg",
      "rounded-tr-lg",
      // Colors
      "text-surface-700 dark:text-surface-0/80",
      "border border-b-0",
      "border-surface-200 dark:border-surface-700"
    ]
  },
  title: {
    class: ["font-semibold text-xl leading-[normal]"]
  },
  headerActions: {
    class: ["flex items-center"]
  },
  content: ({ state: e, instance: t }) => ({
    class: [
      // Spacing
      "px-6",
      "pb-6",
      "pt-0",
      // Shape
      {
        grow: e.maximized,
        "rounded-bl-lg": !t.$slots.footer,
        "rounded-br-lg": !t.$slots.footer
      },
      // Colors
      "text-surface-700 dark:text-surface-0/80",
      "border border-t-0 border-b-0",
      "border-surface-200 dark:border-surface-700",
      // Misc
      "overflow-y-auto"
    ]
  }),
  footer: {
    class: [
      // Flexbox and Alignment
      "flex items-center justify-end",
      "shrink-0",
      "text-right",
      "gap-2",
      // Spacing
      "px-6",
      "pb-6",
      // Shape
      "border-t-0",
      "rounded-b-lg",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-surface-0/80",
      "border border-t-0 border-b-0",
      "border-surface-200 dark:border-surface-700"
    ]
  },
  mask: ({ props: e }) => ({
    class: [
      // Transitions
      "transition-all",
      "duration-300",
      { "p-5": e.position !== "full" },
      // Background and Effects
      { "has-[.mask-active]:bg-transparent bg-black/40": e.modal }
    ]
  }),
  transition: ({ props: e }) => e.position === "top" ? {
    enterFromClass: "opacity-0 scale-75 translate-x-0 -translate-y-full translate-z-0 mask-active",
    enterActiveClass: "transition-all duration-200 ease-out",
    leaveActiveClass: "transition-all duration-200 ease-out",
    leaveToClass: "opacity-0 scale-75 translate-x-0 -translate-y-full translate-z-0 mask-active"
  } : e.position === "bottom" ? {
    enterFromClass: "opacity-0 scale-75 translate-y-full mask-active",
    enterActiveClass: "transition-all duration-200 ease-out",
    leaveActiveClass: "transition-all duration-200 ease-out",
    leaveToClass: "opacity-0 scale-75 translate-x-0 translate-y-full translate-z-0 mask-active"
  } : e.position === "left" || e.position === "topleft" || e.position === "bottomleft" ? {
    enterFromClass: "opacity-0 scale-75 -translate-x-full translate-y-0 translate-z-0 mask-active",
    enterActiveClass: "transition-all duration-200 ease-out",
    leaveActiveClass: "transition-all duration-200 ease-out",
    leaveToClass: "opacity-0 scale-75  -translate-x-full translate-y-0 translate-z-0 mask-active"
  } : e.position === "right" || e.position === "topright" || e.position === "bottomright" ? {
    enterFromClass: "opacity-0 scale-75 translate-x-full translate-y-0 translate-z-0 mask-active",
    enterActiveClass: "transition-all duration-200 ease-out",
    leaveActiveClass: "transition-all duration-200 ease-out",
    leaveToClass: "opacity-0 scale-75 translate-x-full translate-y-0 translate-z-0 mask-active"
  } : {
    enterFromClass: "opacity-0 scale-75 mask-active",
    enterActiveClass: "transition-all duration-200 ease-out",
    leaveActiveClass: "transition-all duration-200 ease-out",
    leaveToClass: "opacity-0 scale-75 mask-active"
  }
}, ai = {
  root: ({ props: e }) => ({
    class: [
      // Flex and Position
      "flex relative",
      { "justify-center": e.layout == "vertical" },
      { "items-center": e.layout == "vertical" },
      {
        "justify-start": (e == null ? void 0 : e.align) == "left" && e.layout == "horizontal",
        "justify-center": (e == null ? void 0 : e.align) == "center" && e.layout == "horizontal",
        "justify-end": (e == null ? void 0 : e.align) == "right" && e.layout == "horizontal",
        "items-center": (e == null ? void 0 : e.align) == "top" && e.layout == "vertical",
        "items-start": (e == null ? void 0 : e.align) == "center" && e.layout == "vertical",
        "items-end": (e == null ? void 0 : e.align) == "bottom" && e.layout == "vertical"
      },
      // Spacing
      {
        "my-5 mx-0 py-0 px-5": e.layout == "horizontal",
        "mx-4 md:mx-5 py-5": e.layout == "vertical"
      },
      // Size
      {
        "w-full": e.layout == "horizontal",
        "min-h-full": e.layout == "vertical"
      },
      // Before: Line
      "before:block",
      // Position
      {
        "before:absolute before:left-0 before:top-1/2": e.layout == "horizontal",
        "before:absolute before:left-1/2 before:top-0 before:transform before:-translate-x-1/2": e.layout == "vertical"
      },
      // Size
      {
        "before:w-full": e.layout == "horizontal",
        "before:min-h-full": e.layout == "vertical"
      },
      // Shape
      {
        "before:border-solid": e.type == "solid",
        "before:border-dotted": e.type == "dotted",
        "before:border-dashed": e.type == "dashed"
      },
      // Color
      {
        "before:border-t before:border-surface-200 before:dark:border-surface-600": e.layout == "horizontal",
        "before:border-l before:border-surface-200 before:dark:border-surface-600": e.layout == "vertical"
      }
    ]
  }),
  content: {
    class: [
      // Space and Position
      "px-1 z-10",
      // Color
      "bg-surface-0 dark:bg-surface-800"
    ]
  }
}, si = {
  root: ({ props: e }) => ({
    class: [
      // Positioning
      "absolute z-1",
      {
        "left-0 bottom-0 w-full": e.position == "bottom",
        "left-0 top-0 w-full": e.position == "top",
        "left-0 top-0 h-full": e.position == "left",
        "right-0 top-0 h-full": e.position == "right"
      },
      // Flexbox & Alignment
      "flex justify-center items-center",
      // Interactivity
      "pointer-events-none"
    ]
  }),
  listContainer: {
    class: [
      // Flexbox
      "flex",
      // Shape & Border
      "rounded-md",
      // Color
      "bg-surface-0/10 dark:bg-surface-900/20 border border-surface-0/20",
      "backdrop-blur-sm",
      // Spacing
      "p-2",
      // Misc
      "pointer-events-auto"
    ]
  },
  list: ({ props: e }) => ({
    class: [
      // Flexbox & Alignment
      "flex items-center justify-center",
      {
        "flex-col": e.position == "left" || e.position == "right"
      },
      // List Style
      "m-0 p-0 list-none",
      // Shape
      "outline-none"
    ]
  }),
  item: ({ props: e, context: t, instance: r }) => ({
    class: [
      // Spacing & Shape
      "p-2 rounded-md",
      // Positioning & Hover States
      {
        "origin-bottom": e.position == "bottom",
        "origin-top": e.position == "top",
        "origin-left": e.position == "left",
        "origin-right": e.position == "right"
      },
      // Transitions & Transform
      "transition-all duration-200 ease-cubic-bezier-will-change-transform transform"
    ]
  }),
  itemLink: {
    class: [
      // Flexbox & Alignment
      "flex flex-col items-center justify-center",
      // Position
      "relative",
      // Size
      "w-16 h-16",
      // Misc
      "cursor-default overflow-hidden"
    ]
  }
}, Zn = {
  root: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex flex-col",
      // Position
      "relative",
      { "!transition-none !transform-none !w-screen !h-screen !max-h-full !top-0 !left-0": e.position == "full" },
      // Size
      {
        "h-full w-80": e.position == "left" || e.position == "right",
        "h-auto w-full": e.position == "top" || e.position == "bottom"
      },
      // Shape
      "border-0 dark:border",
      "shadow-lg",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      "dark:border-surface-700",
      // Transitions
      "transition-transform",
      "duration-300",
      // Misc
      "pointer-events-auto"
    ]
  }),
  header: {
    class: [
      // Flexbox and Alignment
      "flex items-center justify-between",
      "shrink-0",
      // Spacing
      "p-[1.125rem]",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-surface-0/80"
    ]
  },
  title: {
    class: ["font-semibold text-xl"]
  },
  icons: {
    class: ["flex items-center"]
  },
  closeButton: {
    class: [
      "relative",
      // Flexbox and Alignment
      "flex items-center justify-center",
      // Size and Spacing
      "mr-2",
      "last:mr-0",
      "w-7 h-7",
      // Shape
      "border-0",
      "rounded-full",
      // Colors
      "text-surface-500",
      "bg-transparent",
      // Transitions
      "transition duration-200 ease-in-out",
      // States
      "hover:text-surface-700 dark:hover:text-white/80",
      "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
      "focus:outline-none focus:outline-offset-0 focus:ring-1",
      "focus:ring-primary-500 dark:focus:ring-primary-400",
      // Misc
      "overflow-hidden"
    ]
  },
  closeButtonIcon: {
    class: [
      // Display
      "inline-block",
      // Size
      "w-4",
      "h-4"
    ]
  },
  content: {
    class: [
      // Spacing and Size
      "p-[1.125rem]",
      "pt-0",
      "h-full",
      "w-full",
      // Growth and Overflow
      "grow",
      "overflow-y-auto"
    ]
  },
  mask: ({ props: e }) => ({
    class: [
      // Transitions
      "transition-all",
      "duration-300",
      { "p-5": e.position !== "full" },
      // Background and Effects
      { "has-[.mask-active]:bg-transparent bg-black/40": e.modal }
    ]
  }),
  transition: ({ props: e }) => e.position === "top" ? {
    enterFromClass: "translate-x-0 -translate-y-full translate-z-0 mask-active",
    leaveToClass: "translate-x-0 -translate-y-full translate-z-0 mask-active"
  } : e.position === "bottom" ? {
    enterFromClass: "translate-x-0 translate-y-full translate-z-0 mask-active",
    leaveToClass: "translate-x-0 translate-y-full translate-z-0 mask-active"
  } : e.position === "left" ? {
    enterFromClass: "-translate-x-full translate-y-0 translate-z-0 mask-active",
    leaveToClass: "-translate-x-full translate-y-0 translate-z-0 mask-active"
  } : e.position === "right" ? {
    enterFromClass: "translate-x-full translate-y-0 translate-z-0 mask-active",
    leaveToClass: "translate-x-full translate-y-0 translate-z-0 mask-active"
  } : {
    enterFromClass: "opacity-0 mask-active",
    enterActiveClass: "transition-opacity duration-400 ease-in",
    leaveActiveClass: "transition-opacity duration-400 ease-in",
    leaveToClass: "opacity-0 mask-active"
  }
}, ii = {
  root: {
    class: [
      // Spacing
      "p-[1.125rem] pt-0",
      // Shape
      "rounded-md",
      // Color
      "border border-surface-200 dark:border-surface-700",
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-surface-0/80"
    ]
  },
  legend: ({ props: e }) => ({
    class: [
      // Font
      "font-semibold",
      "leading-none",
      //Spacing
      "p-0 mb-[0.375rem]",
      // Shape
      "rounded-md",
      // Color
      "text-surface-700 dark:text-surface-0/80",
      "bg-surface-0 dark:bg-surface-900",
      // Transition
      "transition-none",
      // States
      { "hover:bg-surface-100 dark:hover:bg-surface-800": e.toggleable }
    ]
  }),
  toggleButton: ({ props: e }) => ({
    class: [
      // Alignments
      "flex items-center justify-center",
      "relative",
      //Spacing
      { "py-2 px-3": e.toggleable },
      // Shape
      { "rounded-md": e.toggleable },
      // Color
      { "text-surface-700 dark:text-surface-200 hover:text-surface-900": e.toggleable },
      // States
      { "hover:text-surface-900 dark:hover:text-surface-100": e.toggleable },
      { "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300": e.toggleable },
      // Misc
      {
        "transition-none cursor-pointer overflow-hidden select-none": e.toggleable
      }
    ]
  }),
  toggleIcon: {
    class: "mr-2 inline-block"
  },
  legendLabel: ({ props: e }) => ({
    class: ["flex items-center justify-center leading-none", { "py-2 px-3": !e.toggleable }]
  }),
  content: {
    class: "p-0"
  },
  transition: {
    enterFromClass: "max-h-0",
    enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
    enterToClass: "max-h-[1000px]",
    leaveFromClass: "max-h-[1000px]",
    leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
    leaveToClass: "max-h-0"
  }
}, li = {
  root: ({ props: e }) => ({
    class: [
      {
        "flex flex-wrap items-center justify-center gap-2": e.mode === "basic"
      }
    ]
  }),
  input: {
    class: "hidden"
  },
  header: {
    class: [
      // Flexbox
      "flex",
      "flex-wrap",
      // Colors
      "bg-surface-0",
      "dark:bg-surface-900",
      "text-surface-700",
      "dark:text-white/80",
      // Spacing
      "p-[1.125rem]",
      "gap-2",
      // Borders
      "border",
      "border-solid",
      "border-surface-200",
      "dark:border-surface-700",
      "border-b-0",
      // Shape
      "rounded-tr-lg",
      "rounded-tl-lg"
    ]
  },
  content: {
    class: [
      // Position
      "relative",
      // Colors
      "bg-surface-0",
      "dark:bg-surface-900",
      "text-surface-700",
      "dark:text-white/80",
      // Spacing
      "p-[1.125rem]",
      // Borders
      "border border-t-0",
      "border-surface-200",
      "dark:border-surface-700",
      // Shape
      "rounded-b-lg",
      //ProgressBar
      "[&>[data-pc-name=pcprogressbar]]:absolute",
      "[&>[data-pc-name=pcprogressbar]]:w-full",
      "[&>[data-pc-name=pcprogressbar]]:top-0",
      "[&>[data-pc-name=pcprogressbar]]:left-0",
      "[&>[data-pc-name=pcprogressbar]]:h-1"
    ]
  },
  file: {
    class: [
      // Flexbox
      "flex",
      "items-center",
      "flex-wrap",
      // Spacing
      "p-4",
      "mb-2",
      "last:mb-0",
      // Borders
      "border",
      "border-surface-200",
      "dark:border-surface-700",
      "gap-2",
      // Shape
      "rounded"
    ]
  },
  fileThumbnail: "shrink-0",
  fileName: "mb-2 break-all",
  fileSize: "mr-2"
}, ci = {
  root: {
    class: [
      "block relative",
      // Base Label Appearance
      "[&>*:last-child]:text-surface-900/60 dark:[&>*:last-child]:text-white/60",
      "[&>*:last-child]:absolute",
      "[&>*:last-child]:left-3",
      "[&>*:last-child]:pointer-events-none",
      "[&>*:last-child]:transition-all",
      "[&>*:last-child]:duration-200",
      "[&>*:last-child]:ease",
      // Position for all labels except those following textarea
      "[&>:not(textarea)~label]:top-1/2 [&>:not(textarea)~label]:-translate-y-1/2 ",
      // Position for labels following textareas
      "[&>textarea~label]:top-4",
      // Focus Label Appearance
      "[&>*:last-child]:has-[:focus]:-top-3",
      "[&>*:last-child]:has-[:focus]:text-sm",
      "[&>*:last-child]:has-[:focus]:z-10",
      // Filled Input Label Appearance
      "[&>*:last-child]:has-[.filled]:-top-3",
      "[&>*:last-child]:has-[.filled]:text-sm",
      "[&>*:last-child]:has-[.filled]:z-10"
    ]
  }
}, ui = {
  content: ({ parent: e, props: t }) => ({
    class: [
      "flex",
      {
        "flex-col": t.fullScreen
      },
      {
        "flex-col": e.props.thumbnailsPosition === "top" || e.props.thumbnailsPosition === "bottom",
        "flex-row": e.props.thumbnailsPosition === "right" || e.props.thumbnailsPosition === "left"
      }
    ]
  }),
  itemsContainer: ({ parent: e, props: t }) => ({
    class: [
      "group",
      "flex relative",
      {
        "grow shrink w-0 justify-center": t.fullScreen
      },
      {
        "flex-col": e.props.indicatorsPosition === "bottom" || e.props.indicatorsPosition === "top",
        "flex-row items-center": e.props.indicatorsPosition === "left" || e.props.indicatorsPosition === "right"
      },
      {
        "order-2": e.props.thumbnailsPosition === "top" || e.props.thumbnailsPosition === "left",
        "flex-row": e.props.thumbnailsPosition === "right"
      }
    ]
  }),
  items: ({ parent: e }) => ({
    class: [
      "flex h-full relative",
      {
        "order-1": e.props.indicatorsPosition === "bottom" || e.props.indicatorsPosition === "right",
        "order-2": e.props.indicatorsPosition === "top" || e.props.indicatorsPosition === "left"
      }
    ]
  }),
  item: {
    class: [
      // Flex
      "flex justify-center items-center h-full w-full",
      // Sizing
      "h-full w-full"
    ]
  },
  thumbnails: ({ parent: e }) => ({
    class: [
      // Flex
      "flex flex-col shrink-0",
      {
        "order-1": e.props.thumbnailsPosition === "top" || e.props.thumbnailsPosition === "left"
      },
      // Misc
      "overflow-auto"
    ]
  }),
  thumbnailContent: ({ parent: e }) => ({
    class: [
      // Flex
      "flex",
      // Spacing
      "py-4 px-1",
      // Colors
      "bg-black/90",
      {
        "flex-row": e.props.thumbnailsPosition === "top" || e.props.thumbnailsPosition === "bottom",
        "flex-col grow": e.props.thumbnailsPosition === "right" || e.props.thumbnailsPosition === "left"
      }
    ]
  }),
  thumbnailPrevButton: {
    class: [
      // Positioning
      "self-center relative",
      // Display & Flexbox
      "flex shrink-0 justify-center items-center overflow-hidden",
      // Spacing
      "m-2",
      // Appearance
      "bg-transparent text-white w-8 h-8 rounded-full transition duration-200 ease-in-out",
      // Hover Effects
      "hover:bg-surface-0/10 hover:text-white",
      // Focus Effects
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
    ]
  },
  thumbnailsViewport: {
    class: "overflow-hidden w-full"
  },
  thumbnailItems: ({ parent: e }) => ({
    class: [
      "flex",
      {
        "flex-col h-full": e.props.thumbnailsPosition === "right" || e.props.thumbnailsPosition === "left"
      }
    ]
  }),
  thumbnailItem: ({ parent: e }) => ({
    class: [
      // Flexbox
      "flex items-center justify-center",
      "grow shrink-0",
      // Sizing
      {
        "w-full md:w-[25%] lg:w-[20%]": e.props.thumbnailsPosition === "top" || e.props.thumbnailsPosition === "bottom"
      },
      // Misc
      "overflow-auto",
      "cursor-pointer",
      "opacity-50",
      // States
      '[&[data-p-active="true"]]:opacity-100',
      "hover:opacity-100",
      // Transitions
      "transition-opacity duration-300"
    ]
  }),
  thumbnailNextButton: {
    class: [
      // Positioning
      "self-center relative",
      // Display & Flexbox
      "flex shrink-0 justify-center items-center overflow-hidden",
      // Spacing
      "m-2",
      // Appearance
      "bg-transparent text-white w-8 h-8 rounded-full transition duration-200 ease-in-out",
      // Hover Effects
      "hover:bg-surface-0/10 hover:text-white",
      // Focus Effects
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
    ]
  },
  indicatorList: ({ parent: e }) => ({
    class: [
      // flex
      "flex items-center justify-center",
      // Spacing
      "p-4",
      // Indicators Position
      {
        "order-2": e.props.indicatorsPosition == "bottom",
        "order-1": e.props.indicatorsPosition == "top",
        "order-1 flex-col": e.props.indicatorsPosition == "left",
        "flex-col order-2": e.props.indicatorsPosition == "right"
      },
      {
        "absolute z-10 bg-black/50": e.props.showIndicatorsOnItem
      },
      {
        "bottom-0 left-0 w-full items-start": e.props.indicatorsPosition == "bottom" && e.props.showIndicatorsOnItem,
        "top-0 left-0 w-full items-start": e.props.indicatorsPosition == "top" && e.props.showIndicatorsOnItem,
        "left-0 top-0 h-full items-start": e.props.indicatorsPosition == "left" && e.props.showIndicatorsOnItem,
        "right-0 top-0 h-full items-start": e.props.indicatorsPosition == "right" && e.props.showIndicatorsOnItem
      }
    ]
  }),
  indicator: ({ parent: e }) => ({
    class: [
      {
        "mr-2": e.props.indicatorsPosition == "bottom" || e.props.indicatorsPosition == "top",
        "mb-2": e.props.indicatorsPosition == "left" || e.props.indicatorsPosition == "right"
      }
    ]
  }),
  indicatorButton: ({ context: e }) => ({
    class: [
      // Size
      "w-4 h-4",
      // Appearance
      "rounded-full transition duration-200",
      // Focus Effects
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Conditional Appearance: Not Highlighted
      { "bg-surface-200 hover:bg-surface-300 dark:bg-surface-700 dark:hover:bg-surface-600": !e.highlighted },
      // Conditional Appearance: Highlighted
      { "bg-primary hover:bg-primary-emphasis": e.highlighted }
    ]
  }),
  mask: {
    class: ["fixed top-0 left-0 w-full h-full", "flex items-center justify-center", "bg-black/90"]
  },
  closeButton: {
    class: [
      // Positioning
      "!absolute top-0 right-0",
      // Display & Flexbox
      "flex justify-center items-center overflow-hidden",
      // Spacing
      "m-2",
      // Appearance
      "text-white bg-transparent w-12 h-12 rounded-full transition duration-200 ease-in-out",
      // Hover Effect
      "hover:text-white hover:bg-surface-0/10",
      // Focus Effects
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
    ]
  },
  closeIcon: {
    class: "w-6 h-6"
  },
  prevButton: ({ parent: e }) => ({
    class: [
      // Display & Flexbox
      "inline-flex justify-center items-center overflow-hidden",
      // Appearance
      "bg-transparent text-white w-16 h-16 transition duration-200 ease-in-out rounded-md",
      {
        "opacity-0 group-hover:opacity-100": e.props.showItemNavigatorsOnHover
      },
      // Spacing
      "mx-2",
      // Positioning
      "top-1/2 mt-[-0.5rem] left-0",
      {
        "!absolute": !e.state.containerVisible && e.props.showItemNavigators,
        "!fixed": e.state.containerVisible
      },
      // Hover Effect
      "hover:bg-surface-0/10 hover:text-white",
      // Focus Effects
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
    ]
  }),
  nextButton: ({ parent: e }) => ({
    class: [
      // Display & Flexbox
      "inline-flex justify-center items-center overflow-hidden",
      // Appearance
      "bg-transparent text-white w-16 h-16 transition duration-200 ease-in-out rounded-md",
      {
        "opacity-0 group-hover:opacity-100": e.props.showItemNavigatorsOnHover
      },
      // Spacing
      "mx-2",
      // Positioning
      "top-1/2 mt-[-0.5rem] right-0",
      {
        "!absolute": !e.state.containerVisible && e.props.showItemNavigators,
        "!fixed": e.state.containerVisible
      },
      // Hover Effect
      "hover:bg-surface-0/10 hover:text-white",
      // Focus Effects
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400"
    ]
  }),
  caption: {
    class: [
      // Positioning
      "absolute bottom-0 left-0 w-full",
      // Appearance
      "bg-black/50 text-white p-4"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-75",
    enterActiveClass: "transition-all duration-150 ease-in-out",
    leaveActiveClass: "transition-all duration-150 ease-in",
    leaveToClass: "opacity-0 scale-75"
  }
}, di = {
  css: `
    *[data-pd-ripple="true"]{
        overflow: hidden;
        position: relative;
    }
    span[data-p-ink-active="true"]{
        animation: ripple 0.4s linear;
    }
    @keyframes ripple {
        100% {
            opacity: 0;
            transform: scale(2.5);
        }
    }

    .progress-spinner-circle {
        stroke-dasharray: 89, 200;
        stroke-dashoffset: 0;
        animation: p-progress-spinner-dash 1.5s ease-in-out infinite, p-progress-spinner-color 6s ease-in-out infinite;
        stroke-linecap: round;
    }

    @keyframes p-progress-spinner-dash{
        0% {
            stroke-dasharray: 1, 200;
            stroke-dashoffset: 0;
        }

        50% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -35px;
        }
        100% {
            stroke-dasharray: 89, 200;
            stroke-dashoffset: -124px;
        }
    }
    @keyframes p-progress-spinner-color {
        100%, 0% {
            stroke: #ff5757;
        }
        40% {
            stroke: #696cff;
        }
        66% {
            stroke: #1ea97c;
        }
        80%, 90% {
            stroke: #cc8925;
        }
    }

    .progressbar-value-animate::after {
        will-change: left, right;
        animation: p-progressbar-indeterminate-anim-short 2.1s cubic-bezier(0.165, 0.84, 0.44, 1) infinite;
    }
    .progressbar-value-animate::before {
        will-change: left, right;
        animation: p-progressbar-indeterminate-anim 2.1s cubic-bezier(0.65, 0.815, 0.735, 0.395) infinite;
    }
    @keyframes p-progressbar-indeterminate-anim {
        0% {
            left: -35%;
            right: 100%;
        }
        60% {
            left: 100%;
            right: -90%;
        }
        100% {
            left: 100%;
            right: -90%;
        }
    }

    .p-fadein {
        animation: p-fadein 250ms linear;
    }

    @keyframes p-fadein {
        0% {
            opacity: 0;
        }
        100% {
            opacity: 1;
        }
    }
`
}, fi = {
  root: {
    class: [
      "relative",
      "[&>[data-pc-name=inputicon]]:absolute",
      "[&>[data-pc-name=inputicon]]:top-1/2",
      "[&>[data-pc-name=inputicon]]:-mt-2",
      "[&>[data-pc-name=inputicon]]:text-surface-900/60 dark:[&>[data-pc-name=inputicon]]:text-white/60",
      "[&>[data-pc-name=inputicon]:first-child]:left-3",
      "[&>[data-pc-name=inputicon]:last-child]:right-3",
      "[&>[data-pc-name=inputtext]:first-child]:pr-10",
      "[&>[data-pc-name=inputtext]:last-child]:pl-10",
      // filter
      "[&>[data-pc-extend=inputicon]]:absolute",
      "[&>[data-pc-extend=inputicon]]:top-1/2",
      "[&>[data-pc-extend=inputicon]]:-mt-2",
      "[&>[data-pc-extend=inputicon]]:text-surface-900/60 dark:[&>[data-pc-extend=inputicon]]:text-white/60",
      "[&>[data-pc-extend=inputicon]:first-child]:left-3",
      "[&>[data-pc-extend=inputicon]:last-child]:right-3"
    ]
  }
}, pi = {
  root: {
    class: "relative inline-block"
  },
  previewMask: {
    class: [
      // Flexbox & Alignment
      "flex items-center justify-center",
      // Positioning
      "absolute",
      // Shape
      "inset-0 opacity-0 transition-opacity duration-300",
      // Color
      "bg-transparent text-surface-100",
      // States
      "hover:opacity-100 hover:cursor-pointer hover:bg-black/50 hover:bg-opacity-50"
    ]
  },
  mask: {
    class: [
      // Flexbox & Alignment
      "flex items-center justify-center",
      // Positioning
      "fixed top-0 left-0",
      // Sizing
      "w-full h-full",
      // Color
      "bg-black/90"
    ]
  },
  toolbar: {
    class: [
      // Flexbox
      "flex",
      // Positioning
      "absolute top-0 right-0",
      // Spacing
      "p-4"
    ]
  },
  rotateRightButton: {
    class: [
      "z-20",
      // Flexbox & Alignment
      "flex justify-center items-center",
      // Size
      "w-12 h-12",
      // Spacing
      "mr-2",
      // Shape
      "rounded-full",
      // Color
      "text-white bg-transparent",
      // States
      "hover:text-white hover:bg-surface-0/10",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transition
      "transition duration-200 ease-in-out"
    ]
  },
  rotateRightIcon: {
    class: "w-6 h-6"
  },
  rotateLeftButton: {
    class: [
      "z-20",
      // Flexbox & Alignment
      "flex justify-center items-center",
      // Size
      "w-12 h-12",
      // Spacing
      "mr-2",
      // Shape
      "rounded-full",
      // Color
      "text-white bg-transparent",
      // States
      "hover:text-white hover:bg-surface-0/10",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transition
      "transition duration-200 ease-in-out"
    ]
  },
  rotateLeftIcon: {
    class: "w-6 h-6"
  },
  zoomOutButton: {
    class: [
      "z-20",
      // Flexbox & Alignment
      "flex justify-center items-center",
      // Size
      "w-12 h-12",
      // Spacing
      "mr-2",
      // Shape
      "rounded-full",
      // Color
      "text-white bg-transparent",
      // States
      "hover:text-white hover:bg-surface-0/10",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transition
      "transition duration-200 ease-in-out"
    ]
  },
  zoomOutIcon: {
    class: "w-6 h-6"
  },
  zoomInButton: {
    class: [
      "z-20",
      // Flexbox & Alignment
      "flex justify-center items-center",
      // Size
      "w-12 h-12",
      // Spacing
      "mr-2",
      // Shape
      "rounded-full",
      // Color
      "text-white bg-transparent",
      // States
      "hover:text-white hover:bg-surface-0/10",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transition
      "transition duration-200 ease-in-out"
    ]
  },
  zoomInIcon: {
    class: "w-6 h-6"
  },
  closeButton: {
    class: [
      "z-20",
      // Flexbox & Alignment
      "flex justify-center items-center",
      // Size
      "w-12 h-12",
      // Spacing
      "mr-2",
      // Shape
      "rounded-full",
      // Color
      "text-white bg-transparent",
      // States
      "hover:text-white hover:bg-surface-0/10",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transition
      "transition duration-200 ease-in-out"
    ]
  },
  closeIcon: {
    class: "w-6 h-6"
  },
  transition: {
    enterFromClass: "opacity-0 scale-75",
    enterActiveClass: "transition-all duration-150 ease-in-out",
    leaveActiveClass: "transition-all duration-150 ease-in",
    leaveToClass: "opacity-0 scale-75"
  }
}, bi = {
  display: {
    class: [
      // Display
      "inline",
      // Spacing
      "px-3 py-2",
      // Shape
      "rounded-md",
      // Colors
      "text-surface-700 dark:text-white/80",
      // States
      "hover:bg-surface-100 hover:text-surface-700 dark:hover:bg-surface-800 dark:hover:text-white/80",
      // Transitions
      "transition",
      "duration-200",
      // Misc
      "cursor-pointer"
    ]
  }
}, gi = {
  root: {
    class: ["flex items-stretch", "w-full"]
  }
}, hi = {
  root: {
    class: [
      // Flex
      "flex items-center justify-center",
      // Shape
      "first:rounded-l-md",
      "last:rounded-r-md",
      "border-y",
      "last:border-r",
      "border-l",
      "border-r-0",
      // Space
      "p-2",
      // Size
      "min-w-[2.5rem]",
      // Color
      "bg-transparent dark:bg-surface-900",
      "text-surface-800 dark:text-white/80",
      "border-surface-300 dark:border-surface-700"
    ]
  }
}, mi = {
  pcinputtext: {
    root: ({ context: e, props: t, parent: r }) => {
      var n, o, a, s, i, l, c;
      return {
        class: [
          // Font
          "leading-none",
          // Spacing
          "m-0 py-2 px-3",
          // Colors
          "text-surface-800 dark:text-white/80",
          { "bg-surface-0 dark:bg-surface-950": !e.disabled },
          "border",
          { "border-surface-300 dark:border-surface-700": !t.invalid },
          // Invalid State
          "invalid:focus:ring-red-200",
          "invalid:hover:border-red-500",
          { "border-red-500 dark:border-red-400": t.invalid },
          // States
          {
            "hover:border-surface-400 dark:hover:border-surface-600": !e.disabled && !t.invalid,
            "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10": !e.disabled,
            "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled
          },
          // Filled State *for FloatLabel
          {
            filled: ((n = r.instance) == null ? void 0 : n.$name) == "FloatLabel" && e.filled || ((a = (o = r.instance) == null ? void 0 : o.$parentInstance) == null ? void 0 : a.$name) == "FloatLabel" && r.props.modelValue !== null && ((s = r.props.modelValue) == null ? void 0 : s.length) !== 0
          },
          ((i = r.instance) == null ? void 0 : i.$name) == "FloatLabel" || ((c = (l = r.instance) == null ? void 0 : l.$parentInstance) == null ? void 0 : c.$name) == "FloatLabel" ? "placeholder:text-transparent dark:placeholder:text-transparent" : "placeholder:text-surface-400 dark:placeholder:text-surface-500",
          // Misc
          "rounded-md",
          "appearance-none",
          "transition-colors duration-200"
        ]
      };
    }
  }
}, vi = {
  root: ({ props: e, parent: t }) => ({
    class: [
      // Flex
      "inline-flex",
      "relative",
      { "flex-col": e.showButtons && e.buttonLayout === "vertical" },
      { "flex-1 w-[1%]": t.instance.$name === "InputGroup" },
      { "w-full": e.fluid },
      // Shape
      { "first:rounded-l-md rounded-none last:rounded-r-md": t.instance.$name === "InputGroup" && !e.showButtons },
      { "border-0 border-y border-l last:border-r border-surface-300 dark:border-surface-700": t.instance.$name === "InputGroup" && !e.showButtons },
      { "first:ml-0 -ml-px": t.instance.$name === "InputGroup" && !e.showButtons },
      //Sizing
      { "!w-16": e.showButtons && e.buttonLayout == "vertical" }
    ]
  }),
  pcInput: {
    root: ({ parent: e, context: t }) => {
      var r, n, o;
      return {
        class: [
          // Font
          "leading-none",
          // Display
          "flex-auto",
          { "w-[1%]": e.props.fluid },
          //Text
          { "text-center": e.props.showButtons && e.props.buttonLayout == "vertical" },
          // Spacing
          "py-2 px-3",
          "m-0",
          // Shape
          "rounded-md",
          { "rounded-l-none rounded-r-none": e.props.showButtons && e.props.buttonLayout === "horizontal" },
          { "rounded-none": e.props.showButtons && e.props.buttonLayout === "vertical" },
          { "border-0": ((r = e.instance.$parentInstance) == null ? void 0 : r.$name) === "InputGroup" && !e.props.showButtons },
          // Colors
          "text-surface-800 dark:text-white/80",
          "placeholder:text-surface-400 dark:placeholder:text-surface-500",
          { "bg-surface-0 dark:bg-surface-950": !t.disabled },
          "border",
          { "border-surface-300 dark:border-surface-700": !e.props.invalid },
          // Invalid State
          "invalid:focus:ring-danger-400",
          "invalid:hover:border-danger-400",
          { "border-red-500 dark:border-red-400": e.props.invalid },
          // States
          { "hover:border-secondary-400": !e.props.invalid },
          "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-secondary-500 dark:focus:ring-secondary-400 focus:z-10",
          { "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": t.disabled },
          // Filled State *for FloatLabel
          { filled: ((o = (n = e.instance) == null ? void 0 : n.$parentInstance) == null ? void 0 : o.$name) === "FloatLabel" && e.state.d_modelValue !== null },
          //Position
          { "order-2": e.props.buttonLayout == "horizontal" || e.props.buttonLayout === "vertical" }
        ]
      };
    }
  },
  buttonGroup: ({ props: e }) => ({
    class: [
      "absolute",
      "z-20",
      // Flex
      "flex",
      "flex-col",
      "top-px right-px",
      { "h-[calc(100%-2px)]": e.showButtons && e.buttonLayout === "stacked" }
    ]
  }),
  incrementButton: ({ props: e }) => ({
    class: [
      // Display
      { "flex flex-initial shrink-0": e.showButtons && e.buttonLayout === "horizontal" },
      { "flex flex-auto": e.showButtons && e.buttonLayout === "stacked" },
      // Alignment
      "items-center",
      "justify-center",
      "text-center align-bottom",
      //Position
      "relative",
      { "order-3": e.showButtons && e.buttonLayout === "horizontal" },
      { "order-1": e.showButtons && e.buttonLayout === "vertical" },
      //Color
      "text-surface-800 dark:text-surface-0",
      "bg-transparent",
      { "dark:bg-surface-900": e.showButtons && e.buttonLayout !== "stacked" },
      "border border-surface-300 dark:border-surface-700",
      { "border-0": e.showButtons && e.buttonLayout === "stacked" },
      { "border-l-0": e.showButtons && e.buttonLayout !== "stacked" && e.buttonLayout === "horizontal" },
      { "border-b-0": e.showButtons && e.buttonLayout !== "stacked" && e.buttonLayout === "vertical" },
      // Sizing
      "w-[3rem]",
      { "px-3 py-2": e.showButtons && e.buttonLayout !== "stacked" },
      { "p-0": e.showButtons && e.buttonLayout === "stacked" },
      { "w-full": e.showButtons && e.buttonLayout === "vertical" },
      // Shape
      "rounded-md",
      { "rounded-md": e.showButtons && e.buttonLayout == "stacked" },
      { "rounded-bl-none rounded-tl-none": e.showButtons && e.buttonLayout === "horizontal" },
      { "rounded-bl-none rounded-br-none": e.showButtons && e.buttonLayout === "vertical" },
      //States
      "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
      //Misc
      "cursor-pointer overflow-hidden select-none"
    ]
  }),
  incrementIcon: "inline-block w-4 h-4",
  decrementButton: ({ props: e }) => ({
    class: [
      // Display
      { "flex flex-initial shrink-0": e.showButtons && e.buttonLayout === "horizontal" },
      { "flex flex-auto": e.showButtons && e.buttonLayout === "stacked" },
      // Alignment
      "items-center",
      "justify-center",
      "text-center align-bottom",
      //Position
      "relative",
      { "order-1": e.showButtons && e.buttonLayout === "horizontal" },
      { "order-3": e.showButtons && e.buttonLayout === "vertical" },
      //Color
      "text-surface-800 dark:text-surface-0",
      "bg-transparent",
      { "dark:bg-surface-900": e.showButtons && e.buttonLayout !== "stacked" },
      "border border-surface-300 dark:border-surface-700",
      { "border-0": e.showButtons && e.buttonLayout === "stacked" },
      { "border-r-0": e.showButtons && e.buttonLayout !== "stacked" && e.buttonLayout === "horizontal" },
      { "border-t-0": e.showButtons && e.buttonLayout !== "stacked" && e.buttonLayout === "vertical" },
      // Sizing
      "w-[3rem]",
      { "px-3 py-2": e.showButtons && e.buttonLayout !== "stacked" },
      { "p-0": e.showButtons && e.buttonLayout === "stacked" },
      { "w-full": e.showButtons && e.buttonLayout === "vertical" },
      // Shape
      "rounded-md",
      { "rounded-tr-none rounded-tl-none rounded-bl-none": e.showButtons && e.buttonLayout === "stacked" },
      { "rounded-tr-none rounded-br-none ": e.showButtons && e.buttonLayout === "horizontal" },
      { "rounded-tr-none rounded-tl-none ": e.showButtons && e.buttonLayout === "vertical" },
      //States
      "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
      //Misc
      "cursor-pointer overflow-hidden select-none"
    ]
  }),
  decrementIcon: "inline-block w-4 h-4"
}, xi = {
  root: {
    class: [
      // Alignment
      "flex items-center",
      "gap-2",
      "[&_[data-pc-name^=pcinput]]:w-10"
    ]
  }
}, yi = {
  root: ({ props: e, context: t, parent: r }) => {
    var n, o, a, s;
    return {
      class: [
        // Font
        "leading-none",
        // Flex
        { "flex-1 w-[1%]": r.instance.$name == "InputGroup" },
        // Spacing
        "m-0",
        { "w-full": e.fluid },
        // Size
        {
          "py-3 px-3.5": e.size == "large",
          "py-1.5 px-2": e.size == "small",
          "py-2 px-3": e.size == null
        },
        // Shape
        { "rounded-md": r.instance.$name !== "InputGroup" },
        { "first:rounded-l-md rounded-none last:rounded-r-md": r.instance.$name == "InputGroup" },
        { "border-0 border-y border-l last:border-r": r.instance.$name == "InputGroup" },
        { "first:ml-0 -ml-px": r.instance.$name == "InputGroup" && !e.showButtons },
        // Colors
        "text-surface-800 dark:text-white/80",
        "placeholder:text-surface-400 dark:placeholder:text-surface-500",
        { "bg-surface-0 dark:bg-surface-950": !t.disabled },
        "border",
        { "border-surface-300 dark:border-surface-700": !e.invalid },
        // Invalid State
        "invalid:focus:ring-danger-400",
        "invalid:hover:border-danger-400",
        { "border-danger-400 dark:border-danger-400": e.invalid },
        // States
        {
          "hover:border-surface-400 dark:hover:border-surface-600": !t.disabled && !e.invalid,
          "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-secondary-500 dark:focus:ring-secondary-400 focus:z-10": !t.disabled,
          "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": t.disabled
        },
        // Filled State *for FloatLabel
        { filled: ((n = r.instance) == null ? void 0 : n.$name) == "FloatLabel" && t.filled || ((a = (o = r.instance) == null ? void 0 : o.$parentInstance) == null ? void 0 : a.$name) == "FloatLabel" && r.props.modelValue !== null && ((s = r.props.modelValue) == null ? void 0 : s.length) !== 0 },
        // Misc
        "appearance-none",
        "transition-colors duration-200"
      ]
    };
  }
}, ki = {
  root: ({ props: e }) => ({
    class: [
      // Misc
      { "opacity-60 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  range: {
    class: [
      // Stroke
      "stroke-current",
      // Color
      "stroke-surface-200 dark:stroke-surface-700",
      // Fill
      "fill-none",
      // Transition
      "transition duration-100 ease-in"
    ]
  },
  value: {
    class: [
      // Animation
      "animate-dash-frame",
      // Color
      "stroke-primary",
      // Fill
      "fill-none"
    ]
  },
  text: {
    class: [
      // Text Style
      "text-center text-xl",
      // Color
      "fill-surface-600 dark:fill-surface-200"
    ]
  }
}, wi = {
  root: ({ props: e }) => ({
    class: [
      "rounded-md",
      // Colors
      { "bg-surface-0 dark:bg-surface-900": !e.disabled },
      "text-surface-700 dark:text-white/80",
      "border",
      { "border-surface-300 dark:border-surface-700": !e.invalid },
      // Disabled State
      { "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled },
      // Invalid State
      { "border-red-500 dark:border-red-400": e.invalid }
    ]
  }),
  listContainer: "overflow-auto",
  list: {
    class: "p-1 list-none m-0 outline-none"
  },
  option: ({ context: e, props: t }) => ({
    class: [
      "relative",
      // Flex
      "flex items-center",
      // Font
      "leading-none",
      // Spacing
      "m-0 px-3 py-2",
      "first:mt-0 mt-[2px]",
      // Shape
      "border-0 rounded",
      // Colors
      {
        "bg-surface-200 dark:bg-surface-600/60": e.focused && !e.selected,
        "text-surface-700 dark:text-white/80": e.focused && !e.selected,
        "bg-highlight": e.selected && !t.checkmark,
        "bg-surface-0 dark:bg-surface-900": t.checkmark && e.selected
      },
      //States
      { "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.focused && !e.selected || t.checkmark && e.selected },
      { "hover:bg-highlight-emphasis": e.selected && !t.checkmark },
      { "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": e.focused && !e.selected },
      // Transition
      "transition-shadow duration-200",
      // Misc
      "cursor-pointer overflow-hidden whitespace-nowrap"
    ]
  }),
  optionGroup: {
    class: [
      "font-semibold",
      // Spacing
      "m-0 py-2 px-3",
      // Colors
      "text-surface-400 dark:text-surface-500",
      // Misc
      "cursor-auto"
    ]
  },
  optionCheckIcon: "relative -ms-1.5 me-1.5 text-surface-700 dark:text-white/80 w-4 h-4",
  emptyMessage: {
    class: [
      // Font
      "leading-none",
      // Spacing
      "py-2 px-3",
      // Color
      "text-surface-800 dark:text-white/80",
      "bg-transparent"
    ]
  },
  header: {
    class: [
      // Spacing
      "pt-2 px-2 pb-0",
      "m-0",
      //Shape
      "border-b-0",
      "rounded-tl-md",
      "rounded-tr-md",
      // Color
      "text-surface-700 dark:text-white/80",
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-300 dark:border-surface-700",
      "[&_[data-pc-name=pcfilter]]:w-full"
    ]
  }
}, _i = {
  root: ({ props: e }) => ({
    class: [
      "relative",
      // Flexbox
      "flex",
      // Shape & Size
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border border-surface-200 dark:border-surface-700",
      { "p-2 items-center": e.orientation == "horizontal", "flex-col sm:w-48 p-1": e.orientation !== "horizontal" }
    ]
  }),
  rootList: ({ props: e }) => ({
    class: [
      // Flexbox
      "sm:flex",
      "items-center",
      "flex-wrap",
      "flex-col sm:flex-row",
      { hidden: !(e != null && e.mobileActive), flex: e == null ? void 0 : e.mobileActive },
      // Position
      "absolute sm:relative",
      "top-full left-0",
      "sm:top-auto sm:left-auto",
      // Size
      "w-full sm:w-auto",
      // Spacing
      "m-0",
      "p-1 sm:py-0 sm:p-0",
      "list-none",
      // Shape
      "shadow-md sm:shadow-none",
      "border-0",
      // Color
      "bg-surface-0 dark:bg-surface-900 sm:bg-transparent dark:sm:bg-transparent",
      // Misc
      "outline-none"
    ]
  }),
  item: ({ props: e }) => ({
    class: [
      "sm:relative static my-[2px] [&:first-child]:mt-0",
      {
        "sm:w-auto w-full": e.horizontal,
        "w-full": !e.horizontal
      }
    ]
  }),
  itemContent: ({ context: e }) => ({
    class: [
      "rounded-[4px]",
      //  Colors
      {
        "text-surface-500 dark:text-white/70": !e.focused && !e.active,
        "text-surface-500 dark:text-white/70 bg-surface-200 dark:bg-surface-600/90": e.focused && !e.active,
        "bg-highlight text-highlight-contrast": e.focused && e.active || e.active || !e.focused && e.active
      },
      // Hover States
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.active,
        "hover:bg-highlight-emphasis": e.active
      },
      // Transitions
      "transition-all",
      "duration-200"
    ]
  }),
  itemLink: {
    class: [
      "relative",
      // Flexbox
      "flex",
      "items-center",
      // Spacing
      "py-2",
      "px-3",
      // Size
      "leading-none",
      // Misc
      "select-none",
      "cursor-pointer",
      "no-underline ",
      "overflow-hidden"
    ]
  },
  itemIcon: {
    class: "mr-2"
  },
  submenuIcon: ({ props: e }) => ({
    class: [
      {
        "ml-auto sm:ml-2": e.horizontal,
        "ml-auto": !e.horizontal
      }
    ]
  }),
  overlay: ({ props: e }) => ({
    class: [
      // Size
      "w-auto",
      // Spacing
      "m-0",
      // Shape
      "shadow-none sm:shadow-md",
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      // Position
      "static sm:absolute",
      "z-10",
      {
        "sm:left-full top-0": !e.horizontal
      }
    ]
  }),
  grid: {
    class: "flex flex-wrap sm:flex-nowrap"
  },
  column: {
    class: "w-full sm:w-1/2"
  },
  submenu: {
    class: ["m-0 list-none", "p-1 px-2 w-full sm:min-w-[14rem]"]
  },
  submenuLabel: {
    class: [
      "font-semibold",
      // Spacing
      "py-2 px-3",
      "m-0",
      // Color
      "text-surface-400 dark:text-surface-500",
      "bg-surface-0 dark:bg-surface-900"
    ]
  },
  separator: {
    class: "border-t border-surface-200 dark:border-surface-600"
  },
  button: {
    class: [
      // Flexbox
      "flex sm:hidden",
      "items-center justify-center",
      // Size
      "w-7",
      "h-7",
      // Shape
      "rounded-full",
      // Color
      "text-surface-500 dark:text-white/80",
      // States
      "hover:text-surface-600 dark:hover:text-white/60",
      "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
      "focus:outline-none focus:outline-offset-0",
      "focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transitions
      "transition duration-200 ease-in-out",
      // Misc
      "cursor-pointer",
      "no-underline"
    ]
  },
  end: {
    class: "ml-auto self-center"
  }
}, Si = {
  root: {
    class: [
      // Sizing and Shape
      "min-w-[12.5rem]",
      "rounded-md",
      // Spacing
      "p-1",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      "border border-surface-200 dark:border-surface-700"
    ]
  },
  list: {
    class: [
      // Spacings and Shape
      "list-none",
      "m-0",
      "p-0",
      "outline-none"
    ]
  },
  item: {
    class: "relative my-[2px] [&:first-child]:mt-0"
  },
  separator: {
    class: "border-t border-surface-200 dark:border-surface-600"
  },
  itemContent: ({ context: e }) => ({
    class: [
      //Shape
      "rounded-[4px]",
      // Colors
      {
        "text-surface-500 dark:text-white/70": !e.focused && !e.active,
        "text-surface-500 dark:text-white/70 bg-surface-200 dark:bg-surface-600/90": e.focused && !e.active,
        "bg-highlight text-highlight-contrast": e.focused && e.active || e.active || !e.focused && e.active
      },
      // Transitions
      "transition-shadow",
      "duration-200",
      // States
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.active,
        "hover:bg-highlight-emphasis": e.active
      },
      // Disabled
      { "opacity-60 pointer-events-none cursor-default": e.disabled }
    ]
  }),
  itemLink: {
    class: [
      "relative",
      // Flexbox
      "flex",
      "items-center",
      // Spacing
      "py-2",
      "px-3",
      // Misc
      "no-underline",
      "overflow-hidden",
      "cursor-pointer",
      "select-none"
    ]
  },
  itemIcon: {
    class: [
      // Spacing
      "mr-2"
    ]
  },
  itemLabel: {
    class: ["leading-[normal]"]
  },
  submenuLabel: {
    class: [
      // Font
      "font-bold",
      // Spacing
      "m-0",
      "py-2 px-3",
      // Shape
      "rounded-tl-none",
      "rounded-tr-none",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-400 dark:text-surface-600"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Ci = {
  root: {
    class: [
      "relative",
      // Flexbox
      "flex",
      "items-center",
      // Spacing
      "p-2",
      // Shape
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-800",
      "border border-surface-200 dark:border-none"
    ]
  },
  rootList: ({ props: e }) => ({
    class: [
      // Flexbox
      "sm:flex",
      "items-center",
      "flex-wrap",
      "flex-col sm:flex-row",
      { hidden: !(e != null && e.mobileActive), flex: e == null ? void 0 : e.mobileActive },
      // Position
      "absolute sm:relative",
      "top-full left-0",
      "sm:top-auto sm:left-auto",
      // Size
      "w-full sm:w-auto",
      // Spacing
      "m-0",
      "p-1 sm:py-0 sm:p-0",
      "list-none",
      // Shape
      "shadow-md sm:shadow-none",
      "border-0",
      // Color
      "bg-surface-0 dark:bg-surface-800 sm:bg-transparent",
      // Misc
      "outline-none"
    ]
  }),
  item: {
    class: "sm:relative sm:w-auto w-full static my-[2px] [&:first-child]:mt-0"
  },
  itemContent: ({ context: e }) => ({
    class: [
      // Shape
      "rounded-[4px]",
      // Colors
      {
        "text-surface-500 dark:text-white/70": !e.focused && !e.active,
        "text-surface-500 dark:text-white/70 bg-surface-200 dark:bg-surface-600/90": e.focused && !e.active,
        "bg-highlight text-highlight-contrast": e.focused && e.active || e.active || !e.focused && e.active
      },
      // States
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.active,
        "hover:bg-highlight-emphasis": e.active
      },
      // Disabled State
      { "opacity-60 pointer-events-none cursor-default": e.disabled },
      // Transitions
      "transition-all",
      "duration-200"
    ]
  }),
  itemLink: ({ context: e }) => ({
    class: [
      "relative",
      // Flexbox
      "flex",
      "items-center",
      // Spacing
      "py-2",
      "px-3",
      // Size
      {
        "pl-9 sm:pl-5": e.level === 1,
        "pl-14 sm:pl-5": e.level === 2
      },
      "leading-none",
      // Misc
      "select-none",
      "cursor-pointer",
      "no-underline ",
      "overflow-hidden"
    ]
  }),
  itemIcon: {
    class: "mr-2"
  },
  submenuIcon: ({ props: e }) => ({
    class: [
      {
        "ml-auto sm:ml-2": e.root,
        "ml-auto": !e.root
      }
    ]
  }),
  submenu: ({ props: e }) => ({
    class: [
      "flex flex-col",
      // Size
      "rounded-md",
      "min-w-[12.5rem]",
      // Spacing
      "p-1",
      "m-0",
      "list-none",
      // Shape
      "shadow-none sm:shadow-md",
      "border border-surface-200 dark:border-surface-700",
      // Position
      "static sm:absolute",
      "z-10",
      { "sm:absolute sm:left-full sm:top-0": e.level > 1 },
      // Color
      "bg-surface-0 dark:bg-surface-900"
    ]
  }),
  separator: {
    class: "border-t border-surface-200 dark:border-surface-600"
  },
  button: {
    class: [
      // Flexbox
      "flex sm:hidden",
      "items-center justify-center",
      // Size
      "w-7",
      "h-7",
      // Shape
      "rounded-full",
      // Color
      "text-surface-500 dark:text-white/80",
      // States
      "hover:text-surface-600 dark:hover:text-white/60",
      "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
      "focus:outline-none focus:outline-offset-0",
      "focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transitions
      "transition duration-200 ease-in-out",
      // Misc
      "cursor-pointer",
      "no-underline"
    ]
  },
  end: {
    class: "ml-auto self-center"
  }
}, $i = {
  root: ({ props: e }) => ({
    class: [
      // Spacing and Shape
      "rounded-md",
      "outline",
      // Colors
      {
        "bg-blue-100/70 dark:bg-blue-500/20": e.severity == "info",
        "bg-green-100/70 dark:bg-green-500/20": e.severity == "success",
        "bg-surface-100/70 dark:bg-surface-500/20": e.severity == "secondary",
        "bg-orange-100/70 dark:bg-orange-500/20": e.severity == "warn",
        "bg-red-100/70 dark:bg-red-500/20": e.severity == "error",
        "bg-surface-950 dark:bg-surface-0": e.severity == "contrast"
      },
      {
        "outline-blue-200 dark:outline-blue-500/20": e.severity == "info",
        "outline-green-200 dark:outline-green-500/20": e.severity == "success",
        "outline-surface-200 dark:outline-surface-500/20": e.severity == "secondary",
        "outline-orange-200 dark:outline-orange-500/20": e.severity == "warn",
        "outline-red-200 dark:outline-red-500/20": e.severity == "error",
        "outline-surface-950 dark:outline-surface-0": e.severity == "contrast"
      },
      {
        "text-blue-700 dark:text-blue-300": e.severity == "info",
        "text-green-700 dark:text-green-300": e.severity == "success",
        "text-surface-700 dark:text-surface-300": e.severity == "secondary",
        "text-orange-700 dark:text-orange-300": e.severity == "warn",
        "text-red-700 dark:text-red-300": e.severity == "error",
        "text-surface-0 dark:text-surface-950": e.severity == "contrast"
      }
    ]
  }),
  content: {
    class: [
      // Flexbox
      "flex items-center h-full",
      // Spacing
      "py-2 px-3 gap-2"
    ]
  },
  icon: {
    class: [
      // Sizing and Spacing
      "shrink-0 w-[1.125rem] h-[1.125rem]"
    ]
  },
  text: {
    class: [
      // Font and Text
      "text-base leading-[normal]",
      "font-medium"
    ]
  },
  closeButton: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex items-center justify-center",
      // Size
      "w-7 h-7",
      // Spacing and Misc
      "ml-auto relative",
      // Shape
      "rounded-full",
      // Colors
      "bg-transparent",
      // Transitions
      "transition duration-200 ease-in-out",
      // States
      "hover:bg-surface-0/30 dark:hover:bg-[rgba(255,255,255,0.03)]",
      "focus:outline-none focus:outline-offset-0 focus:ring-1",
      {
        "focus:ring-blue-500 dark:focus:ring-blue-400": e.severity == "info",
        "focus:ring-green-500 dark:focus:ring-green-400": e.severity == "success",
        "focus:ring-surface-500 dark:focus:ring-surface-400": e.severity == "secondary",
        "focus:ring-orange-500 dark:focus:ring-orange-400": e.severity == "warn",
        "focus:ring-red-500 dark:focus:ring-red-4000": e.severity == "error",
        "focus:ring-surface-0 dark:focus:ring-surface-950": e.severity == "contrast"
      },
      // Misc
      "overflow-hidden"
    ]
  }),
  transition: {
    enterFromClass: "opacity-0",
    enterActiveClass: "transition-opacity duration-300",
    leaveFromClass: "max-h-40",
    leaveActiveClass: "overflow-hidden transition-all duration-300 ease-in",
    leaveToClass: "max-h-0 opacity-0 !m-0"
  }
}, Ti = {
  root: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex gap-4",
      { "flex-col": e.orientation == "horizontal", "flex-row": e.orientation == "vertical" }
    ]
  }),
  meters: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex",
      { "flex-col": e.orientation === "vertical" },
      // Sizing
      { "w-2 h-full": e.orientation === "vertical" },
      { "h-2": e.orientation === "horizontal" },
      // Colors
      "bg-gray-200 dark:bg-gray-700",
      // Border Radius
      "rounded-lg"
    ]
  }),
  meter: ({ props: e }) => ({
    class: [
      // Shape
      "border-0",
      // Rounded Corners - Horizontal
      {
        "first:rounded-l-lg last:rounded-r-lg": e.orientation === "horizontal"
      },
      // Rounded Corners - Vertical
      {
        "first:rounded-t-lg last:rounded-b-lg": e.orientation === "vertical"
      },
      // Colors
      "bg-primary"
    ]
  }),
  labelList: ({ props: e }) => ({
    class: [
      // Display & Flexbox
      "flex flex-wrap",
      { "gap-4": e.labelOrientation === "horizontal" },
      { "gap-2": e.labelOrientation === "vertical" },
      { "flex-col": e.labelOrientation === "vertical" },
      // Conditional Alignment - Horizontal
      {
        "align-end": e.labelOrientation === "horizontal" && e.labelPosition === "end",
        "align-start": e.labelOrientation === "horizontal" && e.labelPosition === "start"
      },
      // Conditional Alignment - Vertical
      {
        "justify-start": e.labelOrientation === "vertical" && e.labelPosition === "start"
      },
      // List Styling
      "m-0 p-0 list-none"
    ]
  }),
  label: {
    class: [
      // Flexbox
      "inline-flex",
      "items-center",
      "gap-2"
    ]
  },
  labelMarker: {
    class: [
      // Display
      "inline-flex",
      // Background Color
      "bg-primary",
      // Size
      "w-2 h-2",
      // Rounded Shape
      "rounded-full"
    ]
  }
}, Pi = {
  root: ({ props: e, state: t }) => ({
    class: [
      // Font
      "leading-none",
      // Display and Position
      "inline-flex",
      "relative",
      // Shape
      "rounded-md",
      // Color and Background
      { "bg-surface-0 dark:bg-surface-950": !e.disabled },
      "border",
      { "border-surface-300 dark:border-surface-600": !e.invalid },
      // Invalid State
      "invalid:focus:ring-red-200",
      "invalid:hover:border-red-500",
      { "border-red-500 dark:border-red-400": e.invalid },
      // Transitions
      "transition-all",
      "duration-200",
      // States
      { "hover:border-surface-400 dark:hover:border-surface-700": !e.invalid },
      { "outline-none outline-offset-0 z-10 ring-1 ring-primary-500 dark:ring-primary-400": t.focused },
      // Misc
      "cursor-pointer",
      "select-none",
      { "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  labelContainer: "overflow-hidden flex flex-auto cursor-pointer",
  label: ({ props: e, parent: t }) => {
    var r, n, o, a, s, i, l, c;
    return {
      class: [
        "text-base leading-2",
        // Spacing
        {
          "py-2 px-3": e.display === "comma" || e.display === "chip" && !((r = e == null ? void 0 : e.modelValue) != null && r.length),
          "py-1 px-1": e.display === "chip" && ((n = e == null ? void 0 : e.modelValue) == null ? void 0 : n.length) > 0
        },
        // Color
        { "text-surface-800 dark:text-white/80": (o = e.modelValue) == null ? void 0 : o.length, "text-surface-400 dark:text-surface-500": !((a = e.modelValue) != null && a.length) },
        {
          "placeholder:text-transparent dark:placeholder:text-transparent": ((s = t.instance) == null ? void 0 : s.$name) == "FloatLabel",
          "!text-transparent dark:!text-transparent": ((i = t.instance) == null ? void 0 : i.$name) == "FloatLabel" && e.modelValue == null || ((l = e.modelValue) == null ? void 0 : l.length) == 0
        },
        // Filled State *for FloatLabel
        { filled: ((c = t.instance) == null ? void 0 : c.$name) == "FloatLabel" && e.modelValue !== null },
        // Transitions
        "transition duration-200",
        // Misc
        "overflow-hidden whitespace-nowrap cursor-pointer overflow-ellipsis"
      ]
    };
  },
  dropdown: {
    class: [
      // Flexbox
      "flex items-center justify-center",
      "shrink-0",
      // Color and Background
      "bg-transparent",
      "text-surface-500",
      // Size
      "w-12",
      // Shape
      "rounded-r-md"
    ]
  },
  overlay: {
    class: [
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      // Shape
      "border border-surface-300 dark:border-surface-700",
      "rounded-md",
      "shadow-md",
      "mt-[2px]"
    ]
  },
  header: {
    class: [
      //Flex
      "flex items-center justify-between",
      // Spacing
      "pt-2 px-4 pb-0 gap-2",
      "m-0",
      //Shape
      "border-b-0",
      "rounded-tl-md",
      "rounded-tr-md",
      // Color
      "text-surface-700 dark:text-white/80",
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-300 dark:border-surface-700",
      "[&_[data-pc-name=pcfiltercontainer]]:!flex-auto",
      "[&_[data-pc-name=pcfilter]]:w-full"
    ]
  },
  listContainer: {
    class: [
      // Sizing
      "max-h-[200px]",
      // Misc
      "overflow-auto"
    ]
  },
  list: {
    class: "p-1 list-none m-0"
  },
  option: ({ context: e }) => ({
    class: [
      "relative",
      "flex items-center",
      // Font
      "leading-none",
      // Spacing
      "m-0 px-3 py-2 gap-2",
      "first:mt-0 mt-[2px]",
      // Shape
      "border-0 rounded",
      // Colors
      {
        "bg-surface-200 dark:bg-surface-600/60": e.focused && !e.selected,
        "text-surface-700 dark:text-white/80": e.focused && !e.selected,
        "bg-highlight": e.selected
      },
      //States
      { "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.focused && !e.selected },
      { "hover:bg-highlight-emphasis": e.selected },
      { "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": e.focused && !e.selected },
      // Transition
      "transition-shadow duration-200",
      // Misc
      "cursor-pointer overflow-hidden whitespace-nowrap"
    ]
  }),
  optionGroup: {
    class: [
      "font-semibold",
      // Spacing
      "m-0 py-2 px-3",
      // Colors
      "text-surface-400 dark:text-surface-500",
      // Misc
      "cursor-auto"
    ]
  },
  emptyMessage: {
    class: [
      // Font
      "leading-none",
      // Spacing
      "py-2 px-3",
      // Color
      "text-surface-800 dark:text-white/80",
      "bg-transparent"
    ]
  },
  loadingIcon: {
    class: "text-surface-400 dark:text-surface-500 animate-spin"
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Oi = {
  root: "flex",
  controls: {
    class: [
      // Flexbox & Alignment
      "flex xl:flex-col justify-center gap-2",
      // Spacing
      "p-[1.125rem]"
    ]
  },
  container: {
    class: [
      "flex-auto",
      // Shape
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border border-surface-200 dark:border-surface-700",
      "outline-none"
    ]
  }
}, ji = {
  table: {
    class: [
      // Spacing & Position
      "mx-auto my-0",
      // Table Style
      "border-spacing-0 border-separate"
    ]
  },
  cell: {
    class: [
      // Alignment
      "text-center align-top",
      // Spacing
      "py-0 px-3"
    ]
  },
  node: ({ context: e }) => ({
    class: [
      "relative inline-block",
      // Spacing
      "py-3 px-4",
      // Shape
      "border",
      "rounded-md",
      "border-surface-200 dark:border-surface-700",
      // Color
      {
        "text-surface-600 dark:text-white/80": !(e != null && e.selected),
        "bg-surface-0 dark:bg-surface-900": !(e != null && e.selected),
        "bg-highlight": e == null ? void 0 : e.selected
      },
      // States
      {
        "hover:bg-surface-100 dark:hover:bg-surface-800": (e == null ? void 0 : e.selectable) && !(e != null && e.selected),
        "hover:bg-highlight-emphasis": (e == null ? void 0 : e.selectable) && (e == null ? void 0 : e.selected)
      },
      { "cursor-pointer": e == null ? void 0 : e.selectable }
    ]
  }),
  lineCell: {
    class: [
      // Alignment
      "text-center align-top",
      // Spacing
      "py-0 px-3"
    ]
  },
  connectorDown: {
    class: [
      // Spacing
      "mx-auto my-0",
      // Size
      "w-px h-[20px]",
      // Color
      "bg-surface-200 dark:bg-surface-700"
    ]
  },
  connectorLeft: ({ context: e }) => ({
    class: [
      // Alignment
      "text-center align-top",
      // Spacing
      "py-0 px-3",
      // Shape
      "rounded-none border-r",
      { "border-t": e.lineTop },
      // Color
      "border-surface-200 dark:border-surface-700"
    ]
  }),
  connectorRight: ({ context: e }) => ({
    class: [
      // Alignment
      "text-center align-top",
      // Spacing
      "py-0 px-3",
      // Shape
      "rounded-none",
      // Color
      { "border-t border-surface-200 dark:border-surface-700": e.lineTop }
    ]
  }),
  nodeCell: {
    class: "text-center align-top py-0 px-3"
  },
  nodeToggleButton: {
    class: [
      // Position
      "absolute bottom-[-0.75rem] left-2/4 -ml-3",
      "z-20",
      // Flexbox
      "flex items-center justify-center",
      // Size
      "w-6 h-6",
      // Shape
      "rounded-full",
      "border border-surface-200 dark:border-surface-700",
      // Color
      "bg-inherit text-inherit",
      // Focus
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Misc
      "cursor-pointer no-underline select-none"
    ]
  },
  nodeToggleButtonIcon: {
    class: [
      // Position
      "static inline-block",
      // Size
      "w-4 h-4"
    ]
  }
}, Ii = {
  root: {
    class: [
      "relative",
      "[&>[data-pc-name=pcbadge]]:absolute",
      "[&>[data-pc-name=pcbadge]]:top-0",
      "[&>[data-pc-name=pcbadge]]:right-0",
      "[&>[data-pc-name=pcbadge]]:translate-x-1/2",
      "[&>[data-pc-name=pcbadge]]:-translate-y-1/2",
      "[&>[data-pc-name=pcbadge]]:m-0",
      "[&>[data-pc-name=pcbadge]]:origin-[100%_0]",
      "[&>[data-pc-name=pcbadge]]:outline",
      "[&>[data-pc-name=pcbadge]]:outline-[2px]",
      "[&>[data-pc-name=pcbadge]]:outline-surface-0",
      "dark:[&>[data-pc-name=pcbadge]]:outline-surface-900"
    ]
  }
}, Ai = {
  root: {
    class: [
      // Flex & Alignment
      "flex items-center justify-center flex-wrap",
      // Spacing
      "px-4 py-2",
      // Shape
      "border-0 rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-500 dark:text-white/60"
    ]
  },
  first: ({ context: e }) => ({
    class: [
      "relative",
      // Flex & Alignment
      "inline-flex items-center justify-center",
      // Shape
      "border-0 rounded-full",
      // Size
      "min-w-[2.5rem] h-10 m-[0.143rem]",
      "leading-none",
      // Color
      "text-surface-500 dark:text-white/60",
      // State
      {
        "hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.disabled,
        "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !e.disabled
      },
      // Transition
      "transition duration-200",
      // Misc
      "user-none overflow-hidden",
      { "cursor-default pointer-events-none opacity-60": e.disabled }
    ]
  }),
  prev: ({ context: e }) => ({
    class: [
      "relative",
      // Flex & Alignment
      "inline-flex items-center justify-center",
      // Shape
      "border-0 rounded-full",
      // Size
      "min-w-[2.5rem] h-10 m-[0.143rem]",
      "leading-none",
      // Color
      "text-surface-500 dark:text-white/60",
      // State
      {
        "hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.disabled,
        "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !e.disabled
      },
      // Transition
      "transition duration-200",
      // Misc
      "user-none overflow-hidden",
      { "cursor-default pointer-events-none opacity-60": e.disabled }
    ]
  }),
  next: ({ context: e }) => ({
    class: [
      "relative",
      // Flex & Alignment
      "inline-flex items-center justify-center",
      // Shape
      "border-0 rounded-full",
      // Size
      "min-w-[2.5rem] h-10 m-[0.143rem]",
      "leading-none",
      // Color
      "text-surface-500 dark:text-white/60",
      // State
      {
        "hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.disabled,
        "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !e.disabled
      },
      // Transition
      "transition duration-200",
      // Misc
      "user-none overflow-hidden",
      { "cursor-default pointer-events-none opacity-60": e.disabled }
    ]
  }),
  last: ({ context: e }) => ({
    class: [
      "relative",
      // Flex & Alignment
      "inline-flex items-center justify-center",
      // Shape
      "border-0 rounded-full",
      // Size
      "min-w-[2.5rem] h-10 m-[0.143rem]",
      "leading-none",
      // Color
      "text-surface-500 dark:text-white/60",
      // State
      {
        "hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.disabled,
        "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !e.disabled
      },
      // Transition
      "transition duration-200",
      // Misc
      "user-none overflow-hidden",
      { "cursor-default pointer-events-none opacity-60": e.disabled }
    ]
  }),
  page: ({ context: e }) => ({
    class: [
      "relative",
      // Flex & Alignment
      "inline-flex items-center justify-center",
      // Shape
      "border-0 rounded-full",
      // Size
      "min-w-[2.5rem] h-10 m-[0.143rem]",
      "leading-none",
      // Color
      {
        "bg-highlight text-highlight-contrast border-highlight text-highlight-contrast hover:bg-highlight-emphasis ": e.active,
        "text-surface-500 dark:text-white/60": !e.active
      },
      // State
      {
        "hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.disabled && !e.active,
        "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400": !e.disabled
      },
      // Transition
      "transition duration-200",
      // Misc
      "user-none overflow-hidden",
      { "cursor-default pointer-events-none opacity-60": e.disabled }
    ]
  }),
  contentStart: "mr-auto",
  contentEnd: "ml-auto"
}, zi = {
  root: {
    class: [
      //Shape
      "rounded-md",
      //Colors
      "border border-surface-200 dark:border-surface-700",
      "bg-surface-0 dark:bg-surface-900"
    ]
  },
  header: ({ props: e }) => ({
    class: [
      // Flex
      "flex items-center justify-between",
      // Colors
      "text-surface-700 dark:text-surface-0/80",
      "bg-transparent",
      //Shape
      "rounded-tl-md rounded-tr-md",
      "border-0",
      // Conditional Spacing
      { "p-[1.125rem]": !e.toggleable, "py-3 px-[1.125rem]": e.toggleable }
    ]
  }),
  title: {
    class: "leading-none font-semibold"
  },
  pctogglebutton: {
    root: {
      class: [
        // Positioning
        "relative",
        // Flexbox alignment
        "inline-flex items-center justify-center text-center",
        // Line height
        "leading-[normal]",
        // Size
        "w-10 h-10 px-0 py-2",
        // Shape
        "rounded-[50%] rounded-full",
        // Background and border
        "bg-transparent border-transparent",
        // Text color
        "text-surface-500 dark:text-surface-300",
        // Focus states
        "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-surface-500 dark:focus:ring-surface-400",
        // Hover effect
        "hover:bg-surface-300/10",
        // Transition effects
        "transition duration-200 ease-in-out",
        // Cursor and overflow
        "cursor-pointer overflow-hidden select-none"
      ]
    }
  },
  content: {
    class: [
      // Spacing
      "p-[1.125rem] pt-0",
      // Shape
      "border-0 border-t-0 last:rounded-br-md last:rounded-bl-md",
      //Color
      "text-surface-700 dark:text-surface-0/80"
    ]
  },
  footer: {
    class: [
      // Spacing
      "p-[1.125rem] pt-0",
      // Shape
      "border-0 border-t-0 rounded-br-lg rounded-bl-lg",
      //Color
      "text-surface-700 dark:text-surface-0/80"
    ]
  },
  transition: {
    enterFromClass: "max-h-0",
    enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
    enterToClass: "max-h-[1000px]",
    leaveFromClass: "max-h-[1000px]",
    leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
    leaveToClass: "max-h-0"
  }
}, Li = {
  panel: {
    class: "p-1 overflow-hidden mb-3 border border-surface-200 dark:border-surface-700 rounded-md"
  },
  header: {
    class: ["rounded-[4px]", "outline-none"]
  },
  headerContent: ({ context: e }) => ({
    class: [
      // Shape
      "rounded-[4px]",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-600 dark:text-surface-0/80",
      { "text-surface-900": e.active },
      // States
      "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]",
      "hover:text-surface-900",
      // Transition
      "transition duration-200 ease-in-out",
      "transition-shadow duration-200"
    ]
  }),
  headerLink: {
    class: [
      "relative",
      // Font
      "font-semibold",
      "leading-none",
      // Flex & Alignments
      "flex items-center",
      // Spacing
      "py-2 px-3",
      // Misc
      "select-none cursor-pointer no-underline"
    ]
  },
  headerLabel: {
    class: "leading-none"
  },
  headerIcon: {
    class: "mr-2"
  },
  submenuIcon: {
    class: "mr-2"
  },
  content: {
    class: [
      // Spacing
      "pl-4",
      // Color
      "text-surface-700 dark:text-white/80",
      "bg-surface-0 dark:bg-surface-900"
    ]
  },
  rootList: {
    class: ["outline-none", "m-0 p-0 list-none"]
  },
  menuitem: {
    class: "relative my-[2px]"
  },
  itemContent: {
    class: [
      // Shape
      "border-none rounded-[4px]",
      // Color
      "text-surface-700 dark:text-white/80",
      // Transition
      "transition-shadow duration-200"
    ]
  },
  itemLink: ({ context: e }) => ({
    class: [
      "relative",
      // Font
      "leading-none",
      // Flex & Alignments
      "flex items-center",
      // Spacing
      "py-2 px-3",
      // Shape
      "rounded-[4px]",
      // Color
      "text-surface-700 dark:text-white/80",
      // States
      "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)] hover:text-surface-700 dark:hover:text-white/80",
      {
        "bg-surface-200 text-surface-700 dark:text-white/80 dark:bg-surface-0/10": e.focused
      },
      // Misc
      "cursor-pointer no-underline",
      "select-none overflow-hidden"
    ]
  }),
  itemIcon: {
    class: "mr-2"
  },
  submenu: {
    class: "p-0 pl-4 m-0 list-none"
  },
  transition: {
    enterFromClass: "max-h-0",
    enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
    enterToClass: "max-h-[1000px]",
    leaveFromClass: "max-h-[1000px]",
    leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
    leaveToClass: "max-h-0"
  }
}, Ei = {
  root: ({ props: e }) => ({
    class: ["relative [&>input]:w-full", { "[&>input]:pr-10": e.toggleMask }, { "flex [&>input]:w-full": e.fluid, "inline-flex": !e.fluid }]
  }),
  overlay: {
    class: [
      // Spacing
      "p-3",
      // Shape
      "border",
      "shadow-md rounded-md",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      "border-surface-200 dark:border-surface-700"
    ]
  },
  meter: {
    class: [
      // Position and Overflow
      "overflow-hidden",
      "relative",
      // Shape and Size
      "border-0",
      "h-[10px]",
      "rounded-md",
      // Spacing
      "mb-3",
      // Colors
      "bg-surface-100 dark:bg-surface-700"
    ]
  },
  meterLabel: ({ instance: e }) => {
    var t, r, n;
    return {
      class: [
        // Size
        "h-full",
        // Colors
        {
          "bg-red-500 dark:bg-red-400/50": ((t = e == null ? void 0 : e.meter) == null ? void 0 : t.strength) == "weak",
          "bg-orange-500 dark:bg-orange-400/50": ((r = e == null ? void 0 : e.meter) == null ? void 0 : r.strength) == "medium",
          "bg-green-500 dark:bg-green-400/50": ((n = e == null ? void 0 : e.meter) == null ? void 0 : n.strength) == "strong"
        },
        // Transitions
        "transition-all duration-1000 ease-in-out"
      ]
    };
  },
  maskIcon: {
    class: ["absolute top-1/2 right-3 -mt-2 z-10", "text-surface-600 dark:text-white/70"]
  },
  unmaskIcon: {
    class: ["absolute top-1/2 right-3 -mt-2 z-10", "text-surface-600 dark:text-white/70"]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Ni = {
  root: "flex [&_[data-pc-name=pclist]]:h-full",
  sourceControls: {
    class: [
      // Flexbox & Alignment
      "flex xl:flex-col justify-center gap-2",
      // Spacing
      "p-[1.125rem]"
    ]
  },
  sourceListContainer: {
    class: [
      // Flexbox
      "grow shrink basis-2/4",
      // Shape
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border border-surface-200 dark:border-surface-700",
      "outline-none"
    ]
  },
  transferControls: {
    class: [
      // Flexbox & Alignment
      "flex xl:flex-col justify-center gap-2",
      // Spacing
      "p-[1.125rem]"
    ]
  },
  targetListContainer: {
    class: [
      // Flexbox
      "grow shrink basis-2/4",
      // Shape
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border border-surface-200 dark:border-surface-700",
      "outline-none"
    ]
  },
  targetControls: {
    class: [
      // Flexbox & Alignment
      "flex xl:flex-col justify-center gap-2",
      // Spacing
      "p-[1.125rem]"
    ]
  },
  transition: {
    enterFromClass: "!transition-none",
    enterActiveClass: "!transition-none",
    leaveActiveClass: "!transition-none",
    leaveToClass: "!transition-none"
  }
}, Xn = {
  root: {
    class: [
      // Shape
      "rounded-md shadow-lg",
      // Position
      "absolute left-0 top-0 mt-3",
      '[&[data-p-popover-flipped="true"]]:mb-3 [&[data-p-popover-flipped="true"]]:-mt-3',
      "z-40 transform origin-center",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-surface-0/80",
      // Before: Arrow
      "before:absolute before:w-0 before:-top-3 before:h-0 before:border-transparent before:border-solid before:ml-[10px] before:border-x-[10px] before:border-b-[10px] before:border-t-0 before:border-b-surface-200 dark:before:border-b-surface-700",
      "after:absolute after:w-0 after:-top-[0.54rem] after:left-[4px] after:h-0 after:border-transparent after:border-solid after:ml-[8px] after:border-x-[8px] after:border-b-[8px] after:border-t-0 after:border-b-surface-0 dark:after:border-b-surface-900",
      // Flipped: Arrow
      '[&[data-p-popover-flipped="true"]]:before:-bottom-3 [&[data-p-popover-flipped="true"]]:before:top-auto [&[data-p-popover-flipped="true"]]:before:border-b-0 [&[data-p-popover-flipped="true"]]:before:border-t-[10px] [&[data-p-popover-flipped="true"]]:before:border-t-surface-200 dark:[&[data-p-popover-flipped="true"]]:before:border-t-surface-700',
      '[&[data-p-popover-flipped="true"]]:after:-bottom-[0.54rem] [&[data-p-popover-flipped="true"]]:after:top-auto [&[data-p-popover-flipped="true"]]:after:border-b-0 [&[data-p-popover-flipped="true"]]:after:border-t-[8px] [&[data-p-popover-flipped="true"]]:after:border-t-surface-0 dark:[&[data-p-popover-flipped="true"]]:after:border-t-surface-900'
    ]
  },
  content: {
    class: ["p-5 items-center flex", "rounded-lg", "border border-surface-200 dark:border-surface-700"]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Ri = {
  root: {
    class: [
      // Position and Overflow
      "overflow-hidden",
      "relative",
      // Shape and Size
      "border-0",
      "h-5",
      "rounded-md",
      // Colors
      "bg-surface-100 dark:bg-surface-800"
    ]
  },
  value: ({ props: e }) => ({
    class: [
      // Flexbox & Overflow & Position
      { "absolute flex items-center justify-center overflow-hidden": e.mode !== "indeterminate" },
      // Colors
      "bg-primary",
      // Spacing & Sizing
      "m-0",
      { "h-full w-0": e.mode !== "indeterminate" },
      // Shape
      "border-0",
      // Transitions
      {
        "transition-width duration-1000 ease-in-out": e.mode !== "indeterminate",
        "progressbar-value-animate": e.mode == "indeterminate"
      },
      // Before & After (indeterminate)
      {
        "before:absolute before:top-0 before:left-0 before:bottom-0 before:bg-inherit ": e.mode == "indeterminate",
        "after:absolute after:top-0 after:left-0 after:bottom-0 after:bg-inherit after:delay-1000": e.mode == "indeterminate"
      }
    ]
  }),
  label: {
    class: [
      //Font
      "text-xs font-semibold",
      // Flexbox
      "inline-flex",
      // Font and Text
      "text-white dark:text-surface-900",
      "leading-5"
    ]
  }
}, Fi = {
  root: {
    class: [
      // Position
      "relative",
      "mx-auto",
      // Sizing
      "w-28",
      "h-28",
      // Flexbox
      "inline-block",
      // Pseudo-Elements
      "before:block",
      "before:pt-full"
    ]
  },
  spinner: {
    class: [
      // Position
      "absolute",
      "top-0",
      "bottom-0",
      "left-0",
      "right-0",
      "m-auto",
      // Sizing
      "w-full",
      "h-full",
      // Transformations
      "transform",
      "origin-center",
      // Animations
      "animate-spin"
    ]
  },
  circle: {
    class: [
      // Colors
      "text-red-500",
      // Misc
      "progress-spinner-circle"
    ]
  }
}, Vi = {
  root: {
    class: [
      "relative",
      // Flexbox & Alignment
      "inline-flex",
      "align-bottom",
      // Size
      "w-5 h-5",
      // Misc
      "cursor-pointer",
      "select-none"
    ]
  },
  box: ({ props: e, context: t }) => ({
    class: [
      // Flexbox
      "flex justify-center items-center",
      // Size
      "w-5 h-5",
      // Shape
      "border outline-transparent",
      "rounded-full",
      // Transition
      "transition duration-200 ease-in-out",
      // Colors
      {
        "text-surface-700 dark:text-white/80": t.checked,
        "border-surface-300 dark:border-surface-700": !t.checked && !e.invalid,
        "border-primary bg-primary": t.checked && !e.disabled
      },
      // Invalid State
      { "border-red-500 dark:border-red-400": e.invalid },
      // States
      {
        "peer-hover:border-surface-400 dark:peer-hover:border-surface-400": !e.disabled && !e.invalid && !t.checked,
        "peer-hover:border-primary-emphasis": !e.disabled && !t.checked,
        "peer-hover:[&>*:first-child]:bg-primary-600 dark:peer-hover:[&>*:first-child]:bg-primary-300": !e.disabled && !t.checked,
        "peer-focus-visible:ring-1 peer-focus-visible:ring-primary-500 dark:peer-focus-visible:ring-primary-400": !e.disabled,
        "bg-surface-200 [&>*:first-child]:bg-surface-600 dark:bg-surface-700 dark:[&>*:first-child]:bg-surface-400 border-surface-300 dark:border-surface-700 select-none pointer-events-none cursor-default": e.disabled
      }
    ]
  }),
  input: {
    class: [
      "peer",
      // Size
      "w-full ",
      "h-full",
      // Position
      "absolute",
      "top-0 left-0",
      "z-10",
      // Spacing
      "p-0",
      "m-0",
      // Shape
      "opacity-0",
      "rounded-md",
      "outline-none",
      "border-1 border-surface-200 dark:border-surface-700",
      // Misc
      "appearance-none",
      "cursor-pointer"
    ]
  },
  icon: ({ context: e }) => ({
    class: [
      "block",
      // Shape
      "rounded-full",
      // Size
      "w-3 h-3",
      // Conditions
      {
        "bg-surface-0 dark:bg-surface-900": e.checked,
        "bg-primary": !e.checked,
        "backface-hidden invisible scale-[0.1]": !e.checked,
        "transform visible translate-z-0 scale-[1,1]": e.checked
      },
      // Transition
      "transition duration-200"
    ]
  })
}, Mi = {
  root: ({ props: e }) => ({
    class: [
      "relative",
      // Flex & Alignment
      "flex items-center",
      "gap-1",
      // Misc
      {
        "opacity-60 select-none pointer-events-none cursor-default": e.disabled
      }
    ]
  }),
  option: ({ props: e, context: t }) => ({
    class: [
      // Flex & Alignment
      "inline-flex items-center",
      // State
      {
        "outline-none ring-1 ring-primary-500/50 dark:ring-primary-500": t.focused
      },
      // Misc
      {
        "cursor-pointer": !e.readonly,
        "cursor-default": e.readonly
      }
    ]
  }),
  offIcon: ({ props: e }) => ({
    class: [
      // Size
      "w-4 h-4",
      // Color
      "text-surface-700 dark:text-surface-0/80",
      // State
      { "hover:text-primary-500 dark:hover:text-primary-400": !e.readonly },
      // Transition
      "transition duration-200 ease-in"
    ]
  }),
  onIcon: ({ props: e }) => ({
    class: [
      // Size
      "w-4 h-4",
      // Color
      "text-primary",
      // State
      { "hover:text-primary-600 dark:hover:text-primary-300": !e.readonly },
      // Transition
      "transition duration-200 ease-in"
    ]
  })
}, Bi = {
  root: {
    class: ["block absolute bg-surface-200 dark:bg-surface-700 rounded-full pointer-events-none"],
    style: "transform: scale(0)"
  }
}, Di = {
  root: {
    class: ["group"]
  },
  contentContainer: {
    class: [
      // Size & Position
      "h-full w-full",
      // Layering
      "z-[1]",
      // Spacing
      "overflow-hidden",
      // Misc
      "relative float-left"
    ]
  },
  content: {
    class: [
      // Size & Spacing
      "h-[calc(100%+18px)] w-[calc(100%+18px)] pr-[18px] pb-[18px] pl-0 pt-0",
      // Overflow & Scrollbar
      "overflow-scroll scrollbar-none",
      // Box Model
      "box-border",
      // Position
      "relative",
      // Webkit Specific
      "[&::-webkit-scrollbar]:hidden"
    ]
  },
  barX: {
    class: [
      // Size & Position
      "h-[9px] bottom-0",
      // Appearance
      "bg-surface-100 dark:bg-surface-800 rounded",
      "opacity-0",
      // Interactivity
      "cursor-pointer",
      "focus:outline-none",
      // Visibility & Layering
      "invisible z-20",
      // Transition
      "transition duration-[250ms] ease-linear",
      // Misc
      "relative",
      "group-hover:opacity-100"
    ]
  },
  barY: {
    class: [
      // Size & Position
      "w-[9px] top-0",
      // Appearance
      "bg-surface-100 dark:bg-surface-800 rounded",
      "opacity-0",
      // Interactivity
      "cursor-pointer",
      "focus:outline-none",
      // Visibility & Layering
      "z-20",
      // Transition
      "transition duration-[250ms] ease-linear",
      // Misc
      "relative",
      "group-hover:opacity-100"
    ]
  }
}, Hi = {
  button: ({ props: e }) => ({
    root: {
      class: [
        // Flex & Alignment
        "flex items-center justify-center",
        // Positioning
        {
          "!sticky flex ml-auto": e.target === "parent",
          "!fixed": e.target === "window"
        },
        "bottom-[20px] right-[20px]",
        "h-10 w-10 rounded-full shadow-md",
        "text-white dark:text-surface-900 bg-surface-600 dark:bg-surface-700",
        "hover:bg-surface-600 dark:hover:bg-surface-300"
      ]
    }
  }),
  transition: {
    enterFromClass: "opacity-0",
    enterActiveClass: "transition-opacity duration-150",
    leaveActiveClass: "transition-opacity duration-150",
    leaveToClass: "opacity-0"
  }
}, eo = {
  root: ({ props: e, state: t, parent: r }) => ({
    class: [
      // Display and Position
      "inline-flex",
      "relative",
      // Shape
      { "rounded-md": r.instance.$name !== "InputGroup" },
      { "first:rounded-l-md rounded-none last:rounded-r-md": r.instance.$name == "InputGroup" },
      { "border-0 border-y border-l last:border-r": r.instance.$name == "InputGroup" },
      { "first:ml-0 ml-[-1px]": r.instance.$name == "InputGroup" && !e.showButtons },
      // Color and Background
      { "bg-surface-0 dark:bg-surface-950": !e.disabled },
      "border",
      { "dark:border-surface-700": r.instance.$name != "InputGroup" },
      { "dark:border-surface-600": r.instance.$name == "InputGroup" },
      { "border-surface-300 dark:border-surface-600": !e.invalid },
      // Invalid State
      "invalid:focus:ring-red-200",
      "invalid:hover:border-red-500",
      { "border-red-500 dark:border-red-400": e.invalid },
      // Transitions
      "transition-all",
      "duration-200",
      // States
      { "hover:border-surface-400 dark:hover:border-surface-600": !e.invalid },
      { "outline-none outline-offset-0 ring-1 ring-primary-500 dark:ring-secondary-400 z-10": t.focused },
      // Misc
      "cursor-pointer",
      "select-none",
      { "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  label: ({ props: e, parent: t }) => {
    var r;
    return {
      class: [
        //Font
        "leading-[normal]",
        // Display
        "block",
        "flex-auto",
        // Color and Background
        "bg-transparent",
        "border-0",
        { "text-surface-800 dark:text-white/80": e.modelValue != null, "text-surface-400 dark:text-surface-500": e.modelValue == null },
        "placeholder:text-surface-400 dark:placeholder:text-surface-500",
        // Sizing and Spacing
        "w-[1%]",
        "py-2 px-3",
        { "pr-7": e.showClear },
        //Shape
        "rounded-none",
        // Transitions
        "transition",
        "duration-200",
        // States
        "focus:outline-none focus:shadow-none",
        // Filled State *for FloatLabel
        { filled: ((r = t.instance) == null ? void 0 : r.$name) == "FloatLabel" && e.modelValue !== null },
        // Misc
        "relative",
        "cursor-pointer",
        "overflow-hidden overflow-ellipsis",
        "whitespace-nowrap",
        "appearance-none"
      ]
    };
  },
  dropdown: {
    class: [
      // Flexbox
      "flex items-center justify-center",
      "shrink-0",
      // Color and Background
      "bg-transparent",
      "text-surface-500",
      // Size
      "w-12",
      // Shape
      "rounded-r-md"
    ]
  },
  overlay: {
    class: [
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      // Shape
      "border border-surface-300 dark:border-surface-700",
      "rounded-md",
      "shadow-md"
    ]
  },
  listContainer: {
    class: [
      // Sizing
      "max-h-[200px]",
      // Misc
      "overflow-auto"
    ]
  },
  list: {
    class: "p-1 list-none m-0"
  },
  option: ({ context: e }) => ({
    class: [
      "relative",
      "flex items-center",
      // Font
      "leading-none",
      // Spacing
      "m-0 px-3 py-2",
      "first:mt-0 mt-[2px]",
      // Shape
      "border-0 rounded",
      // Colors
      {
        "bg-surface-200 dark:bg-surface-600/60": e.focused && !e.selected,
        "text-surface-700 dark:text-white/80": e.focused && !e.selected,
        "bg-highlight": e.selected
      },
      //States
      { "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.focused && !e.selected },
      { "hover:bg-highlight-emphasis": e.selected },
      { "hover:text-surface-700 hover:bg-surface-100 dark:hover:text-white dark:hover:bg-[rgba(255,255,255,0.03)]": e.focused && !e.selected },
      // Transition
      "transition-shadow duration-200",
      // Misc
      "cursor-pointer overflow-hidden whitespace-nowrap"
    ]
  }),
  optionGroup: {
    class: [
      "font-semibold",
      // Spacing
      "m-0 py-2 px-3",
      // Colors
      "text-surface-400 dark:text-surface-500",
      // Misc
      "cursor-auto"
    ]
  },
  optionCheckIcon: "relative -ms-1.5 me-1.5 text-surface-700 dark:text-white/80 w-4 h-4",
  optionBlankIcon: "w-4 h-4",
  emptyMessage: {
    class: [
      // Font
      "leading-none",
      // Spacing
      "py-2 px-3",
      // Color
      "text-surface-800 dark:text-white/80",
      "bg-transparent"
    ]
  },
  header: {
    class: [
      // Spacing
      "pt-2 px-2 pb-0",
      "m-0",
      //Shape
      "border-b-0",
      "rounded-tl-md",
      "rounded-tr-md",
      // Color
      "text-surface-700 dark:text-white/80",
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-300 dark:border-surface-700"
    ]
  },
  clearIcon: {
    class: [
      // Color
      "text-surface-400 dark:text-surface-500",
      // Position
      "absolute",
      "top-1/2",
      "right-12",
      // Spacing
      "-mt-2"
    ]
  },
  loadingIcon: {
    class: "text-surface-400 dark:text-surface-500 animate-spin"
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, Ui = {
  root: ({ props: e }) => ({
    class: [
      "inline-flex select-none align-bottom outline-transparent",
      "border rounded-md [&>button]:rounded-none [&>button]:border-none",
      "[&>button:first-child]:border-r-none [&>button:first-child]:rounded-r-none [&>button:first-child]:rounded-tl-md [&>button:first-child]:rounded-bl-md",
      "[&>button:last-child]:border-l-none [&>button:first-child]:rounded-l-none [&>button:last-child]:rounded-tr-md [&>button:last-child]:rounded-br-md",
      // Invalid State
      {
        "border-red-500 dark:border-red-400": e.invalid,
        "border-transparent": !e.invalid
      }
    ]
  })
}, Ki = {
  root: ({ props: e }) => ({
    class: [
      "overflow-hidden",
      {
        "animate-pulse": e.animation !== "none"
      },
      // Round
      { "rounded-full": e.shape === "circle", "rounded-md": e.shape !== "circle" },
      // Colors
      "bg-surface-200 dark:bg-surface-700"
    ]
  })
}, Wi = {
  root: ({ props: e }) => ({
    class: [
      "relative",
      // Size
      { "h-[3px]": e.orientation == "horizontal", "w-[3px]": e.orientation == "vertical" },
      // Shape
      "border-0",
      "rounded-md",
      // Colors
      "bg-surface-200 dark:bg-surface-800",
      // States
      { "opacity-60 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  range: ({ props: e }) => ({
    class: [
      // Position
      "block absolute",
      {
        "top-0 left-0": e.orientation == "horizontal",
        "bottom-0 left-0": e.orientation == "vertical"
      },
      //Size
      {
        "h-full": e.orientation == "horizontal",
        "w-full": e.orientation == "vertical"
      },
      // Shape
      "rounded-md",
      // Colors
      "bg-primary"
    ]
  }),
  handle: ({ props: e }) => ({
    class: [
      "flex items-center justify-center",
      // Size
      "h-[20px]",
      "w-[20px]",
      {
        "top-[50%] -mt-[10px] -ml-[10px]": e.orientation == "horizontal",
        "left-[50%] -mb-[10px] -ml-[10px]": e.orientation == "vertical"
      },
      // Shape
      "rounded-full",
      "before:block before:w-[16px] before:h-[16px] before:rounded-full before:bg-surface-0 dark:before:bg-surface-950 before:shadow-md",
      // Colors
      "bg-surface-200 dark:bg-surface-800",
      // States
      "focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1",
      "ring-primary-500 dark:ring-primary-400",
      // Transitions
      "transition duration-200",
      // Misc
      "cursor-grab",
      "touch-action-none"
    ]
  }),
  startHandler: ({ props: e }) => ({
    class: [
      "flex items-center justify-center",
      // Size
      "h-[20px]",
      "w-[20px]",
      {
        "top-[50%] -mt-[10px] -ml-[10px]": e.orientation == "horizontal",
        "left-[50%] -mb-[10px] -ml-[10px]": e.orientation == "vertical"
      },
      // Shape
      "rounded-full",
      "before:block before:w-[16px] before:h-[16px] before:rounded-full before:bg-surface-0 dark:before:bg-surface-950 before:shadow-md",
      // Colors
      "bg-surface-200 dark:bg-surface-800",
      // States
      "focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1",
      "ring-primary-500 dark:ring-primary-400",
      // Transitions
      "transition duration-200",
      // Misc
      "cursor-grab",
      "touch-action-none"
    ]
  }),
  endHandler: ({ props: e }) => ({
    class: [
      "flex items-center justify-center",
      // Size
      "h-[20px]",
      "w-[20px]",
      {
        "top-[50%] -mt-[10px] -ml-[10px]": e.orientation == "horizontal",
        "left-[50%] -mb-[10px] -ml-[10px]": e.orientation == "vertical"
      },
      // Shape
      "rounded-full",
      "before:block before:w-[16px] before:h-[16px] before:rounded-full before:bg-surface-0 dark:before:bg-surface-950 before:shadow-md",
      // Colors
      "bg-surface-200 dark:bg-surface-800",
      // States
      "focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1",
      "ring-primary-500 dark:ring-primary-400",
      // Transitions
      "transition duration-200",
      // Misc
      "cursor-grab",
      "touch-action-none"
    ]
  })
}, Gi = {
  root: ({ state: e }) => ({
    class: [
      "static flex gap-2",
      {
        "[&_[data-pc-name=pcbutton]]:rotate-45": e.d_visible,
        "[&_[data-pc-name=pcbutton]]:rotate-0": !e.d_visible
      }
    ]
  }),
  list: {
    class: [
      // Spacing
      "m-0 p-0",
      // Layout & Flexbox
      "list-none flex items-center justify-center",
      // Transitions
      "transition delay-200",
      // Z-Index (Positioning)
      "z-20"
    ]
  },
  item: ({ props: e, context: t }) => ({
    class: [
      "transform transition-transform duration-200 ease-out transition-opacity duration-800",
      // Conditional Appearance
      t.hidden ? "opacity-0 scale-0" : "opacity-100 scale-100",
      // Conditional Spacing
      {
        "my-1 first:mb-2": e.direction == "up" && e.type == "linear",
        "my-1 first:mt-2": e.direction == "down" && e.type == "linear",
        "mx-1 first:mr-2": e.direction == "left" && e.type == "linear",
        "mx-1 first:ml-2": e.direction == "right" && e.type == "linear"
      },
      // Conditional Positioning
      { absolute: e.type !== "linear" }
    ]
  }),
  mask: ({ state: e }) => ({
    class: [
      // Base Styles
      "absolute left-0 top-0 w-full h-full transition-opacity duration-250 ease-in-out bg-black/40 z-0",
      // Conditional Appearance
      {
        "opacity-0 pointer-events-none": !e.d_visible,
        "opacity-100 transition-opacity duration-400 ease-in-out": e.d_visible
      }
    ]
  })
}, qi = {
  root: ({ props: e }) => ({
    class: [
      // Flexbox and Position
      "inline-flex",
      "relative",
      // Shape
      "rounded-md",
      { "shadow-lg": e.raised },
      "[&>[data-pc-name=pcbutton]]:rounded-tr-none",
      "[&>[data-pc-name=pcbutton]]:rounded-br-none",
      "[&>[data-pc-name=pcdropdown]]:rounded-tl-none",
      "[&>[data-pc-name=pcdropdown]]:rounded-bl-none",
      "[&>[data-pc-name=pcmenu]]:min-w-full"
    ]
  })
}, Yi = {
  root: ({ context: e }) => ({
    class: [
      // Colors
      "bg-surface-0",
      "dark:bg-surface-900",
      "text-surface-700",
      "dark:text-surface-0/80",
      // Shape
      "rounded-md",
      // Borders (Conditional)
      { "border border-solid border-surface-200 dark:border-surface-700": !e.nested },
      // Nested
      { "flex grow border-0": e.nested }
    ]
  }),
  gutter: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex",
      "items-center",
      "justify-center",
      "shrink-0",
      // Colors
      "bg-surface-100",
      "dark:bg-surface-700",
      // Transitions
      "transition-all",
      "duration-200",
      // Misc
      {
        "cursor-col-resize": e.layout == "horizontal",
        "cursor-row-resize": e.layout !== "horizontal"
      }
    ]
  }),
  gutterhandler: ({ props: e }) => ({
    class: [
      "z-20",
      // Colors
      "bg-surface-100",
      "dark:bg-surface-700",
      // Shape
      "rounded-md",
      //States
      "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
      // Transitions
      "transition-all",
      "duration-200",
      // Sizing (Conditional)
      {
        "h-[1.70rem]": e.layout == "horizontal",
        "w-[1.70rem] h-2": e.layout !== "horizontal"
      }
    ]
  })
}, Ji = {
  root: ({ context: e }) => ({
    class: ["grow", { flex: e.nested }]
  })
}, Qi = {
  root: ({ context: e }) => ({
    class: ["relative flex flex-auto items-center gap-2 p-2 last-of-type:flex-[initial]", { "cursor-default pointer-events-none select-none opacity-60": e.disabled }, "[&_[data-pc-section=separator]]:has-[~[data-p-active=true]]:bg-primary"]
  }),
  header: ({ props: e, context: t }) => ({
    class: [
      "inline-flex items-center border-0 cursor-pointer rounded-md outline-transparent bg-transparent p-0 gap-2",
      "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
      { "!cursor-default": t.active },
      { "cursor-auto": e.linear }
    ]
  }),
  number: ({ context: e }) => ({
    class: [
      // Flexbox
      "flex",
      "items-center",
      "justify-center",
      //Colors
      "border-solid border-2 border-surface-200 dark:border-surface-700",
      // Colors (Conditional)
      e.active ? "text-primary" : "text-surface-900 dark:text-surface-0",
      // Adjust colors as needed
      // Size and Shape
      "min-w-[2rem]",
      "h-[2rem]",
      "line-height-[2rem]",
      "rounded-full",
      // Text
      "text-lg",
      // Transitions
      "transition",
      "transition-colors",
      "transition-shadow",
      "duration-200"
    ]
  }),
  title: ({ context: e }) => ({
    class: [
      // Layout
      "block",
      "whitespace-nowrap",
      "overflow-hidden",
      "text-ellipsis",
      "max-w-full",
      // Text
      e.active ? "text-primary" : "text-surface-700 dark:text-surface-0/80",
      "font-medium",
      // Transitions
      "transition",
      "transition-colors",
      "transition-shadow",
      "duration-200"
    ]
  })
}, Zi = {
  root: ({ state: e }) => ({
    class: [
      "flex flex-col flex-[initial] has-[[data-pc-name=steppanels]]:px-2 has-[[data-pc-name=steppanels]]:pt-3.5 has-[[data-pc-name=steppanels]]:pb-[1.125rem]",
      { "flex-auto": e.isActive },
      "[&>[data-pc-name=step]]:flex-[initial]",
      "[&>[data-pc-name=steppanel]]:flex [&>[data-pc-name=steppanel]]:flex-auto [&>[data-pc-name=steppanel]>[data-pc-section=content]]:w-full [&>[data-pc-name=steppanel]>[data-pc-section=content]]:pl-4 [&:last-child>[data-pc-name=steppanel]>[data-pc-section=content]]:ps-8",
      "[&>[data-pc-name=steppanel]>[data-pc-section=separator]]:relative [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:!flex-initial [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:shrink-0 [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:w-[2px] [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:h-auto [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:m-2 [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:left-[-2px] [&>[data-pc-name=steppanel]>[data-pc-section=separator]]:ml-[1.625rem]"
    ]
  })
}, Xi = {
  root: "relative flex justify-between items-center m-0 p-0 list-none overflow-x-auto"
}, el = {
  root: "px-2 pt-3.5 pb-[1.125rem]"
}, tl = {
  root: "has-[[data-pc-name=stepitem]]:flex has-[[data-pc-name=stepitem]]:flex-col",
  separator: "flex-1 w-full h-[2px] bg-surface-200 dark:bg-surface-700 transition-shadow duration-200",
  transition: {
    class: ["flex flex-1", "bg-surface-0 dark:bg-surface-900", "text-surface-900 dark:text-surface-0"],
    enterFromClass: "max-h-0",
    enterActiveClass: "overflow-hidden transition-[max-height] duration-1000 ease-[cubic-bezier(0.42,0,0.58,1)]",
    enterToClass: "max-h-[1000px]",
    leaveFromClass: "max-h-[1000px]",
    leaveActiveClass: "overflow-hidden transition-[max-height] duration-[450ms] ease-[cubic-bezier(0,1,0,1)]",
    leaveToClass: "max-h-0"
  }
}, rl = {
  root: {
    class: "relative"
  },
  menu: {
    class: "p-0 m-0 list-none flex"
  },
  menuitem: {
    class: [
      // Flexbox and Position
      "relative",
      "flex",
      "justify-center",
      "flex-1",
      "overflow-hidden",
      // Before
      "before:border-t-2",
      "before:border-surface-200",
      "before:dark:border-surface-700",
      "before:w-full",
      "[&:first-child]:before:w-[calc(50%+1rem)]",
      "[&:last-child]:before:w-1/2",
      "before:absolute",
      "before:top-1/2",
      "before:left-0",
      "before:transform",
      "before:mt-[calc(-1rem+1px)]",
      "[&:first-child]:before:translate-x-[100%]"
    ]
  },
  action: ({ props: e }) => ({
    class: [
      // Flexbox
      "inline-flex items-center",
      "flex-col",
      // Transitions and Shape
      "transition-shadow",
      "rounded-md",
      // Colors
      "bg-surface-0",
      "dark:bg-transparent",
      // States
      "focus:outline-none focus:outline-offset-0 focus:ring",
      "focus:ring-primary-500 dark:focus:ring-primary-400",
      // Misc
      "overflow-hidden",
      { "cursor-pointer": !e.readonly }
    ]
  }),
  step: ({ context: e, props: t }) => ({
    class: [
      // Flexbox
      "flex items-center justify-center",
      // Position
      "z-20",
      // Shape
      "rounded-full",
      "border-2",
      // Size
      "w-8",
      "h-8",
      "text-sm",
      "leading-[2rem]",
      "font-medium",
      // Colors
      "bg-surface-0 dark:bg-surface-800",
      "border-surface-100 dark:border-surface-700",
      {
        "text-surface-400 dark:text-white/60": !e.active,
        "text-primary": e.active
      },
      // States
      {
        "hover:border-surface-300 dark:hover:border-surface-500": !e.active && !t.readonly
      },
      // Transition
      "transition-colors duration-200 ease-in-out"
    ]
  }),
  label: ({ context: e }) => ({
    class: [
      // Font
      "leading-[normal]",
      "font-medium",
      // Display
      "block",
      // Spacing
      "mt-2",
      // Colors
      { "text-surface-700 dark:text-white/70": !e.active, "text-primary": e.active },
      // Text and Overflow
      "whitespace-nowrap",
      "overflow-hidden",
      "overflow-ellipsis",
      "max-w-full"
    ]
  })
}, nl = {
  root: ({ props: e, context: t }) => ({
    class: [
      "relative shrink-0",
      // Shape
      "border-b",
      "rounded-t-md",
      // Spacing
      "py-4 px-[1.125rem]",
      "-mb-px",
      // Colors and Conditions
      "outline-transparent",
      {
        "border-surface-200 dark:border-secondary-400": t.active,
        "border-surface-200 dark:border-transparent": !t.active,
        "text-surface-700 dark:text-surface-0/80": !t.active,
        "bg-surface-0 dark:bg-transparent": t.active,
        "text-secondary-400": t.active,
        "opacity-60 cursor-default user-select-none select-none pointer-events-none": e == null ? void 0 : e.disabled
      },
      // States
      "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-secondary-400",
      // Transitions
      "transition-all duration-200",
      // Misc
      "cursor-pointer select-none whitespace-nowrap",
      "user-select-none"
    ]
  })
}, ol = {
  root: "relative flex",
  content: "overflow-x-auto overflow-y-hidden scroll-smooth overscroll-x-contain overscroll-y-auto [&::-webkit-scrollbar]:hidden grow dark:bg-surface-800",
  tabList: "relative flex border-solid border-b border-surface-200 dark:border-surface-900",
  nextButton: "!absolute top-0 right-0 z-20 h-full w-10 flex items-center justify-center text-surface-700 dark:text-surface-0/80 bg-surface-0 dark:bg-surface-800 outline-transparent cursor-pointer shrink-0",
  prevButton: "!absolute top-0 left-0 z-20 h-full w-10 flex items-center justify-center text-surface-700 dark:text-surface-0/80 bg-surface-0 dark:bg-surface-800 outline-transparent cursor-pointer shrink-0",
  activeBar: "z-10 block absolute h-[1px] bottom-[-1px] bg-primary-400"
}, al = {
  root: {
    class: "overflow-x-auto"
  },
  menu: {
    class: [
      // Flexbox
      "flex flex-1",
      // Spacing
      "list-none",
      "p-0 m-0",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "border-b-2 border-surface-200 dark:border-surface-700",
      "text-surface-900 dark:text-surface-0/80"
    ]
  },
  menuitem: {
    class: "mr-0"
  },
  action: ({ context: e, state: t }) => ({
    class: [
      "relative",
      // Font
      "font-semibold leading-none",
      // Flexbox and Alignment
      "flex items-center",
      // Spacing
      "py-4 px-[1.125rem]",
      "-mb-px",
      // Shape
      "border-b",
      "rounded-t-md",
      // Colors and Conditions
      {
        "border-surface-200 dark:border-surface-700": t.d_activeIndex !== e.index,
        "text-surface-700 dark:text-surface-0/80": t.d_activeIndex !== e.index,
        "bg-surface-0 dark:bg-surface-900": t.d_activeIndex === e.index,
        "border-primary": t.d_activeIndex === e.index,
        "text-primary": t.d_activeIndex === e.index
      },
      // States
      "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
      {
        "hover:text-surface-900 dark:hover:text-surface-0": t.d_activeIndex !== e.index
      },
      // Transitions
      "transition-all duration-200",
      // Misc
      "cursor-pointer select-none text-decoration-none",
      "overflow-hidden",
      "user-select-none"
    ]
  }),
  icon: {
    class: "mr-2"
  }
}, sl = {
  root: "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300"
}, il = {
  root: "bg-surface-0 dark:bg-surface-800 text-surface-900 dark:text-surface-0/80 outline-0 p-[1.125rem] pt-[0.875rem]"
}, ll = {
  root: ({ props: e }) => ({
    class: ["flex flex-col", { "[&>[data-pc-name=tablist]]:overflow-hidden": e.scrollable }]
  })
}, cl = {
  // For PrimeVue version 3
  navContainer: ({ props: e }) => ({
    class: [
      // Position
      "relative",
      // Misc
      { "overflow-hidden": e.scrollable }
    ]
  }),
  navContent: ({ instance: e }) => ({
    class: [
      // Overflow and Scrolling
      "overflow-y-hidden overscroll-contain",
      "overscroll-auto",
      "scroll-smooth",
      "[&::-webkit-scrollbar]:hidden"
    ]
  }),
  previousButton: {
    class: [
      // Flexbox and Alignment
      "flex items-center justify-center",
      // Position
      "!absolute",
      "top-0 left-0",
      "z-20",
      // Size and Shape
      "h-full w-10",
      "rounded-none",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-surface-0/80",
      "shadow-sm"
    ]
  },
  nextButton: {
    class: [
      // Flexbox and Alignment
      "flex items-center justify-center",
      // Position
      "!absolute",
      "top-0 right-0",
      "z-20",
      // Size and Shape
      "h-full w-10",
      "rounded-none",
      // Colors
      "text-surface-700 dark:text-surface-0/80",
      "bg-surface-0 dark:bg-surface-900",
      "shadow-sm"
    ]
  },
  nav: {
    class: [
      // Flexbox
      "flex flex-1",
      // Spacing
      "list-none",
      "p-0 m-0",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "border-b border-surface-200 dark:border-surface-700",
      "text-surface-900 dark:text-surface-0/80"
    ]
  },
  tabpanel: {
    header: ({ props: e }) => ({
      class: [
        // Spacing
        "mr-0",
        // Misc
        "outline-none",
        {
          "opacity-60 cursor-default user-select-none select-none pointer-events-none": e == null ? void 0 : e.disabled
        }
      ]
    }),
    headerAction: ({ parent: e, context: t }) => ({
      class: [
        "relative",
        // Font
        "font-semibold",
        // Flexbox and Alignment
        "flex items-center",
        // Spacing
        "py-4 px-[1.125rem]",
        "-mb-px",
        // Shape
        "border-b-2",
        "rounded-t-md",
        // Colors and Conditions
        {
          "border-surface-200 dark:border-surface-700": e.state.d_activeIndex !== t.index,
          "text-surface-700 dark:text-surface-0/80": e.state.d_activeIndex !== t.index,
          "bg-surface-0 dark:bg-surface-900": e.state.d_activeIndex === t.index,
          "border-primary": e.state.d_activeIndex === t.index,
          "text-primary": e.state.d_activeIndex === t.index
        },
        // States
        "focus:outline-none focus:outline-offset-0 focus-visible:ring-1 ring-inset focus-visible:ring-primary-400 dark:focus-visible:ring-primary-300",
        {
          "hover:bg-surface-0 dark:hover:bg-surface-800/80": e.state.d_activeIndex !== t.index,
          "hover:text-surface-900 dark:hover:text-surface-0": e.state.d_activeIndex !== t.index
        },
        // Transitions
        "transition-all duration-200",
        // Misc
        "cursor-pointer select-none text-decoration-none",
        "overflow-hidden",
        "user-select-none"
      ]
    }),
    headerTitle: {
      class: [
        // Text
        "leading-none",
        "whitespace-nowrap"
      ]
    }
  },
  panelcontainer: {
    class: [
      // Spacing
      "p-[1.125rem] pt-[0.875rem]",
      // Shape
      "border-0 rounded-none",
      "border-br-md border-bl-md",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-900 dark:text-surface-0/80"
    ]
  }
}, ul = {
  root: ({ props: e }) => ({
    class: [
      //Font
      "text-xs font-bold",
      //Alignments
      "inline-flex items-center justify-center",
      //Spacing
      "px-[0.4rem] py-1",
      //Shape
      {
        "rounded-md": !e.rounded,
        "rounded-full": e.rounded
      },
      //Colors
      {
        "bg-highlight": e.severity === null || e.severity === "primary",
        "text-green-700 dark:text-green-300 bg-green-100 dark:bg-green-500/20": e.severity === "success",
        "text-surface-700 dark:text-surface-300 bg-surface-100 dark:bg-surface-500/20": e.severity === "secondary",
        "text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-500/20": e.severity === "info",
        "text-orange-700 dark:text-orange-300 bg-orange-100 dark:bg-orange-500/20": e.severity === "warn",
        "text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-500/20": e.severity === "danger",
        "text-surface-0 dark:text-surface-900 bg-surface-900 dark:bg-surface-0": e.severity === "contrast"
      }
    ]
  }),
  value: {
    class: "leading-normal"
  },
  icon: {
    class: "mr-1 text-sm"
  }
}, dl = {
  root: {
    class: [
      // Spacing
      "py-2 px-3",
      // Shape
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-950 text-surface-700 dark:text-surface-0",
      "border border-surface-200 dark:border-surface-700",
      // Sizing & Overflow
      "h-72 overflow-auto"
    ]
  },
  container: {
    class: [
      // Flexbox
      "flex items-center"
    ]
  },
  prompt: {
    class: [
      // Color
      "text-surface-700 dark:text-surface-0"
    ]
  },
  response: {
    class: [
      // Color
      "text-surface-700 dark:text-surface-0"
    ]
  },
  command: {
    class: [
      // Color
      "text-surface-700 dark:text-surface-0"
    ]
  },
  commandtext: {
    class: [
      // Flexbox
      "flex-1 shrink grow-0",
      // Shape
      "border-0",
      // Spacing
      "p-0",
      // Color
      "bg-transparent text-inherit",
      // Outline
      "outline-none"
    ]
  }
}, fl = {
  root: ({ context: e, props: t, parent: r }) => {
    var n, o;
    return {
      class: [
        // Font
        "leading-none",
        // Spacing
        "m-0",
        "py-2 px-3",
        // Shape
        "rounded-md",
        // Colors
        "text-surface-800 dark:text-white/80",
        "placeholder:text-surface-400 dark:placeholder:text-surface-500",
        { "bg-surface-0 dark:bg-surface-950": !e.disabled },
        "border",
        { "border-surface-300 dark:border-surface-600": !t.invalid },
        // Invalid State
        "invalid:focus:ring-danger-400",
        "invalid:hover:border-danger-400",
        { "border-danger-400 dark:border-danger-400": t.invalid },
        // States
        {
          "hover:border-surface-400 dark:hover:border-surface-600": !e.disabled && !t.invalid,
          "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-secondary-500 dark:focus:ring-secondary-400 focus:z-10": !e.disabled,
          "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled
        },
        // Filled State *for FloatLabel
        { filled: ((n = r.instance) == null ? void 0 : n.$name) == "FloatLabel" && t.modelValue !== null && ((o = t.modelValue) == null ? void 0 : o.length) !== 0 },
        // Misc
        "appearance-none",
        "transition-colors duration-200"
      ]
    };
  }
}, pl = {
  root: {
    class: [
      // Shape
      "rounded-md",
      // Size
      "min-w-[12rem]",
      "p-1",
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "border border-surface-200 dark:border-surface-700"
    ]
  },
  rootList: {
    class: [
      // Spacings and Shape
      "list-none",
      "flex flex-col",
      "m-0 p-0",
      "outline-none"
    ]
  },
  item: {
    class: "relative my-[2px] [&:first-child]:mt-0"
  },
  itemContent: ({ context: e }) => ({
    class: [
      //Shape
      "rounded-[4px]",
      // Colors
      {
        "text-surface-500 dark:text-white/70": !e.focused && !e.active,
        "text-surface-500 dark:text-white/70 bg-surface-200 dark:bg-surface-600/90": e.focused && !e.active,
        "bg-highlight text-highlight-contrast": e.focused && e.active || e.active || !e.focused && e.active
      },
      // Transitions
      "transition-shadow",
      "duration-200",
      // States
      {
        "hover:bg-surface-100 dark:hover:bg-[rgba(255,255,255,0.03)]": !e.active,
        "hover:bg-highlight-emphasis": e.active
      },
      // Disabled
      { "opacity-60 pointer-events-none cursor-default": e.disabled }
    ]
  }),
  itemLink: {
    class: [
      "relative",
      // Flexbox
      "flex",
      "items-center",
      // Spacing
      "py-2",
      "px-3",
      // Misc
      "no-underline",
      "overflow-hidden",
      "cursor-pointer",
      "select-none"
    ]
  },
  itemIcon: {
    class: [
      // Spacing
      "mr-2"
    ]
  },
  itemLabel: {
    class: ["leading-none"]
  },
  submenuIcon: {
    class: [
      // Position
      "ml-auto"
    ]
  },
  submenu: {
    class: [
      // Spacing
      "flex flex-col",
      "m-0",
      "p-1",
      "list-none",
      "min-w-[12.5rem]",
      // Shape
      "shadow-none sm:shadow-md",
      "border border-surface-200 dark:border-surface-700",
      // Position
      "static sm:absolute",
      "z-10",
      // Color
      "bg-surface-0 dark:bg-surface-900"
    ]
  },
  separator: {
    class: "border-t border-surface-200 dark:border-surface-600"
  },
  transition: {
    enterFromClass: "opacity-0",
    enterActiveClass: "transition-opacity duration-250"
  }
}, bl = {
  root: ({ props: e }) => ({
    class: [
      "flex grow",
      {
        "flex-col": e.layout === "vertical",
        "flex-row": e.layout === "horizontal"
      }
    ]
  }),
  event: ({ props: e, context: t }) => ({
    class: [
      "flex relative min-h-[70px]",
      {
        "flex-row-reverse": e.align === "right" || e.layout === "vertical" && e.align === "alternate" && t.index % 2 === 1,
        "flex-col [&:not(:last-child)]:flex-1": e.layout === "horizontal",
        "flex-col-reverse ": e.align === "bottom" || e.layout === "horizontal" && e.align === "alternate" && t.index % 2 === 1
      }
    ]
  }),
  eventOpposite: ({ props: e, context: t }) => ({
    class: [
      "flex-1",
      {
        "px-4": e.layout === "vertical",
        "py-4": e.layout === "horizontal"
      },
      {
        "text-right": e.align === "left" || e.layout === "vertical" && e.align === "alternate" && t.index % 2 === 0,
        "text-left": e.align === "right" || e.layout === "vertical" && e.align === "alternate" && t.index % 2 === 1
      }
    ]
  }),
  eventSeparator: ({ props: e }) => ({
    class: [
      "flex items-center flex-initial",
      {
        "flex-col": e.layout === "vertical",
        "flex-row": e.layout === "horizontal"
      }
    ]
  }),
  eventMarker: {
    class: [
      "relative",
      // Display & Flexbox
      "inline-flex items-center justify-center",
      // Size
      "w-[1.125rem] h-[1.125rem]",
      // Appearance
      "rounded-full border-2 border-surface-200 bg-surface-0 dark:border-surface-700 dark:bg-surface-950",
      // Before
      "before:rounded-full before:w-[0.375rem] before:h-[0.375rem] before:bg-primary",
      // After
      "after:absolute after:rounded-full after:w-full after:h-full after:shadow-sm"
    ]
  },
  eventConnector: ({ props: e }) => ({
    class: [
      "grow bg-surface-300 dark:bg-surface-700",
      {
        "w-[2px]": e.layout === "vertical",
        "w-full h-[2px]": e.layout === "horizontal"
      }
    ]
  }),
  eventContent: ({ props: e, context: t }) => ({
    class: [
      "flex-1",
      {
        "px-4": e.layout === "vertical",
        "py-4": e.layout === "horizontal"
      },
      {
        "text-left": e.align === "left" || e.layout === "vertical" && e.align === "alternate" && t.index % 2 === 0,
        "text-right": e.align === "right" || e.layout === "vertical" && e.align === "alternate" && t.index % 2 === 1
      },
      {
        "min-h-0": e.layout === "vertical" && t.index === t.count - 1,
        "grow-0": e.layout === "horizontal" && t.index === t.count - 1
      }
    ]
  })
}, gl = {
  root: ({ props: e }) => ({
    class: [
      //Size and Shape
      "w-96 rounded-md",
      // Positioning
      { "-translate-x-2/4": e.position == "top-center" || e.position == "bottom-center" }
    ]
  }),
  message: ({ props: e }) => ({
    class: [
      "mb-4 rounded-md w-full",
      "border border-transparent",
      "backdrop-blur-[10px] shadow-md",
      // Colors
      {
        "bg-blue-50/90 dark:bg-blue-500/20": e.message.severity == "info",
        "bg-green-50/90 dark:bg-green-500/20": e.message.severity == "success",
        "bg-surface-50 dark:bg-surface-800": e.message.severity == "secondary",
        "bg-orange-50/90 dark:bg-orange-500/20": e.message.severity == "warn",
        "bg-red-50/90 dark:bg-red-500/20": e.message.severity == "error",
        "bg-surface-950 dark:bg-surface-0": e.message.severity == "contrast"
      },
      {
        "border-blue-200 dark:border-blue-500/20": e.message.severity == "info",
        "border-green-200 dark:border-green-500/20": e.message.severity == "success",
        "border-surface-300 dark:border-surface-500/20": e.message.severity == "secondary",
        "border-orange-200 dark:border-orange-500/20": e.message.severity == "warn",
        "border-red-200 dark:border-red-500/20": e.message.severity == "error",
        "border-surface-950 dark:border-surface-0": e.message.severity == "contrast"
      },
      {
        "text-blue-700 dark:text-blue-300": e.message.severity == "info",
        "text-green-700 dark:text-green-300": e.message.severity == "success",
        "text-surface-700 dark:text-surface-300": e.message.severity == "secondary",
        "text-orange-700 dark:text-orange-300": e.message.severity == "warn",
        "text-red-700 dark:text-red-300": e.message.severity == "error",
        "text-surface-0 dark:text-surface-950": e.message.severity == "contrast"
      }
    ]
  }),
  messageContent: ({ props: e }) => ({
    class: [
      "flex p-3",
      {
        "items-start": e.message.summary,
        "items-center": !e.message.summary
      }
    ]
  }),
  messageIcon: ({ props: e }) => ({
    class: [
      // Sizing and Spacing
      e.message.severity === "contrast" || e.message.severity === "secondary" ? "w-0" : "w-[1.125rem] h-[1.125rem] mr-2",
      "text-lg leading-[normal]"
    ]
  }),
  messageText: {
    class: [
      // Font and Text
      "text-base leading-[normal]",
      "ml-2",
      "flex-1"
    ]
  },
  summary: {
    class: "font-medium block"
  },
  detail: ({ props: e }) => ({
    class: ["block", "text-sm", e.message.severity === "contrast" ? "text-surface-0 dark:text-surface-950" : "text-surface-700 dark:text-surface-0", { "mt-2": e.message.summary }]
  }),
  closeButton: ({ props: e }) => ({
    class: [
      // Flexbox
      "flex items-center justify-center",
      // Size
      "w-7 h-7",
      // Spacing and Misc
      "ml-auto  relative",
      // Shape
      "rounded-full",
      // Colors
      "bg-transparent",
      // Transitions
      "transition duration-200 ease-in-out",
      // States
      "hover:bg-surface-0/30 dark:hover:bg-[rgba(255,255,255,0.03)]",
      "focus:outline-none focus:outline-offset-0 focus:ring-1",
      {
        "focus:ring-blue-500 dark:focus:ring-blue-400": e.severity == "info",
        "focus:ring-green-500 dark:focus:ring-green-400": e.severity == "success",
        "focus:ring-surface-500 dark:focus:ring-surface-400": e.severity == "secondary",
        "focus:ring-orange-500 dark:focus:ring-orange-400": e.severity == "warn",
        "focus:ring-red-500 dark:focus:ring-red-4000": e.severity == "error",
        "focus:ring-surface-0 dark:focus:ring-surface-950": e.severity == "contrast"
      },
      // Misc
      "overflow-hidden"
    ]
  }),
  transition: {
    enterFromClass: "opacity-0 translate-y-2/4",
    enterActiveClass: "transition-[transform,opacity] duration-300",
    leaveFromClass: "max-h-[1000px]",
    leaveActiveClass: "!transition-[max-height_.45s_cubic-bezier(0,1,0,1),opacity_.3s,margin-bottom_.3s] overflow-hidden",
    leaveToClass: "max-h-0 opacity-0 mb-0"
  }
}, hl = {
  root: ({ props: e, context: t }) => ({
    class: [
      "relative",
      // Alignment
      "flex items-center justify-center",
      "py-2 px-4",
      "rounded-md border",
      // Color
      "bg-surface-100 dark:bg-surface-950",
      {
        "text-surface-600 dark:text-white/60 before:bg-transparent": !t.active,
        "text-surface-800 dark:text-white/80 before:bg-surface-0 dark:before:bg-surface-800": t.active
      },
      // States
      {
        "hover:text-surface-800 dark:hover:text-white/80": !e.disabled && !e.modelValue,
        "focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary-500 dark:focus-visible:ring-secondary-400": !e.disabled
      },
      // Invalid State
      {
        "border-red-500 dark:border-red-400": e.invalid,
        "border-surface-100 dark:border-surface-950": !e.invalid
      },
      // Before
      "before:absolute before:left-1 before:top-1 before:w-[calc(100%-0.5rem)] before:h-[calc(100%-0.5rem)] before:rounded-[4px] before:z-0",
      // Transitions
      "transition-all duration-200",
      // Misc
      { "cursor-pointer": !e.disabled, "opacity-60 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  content: "relative items-center inline-flex justify-center gap-2",
  label: "font-medium leading-[normal] text-center w-full z-10 relative",
  icon: "relative z-10 mr-2"
}, to = {
  root: ({ props: e }) => ({
    class: [
      "inline-block relative",
      "w-10 h-6",
      "rounded-2xl",
      {
        "opacity-60 select-none pointer-events-none cursor-default": e.disabled
      }
    ]
  }),
  slider: ({ props: e }) => ({
    class: [
      // Position
      "absolute top-0 left-0 right-0 bottom-0",
      { "before:transform before:translate-x-4": e.modelValue == e.trueValue },
      // Shape
      "rounded-2xl",
      // Before:
      "before:absolute before:top-1/2 before:left-1",
      "before:-mt-2",
      "before:h-4 before:w-4",
      "before:rounded-full",
      "before:duration-200",
      "before:bg-surface-0 before:dark:bg-surface-500",
      // Colors
      "border",
      {
        "bg-surface-300 dark:bg-surface-700": e.modelValue != e.trueValue,
        "bg-secondary-400": e.modelValue == e.trueValue,
        "before:dark:bg-surface-950": e.modelValue == e.trueValue,
        "border-transparent": !e.invalid
      },
      // Invalid State
      { "border-red-500 dark:border-danger-400": e.invalid },
      // States
      { "peer-hover:bg-surface-400 dark:peer-hover:bg-surface-600": e.modelValue != e.trueValue && !e.disabled && !e.invalid },
      { "peer-hover:bg-primary-hover": e.modelValue == e.trueValue && !e.disabled && !e.invalid },
      "peer-focus-visible:ring-1 peer-focus-visible:ring-primary-500 dark:peer-focus-visible:ring-secondary-200",
      // Transition
      "transition-colors duration-200",
      // Misc
      "cursor-pointer"
    ]
  }),
  input: {
    class: [
      "peer",
      // Size
      "w-full ",
      "h-full",
      // Position
      "absolute",
      "top-0 left-0",
      "z-10",
      // Spacing
      "p-0",
      "m-0",
      // Shape
      "opacity-0",
      "rounded-2xl",
      "outline-none",
      // Misc
      "appearance-none",
      "cursor-pointer"
    ]
  }
}, ml = {
  root: {
    class: [
      // Flex & Alignment
      "flex items-center justify-between flex-wrap",
      "gap-2",
      // Spacing
      "p-3",
      // Shape
      "rounded-md",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border border-surface-200 dark:border-surface-700"
    ]
  },
  start: {
    class: "flex items-center"
  },
  center: {
    class: "flex items-center"
  },
  end: {
    class: "flex items-center"
  }
}, vl = {
  root: ({ context: e }) => ({
    class: [
      // Position and Shadows
      "absolute",
      "p-fadein",
      // Spacing
      {
        '[&[data-p-position="top"]]:py-1 [&[data-p-position="top"]]:px-0 py-0 px-1': (e == null ? void 0 : e.right) || (e == null ? void 0 : e.left) || !(e != null && e.right) && !(e != null && e.left) && !(e != null && e.top) && !(e != null && e.bottom),
        "py-1 px-0": (e == null ? void 0 : e.top) || (e == null ? void 0 : e.bottom)
      },
      // Flipped Tooltip Arrow
      '[&[data-p-position="top"]>[data-pc-section=arrow]]:border-x-[10px] [&[data-p-position="top"]>[data-pc-section=arrow]]:border-t-[10px] [&[data-p-position="top"]>[data-pc-section=arrow]]:border-b-0 [&[data-p-position="top"]>[data-pc-section=arrow]]:border-t-surface-700 [&[data-p-position="top"]>[data-pc-section=arrow]]:border-y-0 [&[data-p-position="top"]>[data-pc-section=arrow]]:border-x-transparent',
      '[&[data-p-position="top"]>[data-pc-section=arrow]]:-ml-[10px] [&[data-p-position="top"]>[data-pc-section=arrow]]:left-1/2 [&[data-p-position="top"]>[data-pc-section=arrow]]:mt-auto [&[data-p-position="top"]>[data-pc-section=arrow]]:top-auto'
    ]
  }),
  arrow: ({ context: e }) => ({
    class: [
      // Position
      "absolute",
      // Size
      "w-0",
      "h-0",
      // Shape
      "border-transparent",
      "border-solid",
      {
        "border-y-[10px] border-r-[10px] border-l-0 border-r-surface-700": (e == null ? void 0 : e.right) || !(e != null && e.right) && !(e != null && e.left) && !(e != null && e.top) && !(e != null && e.bottom),
        "border-y-[10px] border-l-[10px] border-r-0 border-l-surface-700": e == null ? void 0 : e.left,
        "border-x-[10px] border-t-[10px] border-b-0 border-t-surface-700 ": e == null ? void 0 : e.top,
        "border-x-[10px] border-b-[10px] border-t-0 border-b-surface-700": e == null ? void 0 : e.bottom
      },
      // Spacing
      {
        "-mt-[10px] top-1/2": (e == null ? void 0 : e.right) || (e == null ? void 0 : e.left) || !(e != null && e.right) && !(e != null && e.left) && !(e != null && e.top) && !(e != null && e.bottom),
        "-ml-[10px] left-1/2": (e == null ? void 0 : e.top) || (e == null ? void 0 : e.bottom)
      }
    ]
  }),
  text: {
    class: ["p-3", "bg-surface-700", "text-white", "leading-none", "rounded-md", "whitespace-pre-line", "break-words", "shadow-md"]
  }
}, xl = {
  root: {
    class: [
      // Space
      "p-4",
      // Shape
      "rounded-md",
      "border-none",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      "[&_[data-pc-name=pcfilter]]:w-full"
    ]
  },
  wrapper: {
    class: ["overflow-auto"]
  },
  container: {
    class: [
      // Spacing
      "m-0 p-0",
      // Misc
      "list-none overflow-auto"
    ]
  },
  node: {
    class: ["p-0 my-[2px] mx-0 first:mt-0", "rounded-md", "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-inset focus:ring-primary-500 dark:focus:ring-primary-400 focus:z-10"]
  },
  nodeContent: ({ context: e, props: t }) => ({
    class: [
      // Flex and Alignment
      "flex items-center",
      // Shape
      "rounded-md",
      // Spacing
      "py-1 px-2 gap-2",
      // Colors
      e.selected ? "bg-highlight text-highlight-contrast " : "bg-transparent text-surface-600 dark:text-white/70",
      // States
      { "hover:bg-surface-50 dark:hover:bg-[rgba(255,255,255,0.03)]": (t.selectionMode == "single" || t.selectionMode == "multiple") && !e.selected },
      // Transition
      "transition-shadow duration-200",
      { "cursor-pointer select-none": t.selectionMode == "single" || t.selectionMode == "multiple" }
    ]
  }),
  nodeToggleButton: ({ context: e }) => ({
    class: [
      // Flex and Alignment
      "inline-flex items-center justify-center",
      // Shape
      "border-0 rounded-full",
      // Size
      "w-7 h-7",
      // Colors
      "bg-transparent",
      {
        "text-surface-600 dark:text-white/70": !e.selected,
        "text-highlight-contrast": e.selected,
        invisible: e.leaf
      },
      // States
      "hover:bg-surface-200/20 dark:hover:bg-surface-500/20",
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
      // Transition
      "transition duration-200",
      // Misc
      "cursor-pointer select-none"
    ]
  }),
  nodeIcon: ({ context: e }) => ({
    class: [
      // Space
      "mr-2",
      // Color
      {
        "text-surface-600 dark:text-white/70": !e.selected,
        "text-highlight-contrast": e.selected
      }
    ]
  }),
  nodeLabel: ({ context: e }) => ({
    class: [
      {
        "text-surface-600 dark:text-white/70": !e.selected,
        "text-highlight-contrast": e.selected
      }
    ]
  }),
  nodeChildren: {
    class: ["m-0 list-none p-0 pl-4 [&:not(ul)]:pl-0 [&:not(ul)]:my-[2px]"]
  },
  loadingIcon: {
    class: ["text-surface-500 dark:text-surface-0/70", "absolute top-[50%] right-[50%] -mt-2 -mr-2 animate-spin"]
  }
}, yl = {
  root: ({ props: e, state: t }) => ({
    class: [
      // Display and Position
      "inline-flex",
      "relative",
      // Shape
      "rounded-md",
      // Color and Background
      { "bg-surface-0 dark:bg-surface-950": !e.disabled },
      "border",
      { "border-surface-300 dark:border-surface-700": !e.invalid },
      // Invalid State
      "invalid:focus:ring-red-200",
      "invalid:hover:border-red-500",
      { "border-red-500 dark:border-red-400": e.invalid },
      // Transitions
      "transition-all",
      "duration-200",
      // States
      { "hover:border-surface-400 dark:hover:border-surface-600": !e.invalid },
      { "outline-none outline-offset-0 ring-1 ring-primary-500 dark:ring-primary-400 z-10": t.focused },
      // Misc
      "cursor-pointer",
      "select-none",
      { "bg-surface-200 dark:bg-surface-700 select-none pointer-events-none cursor-default": e.disabled }
    ]
  }),
  labelContainer: {
    class: ["overflow-hidden flex flex-auto cursor-pointer"]
  },
  label: ({ props: e, parent: t }) => {
    var r, n, o, a;
    return {
      class: [
        "block leading-[normal]",
        // Space
        "py-2 px-3",
        // Color
        "text-surface-800 dark:text-white/80",
        {
          "placeholder:text-transparent dark:placeholder:text-transparent": ((r = t.instance) == null ? void 0 : r.$name) == "FloatLabel",
          "!text-transparent dark:!text-transparent": ((n = t.instance) == null ? void 0 : n.$name) == "FloatLabel" && e.modelValue == null || ((o = e.modelValue) == null ? void 0 : o.length) == 0
        },
        // Filled State *for FloatLabel
        { filled: ((a = t.instance) == null ? void 0 : a.$name) == "FloatLabel" && e.modelValue !== null },
        // Transition
        "transition duration-200",
        // Misc
        "overflow-hidden whitespace-nowrap cursor-pointer overflow-ellipsis"
      ]
    };
  },
  dropdown: {
    class: [
      // Flexbox
      "flex items-center justify-center",
      "shrink-0",
      // Color and Background
      "bg-transparent",
      "text-surface-500",
      // Size
      "w-12",
      // Shape
      "rounded-r-md"
    ]
  },
  panel: {
    class: [
      // Colors
      "bg-surface-0 dark:bg-surface-900",
      "text-surface-700 dark:text-white/80",
      // Shape
      "border border-surface-300 dark:border-surface-700",
      "rounded-md",
      "shadow-md"
    ]
  },
  treeContainer: {
    class: [
      // Sizing
      "max-h-[200px]",
      // Misc
      "overflow-auto"
    ]
  },
  transition: {
    enterFromClass: "opacity-0 scale-y-[0.8]",
    enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
    leaveActiveClass: "transition-opacity duration-100 ease-linear",
    leaveToClass: "opacity-0"
  }
}, kl = {
  root: ({ props: e }) => ({
    class: [
      "relative",
      {
        "flex flex-col h-full": e.scrollHeight === "flex"
      }
    ]
  }),
  mask: {
    class: [
      // Position
      "absolute",
      "top-0 left-0",
      "z-20",
      // Flex & Alignment
      "flex items-center justify-center",
      // Size
      "w-full h-full",
      // Color
      "bg-surface-100/40 dark:bg-surface-800/40",
      // Transition
      "transition duration-200"
    ]
  },
  loadingIcon: {
    class: "w-8 h-8 animate-spin"
  },
  tableContainer: ({ props: e }) => ({
    class: [
      // Overflow
      {
        "relative overflow-auto": e.scrollable,
        "overflow-x-auto": e.resizableColumns
      }
    ]
  }),
  header: ({ props: e }) => ({
    class: [
      "font-semibold",
      // Shape
      e.showGridlines ? "border-x border-t border-b-0" : "border-y border-x-0",
      // Spacing
      "p-4",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-200 dark:border-surface-700",
      "text-surface-700 dark:text-white/80"
    ]
  }),
  footer: {
    class: [
      "font-semibold",
      // Shape
      "border-t-0 border-b border-x-0",
      // Spacing
      "p-4",
      // Color
      "bg-surface-0 dark:bg-surface-900",
      "border-surface-200 dark:border-surface-700",
      "text-surface-700 dark:text-white/80"
    ]
  },
  table: {
    class: [
      // Table & Width
      "border-collapse table-fixed w-full "
    ]
  },
  thead: ({ props: e }) => ({
    class: [
      // Position & Z-index
      {
        "top-0 z-40 sticky": e.scrollable
      }
    ]
  }),
  tbody: ({ props: e }) => ({
    class: [
      // Block Display
      {
        block: e.scrollable
      }
    ]
  }),
  tfoot: ({ props: e }) => ({
    class: [
      // Block Display
      {
        block: e.scrollable
      }
    ]
  }),
  headerRow: ({ props: e }) => ({
    class: [
      // Flexbox & Width
      {
        "flex flex-nowrap w-full": e.scrollable
      }
    ]
  }),
  row: ({ context: e, props: t }) => ({
    class: [
      // Flex
      { "flex flex-nowrap w-full": e.scrollable },
      // Color
      "text-surface-700 dark:text-white/80",
      { "bg-highlight": e.selected },
      { "bg-surface-0 text-surface-600 dark:bg-surface-900": !e.selected },
      // Hover & Flexbox
      {
        "hover:bg-surface-100 dark:bg-surface-800/50": e.selectable && !e.selected
      },
      "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 ring-inset dark:focus:ring-primary-400",
      // Transition
      { "transition duration-200": t.selectionMode && !e.selected || t.rowHover }
    ]
  }),
  headerCell: ({ context: e, props: t }) => ({
    class: [
      "font-semibold",
      "leading-[normal]",
      // Position
      { "sticky z-40": e.scrollable && e.scrollDirection === "both" && e.frozen },
      // Flex & Alignment
      {
        "flex flex-1 items-center": e.scrollable,
        "flex-initial shrink-0": e.scrollable && e.scrollDirection === "both" && !e.frozen
      },
      "text-left",
      // Shape
      { "first:border-l border-y border-r": e == null ? void 0 : e.showGridlines },
      "border-0 border-b border-solid",
      // Spacing
      (e == null ? void 0 : e.size) === "small" ? "py-[0.375rem] px-2" : (e == null ? void 0 : e.size) === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
      // Color
      (t.sortable === "" || t.sortable) && e.sorted ? "bg-highlight" : "bg-surface-0 text-surface-700 dark:text-white/80 dark:bg-surface-900",
      "border-surface-200 dark:border-surface-700",
      // States
      { "hover:bg-surface-100 dark:hover:bg-surface-80/50": (t.sortable === "" || t.sortable) && !(e != null && e.sorted) },
      "focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
      // Transition
      { "transition duration-200": t.sortable === "" || t.sortable },
      // Misc
      {
        "overflow-hidden relative bg-clip-padding": e.resizable && !e.frozen
      }
    ]
  }),
  column: {
    headerCell: ({ context: e, props: t }) => ({
      class: [
        "font-semibold",
        "leading-[normal]",
        // Position
        { "sticky z-40": e.scrollable && e.scrollDirection === "both" && e.frozen },
        // Flex & Alignment
        {
          "flex flex-1 items-center": e.scrollable,
          "flex-initial shrink-0": e.scrollable && e.scrollDirection === "both" && !e.frozen
        },
        "text-left",
        // Shape
        { "first:border-l border-y border-r": e == null ? void 0 : e.showGridlines },
        "border-0 border-b border-solid",
        // Spacing
        (e == null ? void 0 : e.size) === "small" ? "py-[0.375rem] px-2" : (e == null ? void 0 : e.size) === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
        // Color
        (t.sortable === "" || t.sortable) && e.sorted ? "bg-highlight" : "bg-surface-0 text-surface-700 dark:text-white/80 dark:bg-surface-900",
        "border-surface-200 dark:border-surface-700",
        // States
        { "hover:bg-surface-100 dark:hover:bg-surface-80/50": (t.sortable === "" || t.sortable) && !(e != null && e.sorted) },
        "focus-visible:outline-none focus-visible:outline-offset-0 focus-visible:ring-1 focus-visible:ring-inset focus-visible:ring-primary-500 dark:focus-visible:ring-primary-400",
        // Transition
        { "transition duration-200": t.sortable === "" || t.sortable },
        // Misc
        {
          "overflow-hidden relative bg-clip-padding": e.resizable && !e.frozen
        }
      ]
    }),
    bodyCell: ({ context: e }) => ({
      class: [
        // Font
        "leading-[normal]",
        // Position
        {
          sticky: e.scrollable && e.scrollDirection === "both" && e.frozen
        },
        // Flex & Alignment
        {
          "flex flex-1 items-center": e.scrollable,
          "flex-initial shrink-0": e.scrollable && e.scrollDirection === "both" && !e.frozen
        },
        "text-left",
        // Shape
        "border-0 border-b border-solid",
        "border-surface-200 dark:border-surface-700",
        {
          "border-x-0 border-l-0": !e.showGridlines
        },
        { "first:border-l border-r border-b": e == null ? void 0 : e.showGridlines },
        // Spacing
        (e == null ? void 0 : e.size) === "small" ? "py-[0.375rem] px-2" : (e == null ? void 0 : e.size) === "large" ? "py-[0.9375rem] px-5" : "py-3 px-4",
        // Misc
        {
          "cursor-pointer": e.selectable,
          sticky: e.scrollable && e.scrollDirection === "both" && e.frozen,
          "border-x-0 border-l-0": !e.showGridlines
        }
      ]
    }),
    bodyCellContent: "flex items-center gap-2",
    rowToggleButton: {
      class: [
        "relative",
        // Flex & Alignment
        "inline-flex items-center justify-center",
        "text-left align-middle",
        // Spacing
        "m-0 mr-2 p-0",
        // Size
        "w-7 h-7",
        // Shape
        "border-0 rounded-full",
        // Color
        "text-surface-700 dark:text-white/70",
        "border-transparent",
        // States
        "focus:outline-none focus:outline-offset-0 focus:ring-1 focus:ring-primary-500 dark:focus:ring-primary-400",
        "hover:text-surface-700 hover:bg-surface-50 dark:hover:bg-surface-800/50",
        // Transition
        "transition duration-200",
        // Misc
        "overflow-hidden",
        "cursor-pointer select-none"
      ]
    },
    sortIcon: ({ context: e }) => ({
      class: ["ml-2 inline-block", e.sorted ? "text-inherit" : "fill-surface-700 dark:fill-white/70"]
    }),
    columnResizer: {
      class: [
        "block",
        // Position
        "absolute top-0 right-0",
        // Sizing
        "w-2 h-full",
        // Spacing
        "m-0 p-0",
        // Color
        "border border-transparent",
        // Misc
        "cursor-col-resize"
      ]
    },
    transition: {
      enterFromClass: "opacity-0 scale-y-[0.8]",
      enterActiveClass: "transition-[transform,opacity] duration-[120ms] ease-[cubic-bezier(0,0,0.2,1)]",
      leaveActiveClass: "transition-opacity duration-100 ease-linear",
      leaveToClass: "opacity-0"
    }
  },
  columnResizeIndicator: {
    class: "absolute hidden w-[2px] z-20 bg-primary"
  }
}, wl = {
  global: di,
  directives: {
    badge: Bs,
    ripple: Bi,
    tooltip: vl
  },
  //forms
  autocomplete: Rs,
  select: eo,
  dropdown: eo,
  inputnumber: vi,
  inputtext: yi,
  datepicker: Qn,
  calendar: Qn,
  checkbox: Ys,
  radiobutton: Vi,
  toggleswitch: to,
  inputswitch: to,
  selectbutton: Ui,
  slider: Wi,
  rating: Mi,
  multiselect: Pi,
  togglebutton: hl,
  cascadeselect: qs,
  listbox: wi,
  colorpicker: Qs,
  inputgroup: gi,
  inputgroupaddon: hi,
  inputmask: mi,
  knob: ki,
  treeselect: yl,
  textarea: fl,
  password: Ei,
  iconfield: fi,
  floatlabel: ci,
  inputotp: xi,
  //buttons
  button: Us,
  buttongroup: Ks,
  splitbutton: qi,
  speeddial: Gi,
  //data
  paginator: Ai,
  datatable: ti,
  tree: xl,
  dataview: ri,
  organizationchart: ji,
  orderlist: Oi,
  picklist: Ni,
  treetable: kl,
  timeline: bl,
  //panels
  accordion: zs,
  accordionpanel: Ns,
  accordionheader: Es,
  accordioncontent: Ls,
  panel: zi,
  fieldset: ii,
  card: Ws,
  tabview: cl,
  divider: ai,
  toolbar: ml,
  scrollpanel: Di,
  splitter: Yi,
  splitterpanel: Ji,
  stepper: tl,
  steplist: Xi,
  step: Qi,
  stepitem: Zi,
  steppanels: el,
  deferred: ni,
  tab: nl,
  tabs: ll,
  tablist: ol,
  tabpanels: il,
  tabpanel: sl,
  //file
  fileupload: li,
  //menu
  contextmenu: ei,
  menu: Si,
  menubar: Ci,
  steps: rl,
  tieredmenu: pl,
  breadcrumb: Hs,
  panelmenu: Li,
  megamenu: _i,
  dock: si,
  tabmenu: al,
  //overlays
  dialog: oi,
  popover: Xn,
  sidebar: Xn,
  drawer: Zn,
  overlaypanel: Zn,
  confirmpopup: Xs,
  confirmdialog: Zs,
  //messages
  message: $i,
  toast: gl,
  //media
  carousel: Gs,
  galleria: ui,
  image: pi,
  //misc
  badge: Ms,
  overlaybadge: Ii,
  avatar: Fs,
  avatargroup: Vs,
  tag: ul,
  chip: Js,
  progressbar: Ri,
  skeleton: Ki,
  scrolltop: Hi,
  terminal: dl,
  blockui: Ds,
  metergroup: Ti,
  inplace: bi,
  progressspinner: Fi
};
var _l = Object.defineProperty, ro = Object.getOwnPropertySymbols, Sl = Object.prototype.hasOwnProperty, Cl = Object.prototype.propertyIsEnumerable, no = (e, t, r) => t in e ? _l(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, $l = (e, t) => {
  for (var r in t || (t = {}))
    Sl.call(t, r) && no(e, r, t[r]);
  if (ro)
    for (var r of ro(t))
      Cl.call(t, r) && no(e, r, t[r]);
  return e;
};
function bt(e) {
  return e == null || e === "" || Array.isArray(e) && e.length === 0 || !(e instanceof Date) && typeof e == "object" && Object.keys(e).length === 0;
}
function Sn(e) {
  return !!(e && e.constructor && e.call && e.apply);
}
function J(e) {
  return !bt(e);
}
function qe(e, t = !0) {
  return e instanceof Object && e.constructor === Object && (t || Object.keys(e).length !== 0);
}
function je(e, ...t) {
  return Sn(e) ? e(...t) : e;
}
function xe(e, t = !0) {
  return typeof e == "string" && (t || e !== "");
}
function Ne(e) {
  return xe(e) ? e.replace(/(-|_)/g, "").toLowerCase() : e;
}
function Cn(e, t = "", r = {}) {
  const n = Ne(t).split("."), o = n.shift();
  return o ? qe(e) ? Cn(je(e[Object.keys(e).find((a) => Ne(a) === o) || ""], r), n.join("."), r) : void 0 : je(e, r);
}
function Er(e, t = !0) {
  return Array.isArray(e) && (t || e.length !== 0);
}
function la(e) {
  return J(e) && !isNaN(e);
}
function Ze(e, t) {
  if (t) {
    const r = t.test(e);
    return t.lastIndex = 0, r;
  }
  return !1;
}
function Tl(...e) {
  const t = (r = {}, n = {}) => {
    const o = $l({}, r);
    return Object.keys(n).forEach((a) => {
      qe(n[a]) && a in r && qe(r[a]) ? o[a] = t(r[a], n[a]) : o[a] = n[a];
    }), o;
  };
  return e.reduce((r, n, o) => o === 0 ? n : t(r, n), {});
}
function Kt(e) {
  return e && e.replace(/\/\*(?:(?!\*\/)[\s\S])*\*\/|[\r\n\t]+/g, "").replace(/ {2,}/g, " ").replace(/ ([{:}]) /g, "$1").replace(/([;,]) /g, "$1").replace(/ !/g, "!").replace(/: /g, ":");
}
function Pl(e) {
  return xe(e, !1) ? e[0].toUpperCase() + e.slice(1) : e;
}
function ca(e) {
  return xe(e) ? e.replace(/(_)/g, "-").replace(/[A-Z]/g, (t, r) => r === 0 ? t : "-" + t.toLowerCase()).toLowerCase() : e;
}
function oo(e) {
  return xe(e) ? e.replace(/[A-Z]/g, (t, r) => r === 0 ? t : "." + t.toLowerCase()).toLowerCase() : e;
}
function ua() {
  const e = /* @__PURE__ */ new Map();
  return {
    on(t, r) {
      let n = e.get(t);
      return n ? n.push(r) : n = [r], e.set(t, n), this;
    },
    off(t, r) {
      let n = e.get(t);
      return n && n.splice(n.indexOf(r) >>> 0, 1), this;
    },
    emit(t, r) {
      let n = e.get(t);
      n && n.slice().map((o) => {
        o(r);
      });
    },
    clear() {
      e.clear();
    }
  };
}
var Ol = Object.defineProperty, jl = Object.defineProperties, Il = Object.getOwnPropertyDescriptors, jr = Object.getOwnPropertySymbols, da = Object.prototype.hasOwnProperty, fa = Object.prototype.propertyIsEnumerable, ao = (e, t, r) => t in e ? Ol(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r, Re = (e, t) => {
  for (var r in t || (t = {}))
    da.call(t, r) && ao(e, r, t[r]);
  if (jr)
    for (var r of jr(t))
      fa.call(t, r) && ao(e, r, t[r]);
  return e;
}, Qr = (e, t) => jl(e, Il(t)), Je = (e, t) => {
  var r = {};
  for (var n in e)
    da.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
  if (e != null && jr)
    for (var n of jr(e))
      t.indexOf(n) < 0 && fa.call(e, n) && (r[n] = e[n]);
  return r;
}, Al = ua(), Ee = Al;
function so(e, t) {
  Er(e) ? e.push(...t || []) : qe(e) && Object.assign(e, t);
}
function zl(e) {
  return qe(e) && e.hasOwnProperty("value") && e.hasOwnProperty("type") ? e.value : e;
}
function io(e, t = "") {
  return ["opacity", "z-index", "line-height", "font-weight", "flex", "flex-grow", "flex-shrink", "order"].some((n) => t.endsWith(n)) ? e : `${e}`.trim().split(" ").map((a) => la(a) ? `${a}px` : a).join(" ");
}
function Ll(e) {
  return e.replaceAll(/ /g, "").replace(/[^\w]/g, "-");
}
function cn(e = "", t = "") {
  return Ll(`${xe(e, !1) && xe(t, !1) ? `${e}-` : e}${t}`);
}
function pa(e = "", t = "") {
  return `--${cn(e, t)}`;
}
function ba(e, t = "", r = "", n = [], o) {
  if (xe(e)) {
    const a = /{([^}]*)}/g, s = e.trim();
    if (Ze(s, a)) {
      const i = s.replaceAll(a, (u) => {
        const b = u.replace(/{|}/g, "").split(".").filter((h) => !n.some((w) => Ze(h, w)));
        return `var(${pa(r, ca(b.join("-")))}${J(o) ? `, ${o}` : ""})`;
      }), l = /(\d+\s+[\+\-\*\/]\s+\d+)/g, c = /var\([^)]+\)/g;
      return Ze(i.replace(c, "0"), l) ? `calc(${i})` : i;
    }
    return io(s, t);
  } else if (la(e))
    return io(e, t);
}
function El(e, t, r) {
  xe(t, !1) && e.push(`${t}:${r};`);
}
function Ot(e, t) {
  return e ? `${e}{${t}}` : "";
}
var Wt = (...e) => Nl(q.getTheme(), ...e), Nl = (e = {}, t, r, n) => {
  if (t) {
    const { variable: o, options: a } = q.defaults || {}, { prefix: s, transform: i } = (e == null ? void 0 : e.options) || a || {}, c = Ze(t, /{([^}]*)}/g) ? t : `{${t}}`;
    return n === "value" || bt(n) && i === "strict" ? q.getTokenValue(t) : ba(c, void 0, s, [o.excludedKeyRegex], r);
  }
  return "";
};
function Rl(e, t = {}) {
  const r = q.defaults.variable, { prefix: n = r.prefix, selector: o = r.selector, excludedKeyRegex: a = r.excludedKeyRegex } = t, s = (c, u = "") => Object.entries(c).reduce(
    (p, [b, h]) => {
      const w = Ze(b, a) ? cn(u) : cn(u, ca(b)), C = zl(h);
      if (qe(C)) {
        const { variables: A, tokens: z } = s(C, w);
        so(p.tokens, z), so(p.variables, A);
      } else
        p.tokens.push((n ? w.replace(`${n}-`, "") : w).replaceAll("-", ".")), El(p.variables, pa(w), ba(C, w, n, [a]));
      return p;
    },
    { variables: [], tokens: [] }
  ), { variables: i, tokens: l } = s(e, n);
  return {
    value: i,
    tokens: l,
    declarations: i.join(""),
    css: Ot(o, i.join(""))
  };
}
var ze = {
  regex: {
    rules: {
      class: {
        pattern: /^\.([a-zA-Z][\w-]*)$/,
        resolve(e) {
          return { type: "class", selector: e, matched: this.pattern.test(e.trim()) };
        }
      },
      attr: {
        pattern: /^\[(.*)\]$/,
        resolve(e) {
          return { type: "attr", selector: `:root${e}`, matched: this.pattern.test(e.trim()) };
        }
      },
      media: {
        pattern: /^@media (.*)$/,
        resolve(e) {
          return { type: "media", selector: `${e}{:root{[CSS]}}`, matched: this.pattern.test(e.trim()) };
        }
      },
      system: {
        pattern: /^system$/,
        resolve(e) {
          return { type: "system", selector: "@media (prefers-color-scheme: dark){:root{[CSS]}}", matched: this.pattern.test(e.trim()) };
        }
      },
      custom: {
        resolve(e) {
          return { type: "custom", selector: e, matched: !0 };
        }
      }
    },
    resolve(e) {
      const t = Object.keys(this.rules).filter((r) => r !== "custom").map((r) => this.rules[r]);
      return [e].flat().map((r) => {
        var n;
        return (n = t.map((o) => o.resolve(r)).find((o) => o.matched)) != null ? n : this.rules.custom.resolve(r);
      });
    }
  },
  _toVariables(e, t) {
    return Rl(e, { prefix: t == null ? void 0 : t.prefix });
  },
  getCommon({ name: e = "", theme: t = {}, params: r, set: n, defaults: o }) {
    var a, s, i, l, c, u, p;
    const { preset: b, options: h } = t;
    let w, C, A, z, I, v, P;
    if (J(b) && h.transform !== "strict") {
      const { primitive: U, semantic: E, extend: ne } = b, te = E || {}, { colorScheme: $e } = te, ue = Je(te, ["colorScheme"]), be = ne || {}, { colorScheme: Te } = be, Pe = Je(be, ["colorScheme"]), Oe = $e || {}, { dark: De } = Oe, ee = Je(Oe, ["dark"]), K = Te || {}, { dark: B } = K, ge = Je(K, ["dark"]), he = J(U) ? this._toVariables({ primitive: U }, h) : {}, oe = J(ue) ? this._toVariables({ semantic: ue }, h) : {}, ae = J(ee) ? this._toVariables({ light: ee }, h) : {}, mt = J(De) ? this._toVariables({ dark: De }, h) : {}, tt = J(Pe) ? this._toVariables({ semantic: Pe }, h) : {}, br = J(ge) ? this._toVariables({ light: ge }, h) : {}, rt = J(B) ? this._toVariables({ dark: B }, h) : {}, [Tt, Vt] = [(a = he.declarations) != null ? a : "", he.tokens], [gr, vt] = [(s = oe.declarations) != null ? s : "", oe.tokens || []], [Gn, d] = [(i = ae.declarations) != null ? i : "", ae.tokens || []], [f, g] = [(l = mt.declarations) != null ? l : "", mt.tokens || []], [y, m] = [(c = tt.declarations) != null ? c : "", tt.tokens || []], [k, $] = [(u = br.declarations) != null ? u : "", br.tokens || []], [_, S] = [(p = rt.declarations) != null ? p : "", rt.tokens || []];
      w = this.transformCSS(e, Tt, "light", "variable", h, n, o), C = Vt;
      const x = this.transformCSS(e, `${gr}${Gn}`, "light", "variable", h, n, o), T = this.transformCSS(e, `${f}`, "dark", "variable", h, n, o);
      A = `${x}${T}`, z = [.../* @__PURE__ */ new Set([...vt, ...d, ...g])];
      const j = this.transformCSS(e, `${y}${k}color-scheme:light`, "light", "variable", h, n, o), O = this.transformCSS(e, `${_}color-scheme:dark`, "dark", "variable", h, n, o);
      I = `${j}${O}`, v = [.../* @__PURE__ */ new Set([...m, ...$, ...S])], P = je(b.css, { dt: Wt });
    }
    return {
      primitive: {
        css: w,
        tokens: C
      },
      semantic: {
        css: A,
        tokens: z
      },
      global: {
        css: I,
        tokens: v
      },
      style: P
    };
  },
  getPreset({ name: e = "", preset: t = {}, options: r, params: n, set: o, defaults: a, selector: s }) {
    var i, l, c;
    let u, p, b;
    if (J(t) && r.transform !== "strict") {
      const h = e.replace("-directive", ""), w = t, { colorScheme: C, extend: A, css: z } = w, I = Je(w, ["colorScheme", "extend", "css"]), v = A || {}, { colorScheme: P } = v, U = Je(v, ["colorScheme"]), E = C || {}, { dark: ne } = E, te = Je(E, ["dark"]), $e = P || {}, { dark: ue } = $e, be = Je($e, ["dark"]), Te = J(I) ? this._toVariables({ [h]: Re(Re({}, I), U) }, r) : {}, Pe = J(te) ? this._toVariables({ [h]: Re(Re({}, te), be) }, r) : {}, Oe = J(ne) ? this._toVariables({ [h]: Re(Re({}, ne), ue) }, r) : {}, [De, ee] = [(i = Te.declarations) != null ? i : "", Te.tokens || []], [K, B] = [(l = Pe.declarations) != null ? l : "", Pe.tokens || []], [ge, he] = [(c = Oe.declarations) != null ? c : "", Oe.tokens || []], oe = this.transformCSS(h, `${De}${K}`, "light", "variable", r, o, a, s), ae = this.transformCSS(h, ge, "dark", "variable", r, o, a, s);
      u = `${oe}${ae}`, p = [.../* @__PURE__ */ new Set([...ee, ...B, ...he])], b = je(z, { dt: Wt });
    }
    return {
      css: u,
      tokens: p,
      style: b
    };
  },
  getPresetC({ name: e = "", theme: t = {}, params: r, set: n, defaults: o }) {
    var a;
    const { preset: s, options: i } = t, l = (a = s == null ? void 0 : s.components) == null ? void 0 : a[e];
    return this.getPreset({ name: e, preset: l, options: i, params: r, set: n, defaults: o });
  },
  getPresetD({ name: e = "", theme: t = {}, params: r, set: n, defaults: o }) {
    var a;
    const s = e.replace("-directive", ""), { preset: i, options: l } = t, c = (a = i == null ? void 0 : i.directives) == null ? void 0 : a[s];
    return this.getPreset({ name: s, preset: c, options: l, params: r, set: n, defaults: o });
  },
  applyDarkColorScheme(e) {
    return !(e.darkModeSelector === "none" || e.darkModeSelector === !1);
  },
  getColorSchemeOption(e, t) {
    var r;
    return this.applyDarkColorScheme(e) ? this.regex.resolve(e.darkModeSelector === !0 ? t.options.darkModeSelector : (r = e.darkModeSelector) != null ? r : t.options.darkModeSelector) : [];
  },
  getLayerOrder(e, t = {}, r, n) {
    const { cssLayer: o } = t;
    return o ? `@layer ${je(o.order || "primeui", r)}` : "";
  },
  getCommonStyleSheet({ name: e = "", theme: t = {}, params: r, props: n = {}, set: o, defaults: a }) {
    const s = this.getCommon({ name: e, theme: t, params: r, set: o, defaults: a }), i = Object.entries(n).reduce((l, [c, u]) => l.push(`${c}="${u}"`) && l, []).join(" ");
    return Object.entries(s || {}).reduce((l, [c, u]) => {
      if (u != null && u.css) {
        const p = Kt(u == null ? void 0 : u.css), b = `${c}-variables`;
        l.push(`<style type="text/css" data-primevue-style-id="${b}" ${i}>${p}</style>`);
      }
      return l;
    }, []).join("");
  },
  getStyleSheet({ name: e = "", theme: t = {}, params: r, props: n = {}, set: o, defaults: a }) {
    var s;
    const i = { name: e, theme: t, params: r, set: o, defaults: a }, l = (s = e.includes("-directive") ? this.getPresetD(i) : this.getPresetC(i)) == null ? void 0 : s.css, c = Object.entries(n).reduce((u, [p, b]) => u.push(`${p}="${b}"`) && u, []).join(" ");
    return l ? `<style type="text/css" data-primevue-style-id="${e}-variables" ${c}>${Kt(l)}</style>` : "";
  },
  createTokens(e = {}, t, r = "", n = "", o = {}) {
    return Object.entries(e).forEach(([a, s]) => {
      const i = Ze(a, t.variable.excludedKeyRegex) ? r : r ? `${r}.${oo(a)}` : oo(a), l = n ? `${n}.${a}` : a;
      qe(s) ? this.createTokens(s, t, i, l, o) : (o[i] || (o[i] = {
        paths: [],
        computed(c, u = {}) {
          var p, b;
          return this.paths.length === 1 ? (p = this.paths[0]) == null ? void 0 : p.computed(this.paths[0].scheme, u.binding) : c && c !== "none" ? (b = this.paths.find((h) => h.scheme === c)) == null ? void 0 : b.computed(c, u.binding) : this.paths.map((h) => h.computed(h.scheme, u[h.scheme]));
        }
      }), o[i].paths.push({
        path: l,
        value: s,
        scheme: l.includes("colorScheme.light") ? "light" : l.includes("colorScheme.dark") ? "dark" : "none",
        computed(c, u = {}) {
          const p = /{([^}]*)}/g;
          let b = s;
          if (u.name = this.path, u.binding || (u.binding = {}), Ze(s, p)) {
            const w = s.trim().replaceAll(p, (z) => {
              var I;
              const v = z.replace(/{|}/g, ""), P = (I = o[v]) == null ? void 0 : I.computed(c, u);
              return Er(P) && P.length === 2 ? `light-dark(${P[0].value},${P[1].value})` : P == null ? void 0 : P.value;
            }), C = /(\d+\w*\s+[\+\-\*\/]\s+\d+\w*)/g, A = /var\([^)]+\)/g;
            b = Ze(w.replace(A, "0"), C) ? `calc(${w})` : w;
          }
          return bt(u.binding) && delete u.binding, {
            colorScheme: c,
            path: this.path,
            paths: u,
            value: b.includes("undefined") ? void 0 : b
          };
        }
      }));
    }), o;
  },
  getTokenValue(e, t, r) {
    var n;
    const a = ((l) => l.split(".").filter((u) => !Ze(u.toLowerCase(), r.variable.excludedKeyRegex)).join("."))(t), s = t.includes("colorScheme.light") ? "light" : t.includes("colorScheme.dark") ? "dark" : void 0, i = [(n = e[a]) == null ? void 0 : n.computed(s)].flat().filter((l) => l);
    return i.length === 1 ? i[0].value : i.reduce((l = {}, c) => {
      const u = c, { colorScheme: p } = u, b = Je(u, ["colorScheme"]);
      return l[p] = b, l;
    }, void 0);
  },
  getSelectorRule(e, t, r, n) {
    return r === "class" || r === "attr" ? Ot(J(t) ? `${e}${t},${e} ${t}` : e, n) : Ot(e, J(t) ? Ot(t, n) : n);
  },
  transformCSS(e, t, r, n, o = {}, a, s, i) {
    if (J(t)) {
      const { cssLayer: l } = o;
      if (n !== "style") {
        const c = this.getColorSchemeOption(o, s);
        t = r === "dark" ? c.reduce((u, { type: p, selector: b }) => (J(b) && (u += b.includes("[CSS]") ? b.replace("[CSS]", t) : this.getSelectorRule(b, i, p, t)), u), "") : Ot(i ?? ":root", t);
      }
      if (l) {
        const c = {
          name: "primeui"
        };
        qe(l) && (c.name = je(l.name, { name: e, type: n })), J(c.name) && (t = Ot(`@layer ${c.name}`, t), a == null || a.layerNames(c.name));
      }
      return t;
    }
    return "";
  }
}, q = {
  defaults: {
    variable: {
      prefix: "p",
      selector: ":root",
      excludedKeyRegex: /^(primitive|semantic|components|directives|variables|colorscheme|light|dark|common|root|states|extend|css)$/gi
    },
    options: {
      prefix: "p",
      darkModeSelector: "system",
      cssLayer: !1
    }
  },
  _theme: void 0,
  _layerNames: /* @__PURE__ */ new Set(),
  _loadedStyleNames: /* @__PURE__ */ new Set(),
  _loadingStyles: /* @__PURE__ */ new Set(),
  _tokens: {},
  update(e = {}) {
    const { theme: t } = e;
    t && (this._theme = Qr(Re({}, t), {
      options: Re(Re({}, this.defaults.options), t.options)
    }), this._tokens = ze.createTokens(this.preset, this.defaults), this.clearLoadedStyleNames());
  },
  get theme() {
    return this._theme;
  },
  get preset() {
    var e;
    return ((e = this.theme) == null ? void 0 : e.preset) || {};
  },
  get options() {
    var e;
    return ((e = this.theme) == null ? void 0 : e.options) || {};
  },
  get tokens() {
    return this._tokens;
  },
  getTheme() {
    return this.theme;
  },
  setTheme(e) {
    this.update({ theme: e }), Ee.emit("theme:change", e);
  },
  getPreset() {
    return this.preset;
  },
  setPreset(e) {
    this._theme = Qr(Re({}, this.theme), { preset: e }), this._tokens = ze.createTokens(e, this.defaults), this.clearLoadedStyleNames(), Ee.emit("preset:change", e), Ee.emit("theme:change", this.theme);
  },
  getOptions() {
    return this.options;
  },
  setOptions(e) {
    this._theme = Qr(Re({}, this.theme), { options: e }), this.clearLoadedStyleNames(), Ee.emit("options:change", e), Ee.emit("theme:change", this.theme);
  },
  getLayerNames() {
    return [...this._layerNames];
  },
  setLayerNames(e) {
    this._layerNames.add(e);
  },
  getLoadedStyleNames() {
    return this._loadedStyleNames;
  },
  isStyleNameLoaded(e) {
    return this._loadedStyleNames.has(e);
  },
  setLoadedStyleName(e) {
    this._loadedStyleNames.add(e);
  },
  deleteLoadedStyleName(e) {
    this._loadedStyleNames.delete(e);
  },
  clearLoadedStyleNames() {
    this._loadedStyleNames.clear();
  },
  getTokenValue(e) {
    return ze.getTokenValue(this.tokens, e, this.defaults);
  },
  getCommon(e = "", t) {
    return ze.getCommon({ name: e, theme: this.theme, params: t, defaults: this.defaults, set: { layerNames: this.setLayerNames.bind(this) } });
  },
  getComponent(e = "", t) {
    const r = { name: e, theme: this.theme, params: t, defaults: this.defaults, set: { layerNames: this.setLayerNames.bind(this) } };
    return ze.getPresetC(r);
  },
  getDirective(e = "", t) {
    const r = { name: e, theme: this.theme, params: t, defaults: this.defaults, set: { layerNames: this.setLayerNames.bind(this) } };
    return ze.getPresetD(r);
  },
  getCustomPreset(e = "", t, r, n) {
    const o = { name: e, preset: t, options: this.options, selector: r, params: n, defaults: this.defaults, set: { layerNames: this.setLayerNames.bind(this) } };
    return ze.getPreset(o);
  },
  getLayerOrderCSS(e = "") {
    return ze.getLayerOrder(e, this.options, { names: this.getLayerNames() }, this.defaults);
  },
  transformCSS(e = "", t, r = "style", n) {
    return ze.transformCSS(e, t, n, r, this.options, { layerNames: this.setLayerNames.bind(this) }, this.defaults);
  },
  getCommonStyleSheet(e = "", t, r = {}) {
    return ze.getCommonStyleSheet({ name: e, theme: this.theme, params: t, props: r, defaults: this.defaults, set: { layerNames: this.setLayerNames.bind(this) } });
  },
  getStyleSheet(e, t, r = {}) {
    return ze.getStyleSheet({ name: e, theme: this.theme, params: t, props: r, defaults: this.defaults, set: { layerNames: this.setLayerNames.bind(this) } });
  },
  onStyleMounted(e) {
    this._loadingStyles.add(e);
  },
  onStyleUpdated(e) {
    this._loadingStyles.add(e);
  },
  onStyleLoaded(e, { name: t }) {
    this._loadingStyles.size && (this._loadingStyles.delete(t), Ee.emit(`theme:${t}:load`, e), !this._loadingStyles.size && Ee.emit("theme:load"));
  }
};
function Fl(e, t) {
  return e ? e.classList ? e.classList.contains(t) : new RegExp("(^| )" + t + "( |$)", "gi").test(e.className) : !1;
}
function Vl(e, t) {
  if (e && t) {
    const r = (n) => {
      Fl(e, n) || (e.classList ? e.classList.add(n) : e.className += " " + n);
    };
    [t].flat().filter(Boolean).forEach((n) => n.split(" ").forEach(r));
  }
}
function Zr(e, t) {
  if (e && t) {
    const r = (n) => {
      e.classList ? e.classList.remove(n) : e.className = e.className.replace(new RegExp("(^|\\b)" + n.split(" ").join("|") + "(\\b|$)", "gi"), " ");
    };
    [t].flat().filter(Boolean).forEach((n) => n.split(" ").forEach(r));
  }
}
function Ml(e, t) {
  return e instanceof HTMLElement ? e.offsetWidth : 0;
}
function Nr(e) {
  return typeof HTMLElement == "object" ? e instanceof HTMLElement : e && typeof e == "object" && e !== null && e.nodeType === 1 && typeof e.nodeName == "string";
}
function Ir(e, t = {}) {
  if (Nr(e)) {
    const r = (n, o) => {
      var a, s;
      const i = (a = e == null ? void 0 : e.$attrs) != null && a[n] ? [(s = e == null ? void 0 : e.$attrs) == null ? void 0 : s[n]] : [];
      return [o].flat().reduce((l, c) => {
        if (c != null) {
          const u = typeof c;
          if (u === "string" || u === "number")
            l.push(c);
          else if (u === "object") {
            const p = Array.isArray(c) ? r(n, c) : Object.entries(c).map(([b, h]) => n === "style" && (h || h === 0) ? `${b.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase()}:${h}` : h ? b : void 0);
            l = p.length ? l.concat(p.filter((b) => !!b)) : l;
          }
        }
        return l;
      }, i);
    };
    Object.entries(t).forEach(([n, o]) => {
      if (o != null) {
        const a = n.match(/^on(.+)/);
        a ? e.addEventListener(a[1].toLowerCase(), o) : n === "p-bind" ? Ir(e, o) : (o = n === "class" ? [...new Set(r("class", o))].join(" ").trim() : n === "style" ? r("style", o).join(";").trim() : o, (e.$attrs = e.$attrs || {}) && (e.$attrs[n] = o), e.setAttribute(n, o));
      }
    });
  }
}
function Bl(e, t = {}, ...r) {
  {
    const n = document.createElement(e);
    return Ir(n, t), n.append(...r), n;
  }
}
function Dl(e, t) {
  return Nr(e) ? e.matches(t) ? e : e.querySelector(t) : null;
}
function Hl(e, t) {
  if (Nr(e)) {
    const r = e.getAttribute(t);
    return isNaN(r) ? r === "true" || r === "false" ? r === "true" : r : +r;
  }
}
function lo(e) {
  if (e) {
    let t = e.offsetHeight, r = getComputedStyle(e);
    return t -= parseFloat(r.paddingTop) + parseFloat(r.paddingBottom) + parseFloat(r.borderTopWidth) + parseFloat(r.borderBottomWidth), t;
  }
  return 0;
}
function Ul(e) {
  if (e) {
    let t = e.parentNode;
    return t && t instanceof ShadowRoot && t.host && (t = t.host), t;
  }
  return null;
}
function Kl(e) {
  if (e) {
    let t = e.getBoundingClientRect();
    return {
      top: t.top + (window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0),
      left: t.left + (window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft || 0)
    };
  }
  return {
    top: "auto",
    left: "auto"
  };
}
function Wl(e, t) {
  return e ? e.offsetHeight : 0;
}
function Gl(e) {
  return !!(e !== null && typeof e < "u" && e.nodeName && Ul(e));
}
function co(e) {
  if (e) {
    let t = e.offsetWidth, r = getComputedStyle(e);
    return t -= parseFloat(r.paddingLeft) + parseFloat(r.paddingRight) + parseFloat(r.borderLeftWidth) + parseFloat(r.borderRightWidth), t;
  }
  return 0;
}
function ga() {
  return !!(typeof window < "u" && window.document && window.document.createElement);
}
function ql(e, t = "", r) {
  Nr(e) && r !== null && r !== void 0 && e.setAttribute(t, r);
}
var hr = {};
function ha(e = "pui_id_") {
  return hr.hasOwnProperty(e) || (hr[e] = 0), hr[e]++, `${e}${hr[e]}`;
}
var le = {
  STARTS_WITH: "startsWith",
  CONTAINS: "contains",
  NOT_CONTAINS: "notContains",
  ENDS_WITH: "endsWith",
  EQUALS: "equals",
  NOT_EQUALS: "notEquals",
  LESS_THAN: "lt",
  LESS_THAN_OR_EQUAL_TO: "lte",
  GREATER_THAN: "gt",
  GREATER_THAN_OR_EQUAL_TO: "gte",
  DATE_IS: "dateIs",
  DATE_IS_NOT: "dateIsNot",
  DATE_BEFORE: "dateBefore",
  DATE_AFTER: "dateAfter"
};
/**
* @vue/shared v3.4.37
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function $n(e, t) {
  const r = new Set(e.split(","));
  return t ? (n) => r.has(n.toLowerCase()) : (n) => r.has(n);
}
const Z = {}, At = [], Ie = () => {
}, Yl = () => !1, Rr = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // uppercase letter
(e.charCodeAt(2) > 122 || e.charCodeAt(2) < 97), Tn = (e) => e.startsWith("onUpdate:"), ye = Object.assign, Pn = (e, t) => {
  const r = e.indexOf(t);
  r > -1 && e.splice(r, 1);
}, Jl = Object.prototype.hasOwnProperty, H = (e, t) => Jl.call(e, t), L = Array.isArray, zt = (e) => fr(e) === "[object Map]", Fr = (e) => fr(e) === "[object Set]", uo = (e) => fr(e) === "[object Date]", R = (e) => typeof e == "function", re = (e) => typeof e == "string", Ye = (e) => typeof e == "symbol", X = (e) => e !== null && typeof e == "object", ma = (e) => (X(e) || R(e)) && R(e.then) && R(e.catch), va = Object.prototype.toString, fr = (e) => va.call(e), Ql = (e) => fr(e).slice(8, -1), xa = (e) => fr(e) === "[object Object]", On = (e) => re(e) && e !== "NaN" && e[0] !== "-" && "" + parseInt(e, 10) === e, Gt = /* @__PURE__ */ $n(
  // the leading comma is intentional so empty string "" is also included
  ",key,ref,ref_for,ref_key,onVnodeBeforeMount,onVnodeMounted,onVnodeBeforeUpdate,onVnodeUpdated,onVnodeBeforeUnmount,onVnodeUnmounted"
), Vr = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (r) => t[r] || (t[r] = e(r));
}, Zl = /-(\w)/g, Be = Vr((e) => e.replace(Zl, (t, r) => r ? r.toUpperCase() : "")), Xl = /\B([A-Z])/g, $t = Vr(
  (e) => e.replace(Xl, "-$1").toLowerCase()
), Mr = Vr((e) => e.charAt(0).toUpperCase() + e.slice(1)), Xr = Vr((e) => e ? `on${Mr(e)}` : ""), ft = (e, t) => !Object.is(e, t), Cr = (e, ...t) => {
  for (let r = 0; r < e.length; r++)
    e[r](...t);
}, ya = (e, t, r, n = !1) => {
  Object.defineProperty(e, t, {
    configurable: !0,
    enumerable: !1,
    writable: n,
    value: r
  });
}, ec = (e) => {
  const t = parseFloat(e);
  return isNaN(t) ? e : t;
};
let fo;
const ka = () => fo || (fo = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : typeof global < "u" ? global : {});
function jn(e) {
  if (L(e)) {
    const t = {};
    for (let r = 0; r < e.length; r++) {
      const n = e[r], o = re(n) ? oc(n) : jn(n);
      if (o)
        for (const a in o)
          t[a] = o[a];
    }
    return t;
  } else if (re(e) || X(e))
    return e;
}
const tc = /;(?![^(]*\))/g, rc = /:([^]+)/, nc = /\/\*[^]*?\*\//g;
function oc(e) {
  const t = {};
  return e.replace(nc, "").split(tc).forEach((r) => {
    if (r) {
      const n = r.split(rc);
      n.length > 1 && (t[n[0].trim()] = n[1].trim());
    }
  }), t;
}
function wt(e) {
  let t = "";
  if (re(e))
    t = e;
  else if (L(e))
    for (let r = 0; r < e.length; r++) {
      const n = wt(e[r]);
      n && (t += n + " ");
    }
  else if (X(e))
    for (const r in e)
      e[r] && (t += r + " ");
  return t.trim();
}
const ac = "itemscope,allowfullscreen,formnovalidate,ismap,nomodule,novalidate,readonly", sc = /* @__PURE__ */ $n(ac);
function wa(e) {
  return !!e || e === "";
}
function ic(e, t) {
  if (e.length !== t.length) return !1;
  let r = !0;
  for (let n = 0; r && n < e.length; n++)
    r = Br(e[n], t[n]);
  return r;
}
function Br(e, t) {
  if (e === t) return !0;
  let r = uo(e), n = uo(t);
  if (r || n)
    return r && n ? e.getTime() === t.getTime() : !1;
  if (r = Ye(e), n = Ye(t), r || n)
    return e === t;
  if (r = L(e), n = L(t), r || n)
    return r && n ? ic(e, t) : !1;
  if (r = X(e), n = X(t), r || n) {
    if (!r || !n)
      return !1;
    const o = Object.keys(e).length, a = Object.keys(t).length;
    if (o !== a)
      return !1;
    for (const s in e) {
      const i = e.hasOwnProperty(s), l = t.hasOwnProperty(s);
      if (i && !l || !i && l || !Br(e[s], t[s]))
        return !1;
    }
  }
  return String(e) === String(t);
}
function _a(e, t) {
  return e.findIndex((r) => Br(r, t));
}
const Sa = (e) => !!(e && e.__v_isRef === !0), In = (e) => re(e) ? e : e == null ? "" : L(e) || X(e) && (e.toString === va || !R(e.toString)) ? Sa(e) ? In(e.value) : JSON.stringify(e, Ca, 2) : String(e), Ca = (e, t) => Sa(t) ? Ca(e, t.value) : zt(t) ? {
  [`Map(${t.size})`]: [...t.entries()].reduce(
    (r, [n, o], a) => (r[en(n, a) + " =>"] = o, r),
    {}
  )
} : Fr(t) ? {
  [`Set(${t.size})`]: [...t.values()].map((r) => en(r))
} : Ye(t) ? en(t) : X(t) && !L(t) && !xa(t) ? String(t) : t, en = (e, t = "") => {
  var r;
  return (
    // Symbol.description in es2019+ so we need to cast here to pass
    // the lib: es2016 check
    Ye(e) ? `Symbol(${(r = e.description) != null ? r : t})` : e
  );
};
/**
* @vue/reactivity v3.4.37
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
let Le;
class lc {
  constructor(t = !1) {
    this.detached = t, this._active = !0, this.effects = [], this.cleanups = [], this.parent = Le, !t && Le && (this.index = (Le.scopes || (Le.scopes = [])).push(
      this
    ) - 1);
  }
  get active() {
    return this._active;
  }
  run(t) {
    if (this._active) {
      const r = Le;
      try {
        return Le = this, t();
      } finally {
        Le = r;
      }
    }
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  on() {
    Le = this;
  }
  /**
   * This should only be called on non-detached scopes
   * @internal
   */
  off() {
    Le = this.parent;
  }
  stop(t) {
    if (this._active) {
      let r, n;
      for (r = 0, n = this.effects.length; r < n; r++)
        this.effects[r].stop();
      for (r = 0, n = this.cleanups.length; r < n; r++)
        this.cleanups[r]();
      if (this.scopes)
        for (r = 0, n = this.scopes.length; r < n; r++)
          this.scopes[r].stop(!0);
      if (!this.detached && this.parent && !t) {
        const o = this.parent.scopes.pop();
        o && o !== this && (this.parent.scopes[this.index] = o, o.index = this.index);
      }
      this.parent = void 0, this._active = !1;
    }
  }
}
function cc(e, t = Le) {
  t && t.active && t.effects.push(e);
}
function uc() {
  return Le;
}
let _t;
class An {
  constructor(t, r, n, o) {
    this.fn = t, this.trigger = r, this.scheduler = n, this.active = !0, this.deps = [], this._dirtyLevel = 4, this._trackId = 0, this._runnings = 0, this._shouldSchedule = !1, this._depsLength = 0, cc(this, o);
  }
  get dirty() {
    if (this._dirtyLevel === 2 || this._dirtyLevel === 3) {
      this._dirtyLevel = 1, gt();
      for (let t = 0; t < this._depsLength; t++) {
        const r = this.deps[t];
        if (r.computed && (dc(r.computed), this._dirtyLevel >= 4))
          break;
      }
      this._dirtyLevel === 1 && (this._dirtyLevel = 0), ht();
    }
    return this._dirtyLevel >= 4;
  }
  set dirty(t) {
    this._dirtyLevel = t ? 4 : 0;
  }
  run() {
    if (this._dirtyLevel = 0, !this.active)
      return this.fn();
    let t = ut, r = _t;
    try {
      return ut = !0, _t = this, this._runnings++, po(this), this.fn();
    } finally {
      bo(this), this._runnings--, _t = r, ut = t;
    }
  }
  stop() {
    this.active && (po(this), bo(this), this.onStop && this.onStop(), this.active = !1);
  }
}
function dc(e) {
  return e.value;
}
function po(e) {
  e._trackId++, e._depsLength = 0;
}
function bo(e) {
  if (e.deps.length > e._depsLength) {
    for (let t = e._depsLength; t < e.deps.length; t++)
      $a(e.deps[t], e);
    e.deps.length = e._depsLength;
  }
}
function $a(e, t) {
  const r = e.get(t);
  r !== void 0 && t._trackId !== r && (e.delete(t), e.size === 0 && e.cleanup());
}
let ut = !0, un = 0;
const Ta = [];
function gt() {
  Ta.push(ut), ut = !1;
}
function ht() {
  const e = Ta.pop();
  ut = e === void 0 ? !0 : e;
}
function zn() {
  un++;
}
function Ln() {
  for (un--; !un && dn.length; )
    dn.shift()();
}
function Pa(e, t, r) {
  if (t.get(e) !== e._trackId) {
    t.set(e, e._trackId);
    const n = e.deps[e._depsLength];
    n !== t ? (n && $a(n, e), e.deps[e._depsLength++] = t) : e._depsLength++;
  }
}
const dn = [];
function Oa(e, t, r) {
  zn();
  for (const n of e.keys()) {
    let o;
    n._dirtyLevel < t && (o ?? (o = e.get(n) === n._trackId)) && (n._shouldSchedule || (n._shouldSchedule = n._dirtyLevel === 0), n._dirtyLevel = t), n._shouldSchedule && (o ?? (o = e.get(n) === n._trackId)) && (n.trigger(), (!n._runnings || n.allowRecurse) && n._dirtyLevel !== 2 && (n._shouldSchedule = !1, n.scheduler && dn.push(n.scheduler)));
  }
  Ln();
}
const ja = (e, t) => {
  const r = /* @__PURE__ */ new Map();
  return r.cleanup = e, r.computed = t, r;
}, fn = /* @__PURE__ */ new WeakMap(), St = Symbol(""), pn = Symbol("");
function ke(e, t, r) {
  if (ut && _t) {
    let n = fn.get(e);
    n || fn.set(e, n = /* @__PURE__ */ new Map());
    let o = n.get(r);
    o || n.set(r, o = ja(() => n.delete(r))), Pa(
      _t,
      o
    );
  }
}
function Xe(e, t, r, n, o, a) {
  const s = fn.get(e);
  if (!s)
    return;
  let i = [];
  if (t === "clear")
    i = [...s.values()];
  else if (r === "length" && L(e)) {
    const l = Number(n);
    s.forEach((c, u) => {
      (u === "length" || !Ye(u) && u >= l) && i.push(c);
    });
  } else
    switch (r !== void 0 && i.push(s.get(r)), t) {
      case "add":
        L(e) ? On(r) && i.push(s.get("length")) : (i.push(s.get(St)), zt(e) && i.push(s.get(pn)));
        break;
      case "delete":
        L(e) || (i.push(s.get(St)), zt(e) && i.push(s.get(pn)));
        break;
      case "set":
        zt(e) && i.push(s.get(St));
        break;
    }
  zn();
  for (const l of i)
    l && Oa(
      l,
      4
    );
  Ln();
}
const fc = /* @__PURE__ */ $n("__proto__,__v_isRef,__isVue"), Ia = new Set(
  /* @__PURE__ */ Object.getOwnPropertyNames(Symbol).filter((e) => e !== "arguments" && e !== "caller").map((e) => Symbol[e]).filter(Ye)
), go = /* @__PURE__ */ pc();
function pc() {
  const e = {};
  return ["includes", "indexOf", "lastIndexOf"].forEach((t) => {
    e[t] = function(...r) {
      const n = W(this);
      for (let a = 0, s = this.length; a < s; a++)
        ke(n, "get", a + "");
      const o = n[t](...r);
      return o === -1 || o === !1 ? n[t](...r.map(W)) : o;
    };
  }), ["push", "pop", "shift", "unshift", "splice"].forEach((t) => {
    e[t] = function(...r) {
      gt(), zn();
      const n = W(this)[t].apply(this, r);
      return Ln(), ht(), n;
    };
  }), e;
}
function bc(e) {
  Ye(e) || (e = String(e));
  const t = W(this);
  return ke(t, "has", e), t.hasOwnProperty(e);
}
class Aa {
  constructor(t = !1, r = !1) {
    this._isReadonly = t, this._isShallow = r;
  }
  get(t, r, n) {
    const o = this._isReadonly, a = this._isShallow;
    if (r === "__v_isReactive")
      return !o;
    if (r === "__v_isReadonly")
      return o;
    if (r === "__v_isShallow")
      return a;
    if (r === "__v_raw")
      return n === (o ? a ? Tc : Na : a ? Ea : La).get(t) || // receiver is not the reactive proxy, but has the same prototype
      // this means the receiver is a user proxy of the reactive proxy
      Object.getPrototypeOf(t) === Object.getPrototypeOf(n) ? t : void 0;
    const s = L(t);
    if (!o) {
      if (s && H(go, r))
        return Reflect.get(go, r, n);
      if (r === "hasOwnProperty")
        return bc;
    }
    const i = Reflect.get(t, r, n);
    return (Ye(r) ? Ia.has(r) : fc(r)) || (o || ke(t, "get", r), a) ? i : we(i) ? s && On(r) ? i : i.value : X(i) ? o ? Rn(i) : Hr(i) : i;
  }
}
class za extends Aa {
  constructor(t = !1) {
    super(!1, t);
  }
  set(t, r, n, o) {
    let a = t[r];
    if (!this._isShallow) {
      const l = Ct(a);
      if (!Nt(n) && !Ct(n) && (a = W(a), n = W(n)), !L(t) && we(a) && !we(n))
        return l ? !1 : (a.value = n, !0);
    }
    const s = L(t) && On(r) ? Number(r) < t.length : H(t, r), i = Reflect.set(t, r, n, o);
    return t === W(o) && (s ? ft(n, a) && Xe(t, "set", r, n) : Xe(t, "add", r, n)), i;
  }
  deleteProperty(t, r) {
    const n = H(t, r);
    t[r];
    const o = Reflect.deleteProperty(t, r);
    return o && n && Xe(t, "delete", r, void 0), o;
  }
  has(t, r) {
    const n = Reflect.has(t, r);
    return (!Ye(r) || !Ia.has(r)) && ke(t, "has", r), n;
  }
  ownKeys(t) {
    return ke(
      t,
      "iterate",
      L(t) ? "length" : St
    ), Reflect.ownKeys(t);
  }
}
class gc extends Aa {
  constructor(t = !1) {
    super(!0, t);
  }
  set(t, r) {
    return !0;
  }
  deleteProperty(t, r) {
    return !0;
  }
}
const hc = /* @__PURE__ */ new za(), mc = /* @__PURE__ */ new gc(), vc = /* @__PURE__ */ new za(
  !0
);
const En = (e) => e, Dr = (e) => Reflect.getPrototypeOf(e);
function mr(e, t, r = !1, n = !1) {
  e = e.__v_raw;
  const o = W(e), a = W(t);
  r || (ft(t, a) && ke(o, "get", t), ke(o, "get", a));
  const { has: s } = Dr(o), i = n ? En : r ? Vn : er;
  if (s.call(o, t))
    return i(e.get(t));
  if (s.call(o, a))
    return i(e.get(a));
  e !== o && e.get(t);
}
function vr(e, t = !1) {
  const r = this.__v_raw, n = W(r), o = W(e);
  return t || (ft(e, o) && ke(n, "has", e), ke(n, "has", o)), e === o ? r.has(e) : r.has(e) || r.has(o);
}
function xr(e, t = !1) {
  return e = e.__v_raw, !t && ke(W(e), "iterate", St), Reflect.get(e, "size", e);
}
function ho(e, t = !1) {
  !t && !Nt(e) && !Ct(e) && (e = W(e));
  const r = W(this);
  return Dr(r).has.call(r, e) || (r.add(e), Xe(r, "add", e, e)), this;
}
function mo(e, t, r = !1) {
  !r && !Nt(t) && !Ct(t) && (t = W(t));
  const n = W(this), { has: o, get: a } = Dr(n);
  let s = o.call(n, e);
  s || (e = W(e), s = o.call(n, e));
  const i = a.call(n, e);
  return n.set(e, t), s ? ft(t, i) && Xe(n, "set", e, t) : Xe(n, "add", e, t), this;
}
function vo(e) {
  const t = W(this), { has: r, get: n } = Dr(t);
  let o = r.call(t, e);
  o || (e = W(e), o = r.call(t, e)), n && n.call(t, e);
  const a = t.delete(e);
  return o && Xe(t, "delete", e, void 0), a;
}
function xo() {
  const e = W(this), t = e.size !== 0, r = e.clear();
  return t && Xe(e, "clear", void 0, void 0), r;
}
function yr(e, t) {
  return function(n, o) {
    const a = this, s = a.__v_raw, i = W(s), l = t ? En : e ? Vn : er;
    return !e && ke(i, "iterate", St), s.forEach((c, u) => n.call(o, l(c), l(u), a));
  };
}
function kr(e, t, r) {
  return function(...n) {
    const o = this.__v_raw, a = W(o), s = zt(a), i = e === "entries" || e === Symbol.iterator && s, l = e === "keys" && s, c = o[e](...n), u = r ? En : t ? Vn : er;
    return !t && ke(
      a,
      "iterate",
      l ? pn : St
    ), {
      // iterator protocol
      next() {
        const { value: p, done: b } = c.next();
        return b ? { value: p, done: b } : {
          value: i ? [u(p[0]), u(p[1])] : u(p),
          done: b
        };
      },
      // iterable protocol
      [Symbol.iterator]() {
        return this;
      }
    };
  };
}
function nt(e) {
  return function(...t) {
    return e === "delete" ? !1 : e === "clear" ? void 0 : this;
  };
}
function xc() {
  const e = {
    get(a) {
      return mr(this, a);
    },
    get size() {
      return xr(this);
    },
    has: vr,
    add: ho,
    set: mo,
    delete: vo,
    clear: xo,
    forEach: yr(!1, !1)
  }, t = {
    get(a) {
      return mr(this, a, !1, !0);
    },
    get size() {
      return xr(this);
    },
    has: vr,
    add(a) {
      return ho.call(this, a, !0);
    },
    set(a, s) {
      return mo.call(this, a, s, !0);
    },
    delete: vo,
    clear: xo,
    forEach: yr(!1, !0)
  }, r = {
    get(a) {
      return mr(this, a, !0);
    },
    get size() {
      return xr(this, !0);
    },
    has(a) {
      return vr.call(this, a, !0);
    },
    add: nt("add"),
    set: nt("set"),
    delete: nt("delete"),
    clear: nt("clear"),
    forEach: yr(!0, !1)
  }, n = {
    get(a) {
      return mr(this, a, !0, !0);
    },
    get size() {
      return xr(this, !0);
    },
    has(a) {
      return vr.call(this, a, !0);
    },
    add: nt("add"),
    set: nt("set"),
    delete: nt("delete"),
    clear: nt("clear"),
    forEach: yr(!0, !0)
  };
  return [
    "keys",
    "values",
    "entries",
    Symbol.iterator
  ].forEach((a) => {
    e[a] = kr(a, !1, !1), r[a] = kr(a, !0, !1), t[a] = kr(a, !1, !0), n[a] = kr(
      a,
      !0,
      !0
    );
  }), [
    e,
    r,
    t,
    n
  ];
}
const [
  yc,
  kc,
  wc,
  _c
] = /* @__PURE__ */ xc();
function Nn(e, t) {
  const r = t ? e ? _c : wc : e ? kc : yc;
  return (n, o, a) => o === "__v_isReactive" ? !e : o === "__v_isReadonly" ? e : o === "__v_raw" ? n : Reflect.get(
    H(r, o) && o in n ? r : n,
    o,
    a
  );
}
const Sc = {
  get: /* @__PURE__ */ Nn(!1, !1)
}, Cc = {
  get: /* @__PURE__ */ Nn(!1, !0)
}, $c = {
  get: /* @__PURE__ */ Nn(!0, !1)
};
const La = /* @__PURE__ */ new WeakMap(), Ea = /* @__PURE__ */ new WeakMap(), Na = /* @__PURE__ */ new WeakMap(), Tc = /* @__PURE__ */ new WeakMap();
function Pc(e) {
  switch (e) {
    case "Object":
    case "Array":
      return 1;
    case "Map":
    case "Set":
    case "WeakMap":
    case "WeakSet":
      return 2;
    default:
      return 0;
  }
}
function Oc(e) {
  return e.__v_skip || !Object.isExtensible(e) ? 0 : Pc(Ql(e));
}
function Hr(e) {
  return Ct(e) ? e : Fn(
    e,
    !1,
    hc,
    Sc,
    La
  );
}
function jc(e) {
  return Fn(
    e,
    !1,
    vc,
    Cc,
    Ea
  );
}
function Rn(e) {
  return Fn(
    e,
    !0,
    mc,
    $c,
    Na
  );
}
function Fn(e, t, r, n, o) {
  if (!X(e) || e.__v_raw && !(t && e.__v_isReactive))
    return e;
  const a = o.get(e);
  if (a)
    return a;
  const s = Oc(e);
  if (s === 0)
    return e;
  const i = new Proxy(
    e,
    s === 2 ? n : r
  );
  return o.set(e, i), i;
}
function qt(e) {
  return Ct(e) ? qt(e.__v_raw) : !!(e && e.__v_isReactive);
}
function Ct(e) {
  return !!(e && e.__v_isReadonly);
}
function Nt(e) {
  return !!(e && e.__v_isShallow);
}
function Ra(e) {
  return e ? !!e.__v_raw : !1;
}
function W(e) {
  const t = e && e.__v_raw;
  return t ? W(t) : e;
}
function Ic(e) {
  return Object.isExtensible(e) && ya(e, "__v_skip", !0), e;
}
const er = (e) => X(e) ? Hr(e) : e, Vn = (e) => X(e) ? Rn(e) : e;
class Fa {
  constructor(t, r, n, o) {
    this.getter = t, this._setter = r, this.dep = void 0, this.__v_isRef = !0, this.__v_isReadonly = !1, this.effect = new An(
      () => t(this._value),
      () => $r(
        this,
        this.effect._dirtyLevel === 2 ? 2 : 3
      )
    ), this.effect.computed = this, this.effect.active = this._cacheable = !o, this.__v_isReadonly = n;
  }
  get value() {
    const t = W(this);
    return (!t._cacheable || t.effect.dirty) && ft(t._value, t._value = t.effect.run()) && $r(t, 4), Va(t), t.effect._dirtyLevel >= 2 && $r(t, 2), t._value;
  }
  set value(t) {
    this._setter(t);
  }
  // #region polyfill _dirty for backward compatibility third party code for Vue <= 3.3.x
  get _dirty() {
    return this.effect.dirty;
  }
  set _dirty(t) {
    this.effect.dirty = t;
  }
  // #endregion
}
function Ac(e, t, r = !1) {
  let n, o;
  const a = R(e);
  return a ? (n = e, o = Ie) : (n = e.get, o = e.set), new Fa(n, o, a || !o, r);
}
function Va(e) {
  var t;
  ut && _t && (e = W(e), Pa(
    _t,
    (t = e.dep) != null ? t : e.dep = ja(
      () => e.dep = void 0,
      e instanceof Fa ? e : void 0
    )
  ));
}
function $r(e, t = 4, r, n) {
  e = W(e);
  const o = e.dep;
  o && Oa(
    o,
    t
  );
}
function we(e) {
  return !!(e && e.__v_isRef === !0);
}
function lt(e) {
  return zc(e, !1);
}
function zc(e, t) {
  return we(e) ? e : new Lc(e, t);
}
class Lc {
  constructor(t, r) {
    this.__v_isShallow = r, this.dep = void 0, this.__v_isRef = !0, this._rawValue = r ? t : W(t), this._value = r ? t : er(t);
  }
  get value() {
    return Va(this), this._value;
  }
  set value(t) {
    const r = this.__v_isShallow || Nt(t) || Ct(t);
    t = r ? t : W(t), ft(t, this._rawValue) && (this._rawValue, this._rawValue = t, this._value = r ? t : er(t), $r(this, 4));
  }
}
function Tr(e) {
  return we(e) ? e.value : e;
}
const Ec = {
  get: (e, t, r) => Tr(Reflect.get(e, t, r)),
  set: (e, t, r, n) => {
    const o = e[t];
    return we(o) && !we(r) ? (o.value = r, !0) : Reflect.set(e, t, r, n);
  }
};
function Ma(e) {
  return qt(e) ? e : new Proxy(e, Ec);
}
/**
* @vue/runtime-core v3.4.37
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
function dt(e, t, r, n) {
  try {
    return n ? e(...n) : e();
  } catch (o) {
    Ur(o, t, r);
  }
}
function Me(e, t, r, n) {
  if (R(e)) {
    const o = dt(e, t, r, n);
    return o && ma(o) && o.catch((a) => {
      Ur(a, t, r);
    }), o;
  }
  if (L(e)) {
    const o = [];
    for (let a = 0; a < e.length; a++)
      o.push(Me(e[a], t, r, n));
    return o;
  }
}
function Ur(e, t, r, n = !0) {
  const o = t ? t.vnode : null;
  if (t) {
    let a = t.parent;
    const s = t.proxy, i = `https://vuejs.org/error-reference/#runtime-${r}`;
    for (; a; ) {
      const c = a.ec;
      if (c) {
        for (let u = 0; u < c.length; u++)
          if (c[u](e, s, i) === !1)
            return;
      }
      a = a.parent;
    }
    const l = t.appContext.config.errorHandler;
    if (l) {
      gt(), dt(
        l,
        null,
        10,
        [e, s, i]
      ), ht();
      return;
    }
  }
  Nc(e, r, o, n);
}
function Nc(e, t, r, n = !0) {
  console.error(e);
}
let tr = !1, bn = !1;
const ce = [];
let Ge = 0;
const Lt = [];
let ot = null, kt = 0;
const Ba = /* @__PURE__ */ Promise.resolve();
let Mn = null;
function Da(e) {
  const t = Mn || Ba;
  return e ? t.then(this ? e.bind(this) : e) : t;
}
function Rc(e) {
  let t = Ge + 1, r = ce.length;
  for (; t < r; ) {
    const n = t + r >>> 1, o = ce[n], a = rr(o);
    a < e || a === e && o.pre ? t = n + 1 : r = n;
  }
  return t;
}
function Bn(e) {
  (!ce.length || !ce.includes(
    e,
    tr && e.allowRecurse ? Ge + 1 : Ge
  )) && (e.id == null ? ce.push(e) : ce.splice(Rc(e.id), 0, e), Ha());
}
function Ha() {
  !tr && !bn && (bn = !0, Mn = Ba.then(Ka));
}
function Fc(e) {
  const t = ce.indexOf(e);
  t > Ge && ce.splice(t, 1);
}
function Vc(e) {
  L(e) ? Lt.push(...e) : (!ot || !ot.includes(
    e,
    e.allowRecurse ? kt + 1 : kt
  )) && Lt.push(e), Ha();
}
function yo(e, t, r = tr ? Ge + 1 : 0) {
  for (; r < ce.length; r++) {
    const n = ce[r];
    if (n && n.pre) {
      if (e && n.id !== e.uid)
        continue;
      ce.splice(r, 1), r--, n();
    }
  }
}
function Ua(e) {
  if (Lt.length) {
    const t = [...new Set(Lt)].sort(
      (r, n) => rr(r) - rr(n)
    );
    if (Lt.length = 0, ot) {
      ot.push(...t);
      return;
    }
    for (ot = t, kt = 0; kt < ot.length; kt++) {
      const r = ot[kt];
      r.active !== !1 && r();
    }
    ot = null, kt = 0;
  }
}
const rr = (e) => e.id == null ? 1 / 0 : e.id, Mc = (e, t) => {
  const r = rr(e) - rr(t);
  if (r === 0) {
    if (e.pre && !t.pre) return -1;
    if (t.pre && !e.pre) return 1;
  }
  return r;
};
function Ka(e) {
  bn = !1, tr = !0, ce.sort(Mc);
  try {
    for (Ge = 0; Ge < ce.length; Ge++) {
      const t = ce[Ge];
      t && t.active !== !1 && dt(
        t,
        t.i,
        t.i ? 15 : 14
      );
    }
  } finally {
    Ge = 0, ce.length = 0, Ua(), tr = !1, Mn = null, (ce.length || Lt.length) && Ka();
  }
}
let se = null, Wa = null;
function Ar(e) {
  const t = se;
  return se = e, Wa = e && e.type.__scopeId || null, t;
}
function Ga(e, t = se, r) {
  if (!t || e._n)
    return e;
  const n = (...o) => {
    n._d && Io(-1);
    const a = Ar(t);
    let s;
    try {
      s = e(...o);
    } finally {
      Ar(a), n._d && Io(1);
    }
    return s;
  };
  return n._n = !0, n._c = !0, n._d = !0, n;
}
function qa(e, t) {
  if (se === null)
    return e;
  const r = Yr(se), n = e.dirs || (e.dirs = []);
  for (let o = 0; o < t.length; o++) {
    let [a, s, i, l = Z] = t[o];
    a && (R(a) && (a = {
      mounted: a,
      updated: a
    }), a.deep && st(s), n.push({
      dir: a,
      instance: r,
      value: s,
      oldValue: void 0,
      arg: i,
      modifiers: l
    }));
  }
  return e;
}
function xt(e, t, r, n) {
  const o = e.dirs, a = t && t.dirs;
  for (let s = 0; s < o.length; s++) {
    const i = o[s];
    a && (i.oldValue = a[s].value);
    let l = i.dir[n];
    l && (gt(), Me(l, r, 8, [
      e.el,
      i,
      e,
      t
    ]), ht());
  }
}
function Ya(e, t) {
  e.shapeFlag & 6 && e.component ? Ya(e.component.subTree, t) : e.shapeFlag & 128 ? (e.ssContent.transition = t.clone(e.ssContent), e.ssFallback.transition = t.clone(e.ssFallback)) : e.transition = t;
}
/*! #__NO_SIDE_EFFECTS__ */
// @__NO_SIDE_EFFECTS__
function Bc(e, t) {
  return R(e) ? (
    // #8326: extend call and options.name access are considered side-effects
    // by Rollup, so we have to wrap it in a pure-annotated IIFE.
    ye({ name: e.name }, t, { setup: e })
  ) : e;
}
const Yt = (e) => !!e.type.__asyncLoader, Ja = (e) => e.type.__isKeepAlive;
function Dc(e, t) {
  Qa(e, "a", t);
}
function Hc(e, t) {
  Qa(e, "da", t);
}
function Qa(e, t, r = ie) {
  const n = e.__wdc || (e.__wdc = () => {
    let o = r;
    for (; o; ) {
      if (o.isDeactivated)
        return;
      o = o.parent;
    }
    return e();
  });
  if (Kr(t, n, r), r) {
    let o = r.parent;
    for (; o && o.parent; )
      Ja(o.parent.vnode) && Uc(n, t, r, o), o = o.parent;
  }
}
function Uc(e, t, r, n) {
  const o = Kr(
    t,
    e,
    n,
    !0
    /* prepend */
  );
  Za(() => {
    Pn(n[t], o);
  }, r);
}
function Kr(e, t, r = ie, n = !1) {
  if (r) {
    const o = r[e] || (r[e] = []), a = t.__weh || (t.__weh = (...s) => {
      gt();
      const i = pr(r), l = Me(t, r, e, s);
      return i(), ht(), l;
    });
    return n ? o.unshift(a) : o.push(a), a;
  }
}
const et = (e) => (t, r = ie) => {
  (!qr || e === "sp") && Kr(e, (...n) => t(...n), r);
}, Kc = et("bm"), Dn = et("m"), Wc = et("bu"), Gc = et("u"), qc = et("bum"), Za = et("um"), Yc = et("sp"), Jc = et(
  "rtg"
), Qc = et(
  "rtc"
);
function Zc(e, t = ie) {
  Kr("ec", e, t);
}
const Hn = "components", Xc = "directives";
function ko(e, t) {
  return Un(Hn, e, !0, t) || e;
}
const Xa = Symbol.for("v-ndc");
function eu(e) {
  return re(e) ? Un(Hn, e, !1) || e : e || Xa;
}
function tu(e) {
  return Un(Xc, e);
}
function Un(e, t, r = !0, n = !1) {
  const o = se || ie;
  if (o) {
    const a = o.type;
    if (e === Hn) {
      const i = Ku(
        a,
        !1
      );
      if (i && (i === t || i === Be(t) || i === Mr(Be(t))))
        return a;
    }
    const s = (
      // local registration
      // check instance[type] first which is resolved for options API
      wo(o[e] || a[e], t) || // global registration
      wo(o.appContext[e], t)
    );
    return !s && n ? a : s;
  }
}
function wo(e, t) {
  return e && (e[t] || e[Be(t)] || e[Mr(Be(t))]);
}
function Dt(e, t, r = {}, n, o) {
  if (se.isCE || se.parent && Yt(se.parent) && se.parent.isCE)
    return t !== "default" && (r.name = t), Ce("slot", r, n && n());
  let a = e[t];
  a && a._c && (a._d = !1), Ve();
  const s = a && es(a(r)), i = Xt(
    Fe,
    {
      key: (r.key || // slot content array of a dynamic conditional slot may have a branch
      // key attached in the `createSlots` helper, respect that
      s && s.key || `_${t}`) + // #7256 force differentiate fallback content from actual content
      (!s && n ? "_fb" : "")
    },
    s || (n ? n() : []),
    s && e._ === 1 ? 64 : -2
  );
  return i.scopeId && (i.slotScopeIds = [i.scopeId + "-s"]), a && a._c && (a._d = !0), i;
}
function es(e) {
  return e.some((t) => xs(t) ? !(t.type === pt || t.type === Fe && !es(t.children)) : !0) ? e : null;
}
const gn = (e) => e ? ws(e) ? Yr(e) : gn(e.parent) : null, Jt = (
  // Move PURE marker to new line to workaround compiler discarding it
  // due to type annotation
  /* @__PURE__ */ ye(/* @__PURE__ */ Object.create(null), {
    $: (e) => e,
    $el: (e) => e.vnode.el,
    $data: (e) => e.data,
    $props: (e) => e.props,
    $attrs: (e) => e.attrs,
    $slots: (e) => e.slots,
    $refs: (e) => e.refs,
    $parent: (e) => gn(e.parent),
    $root: (e) => gn(e.root),
    $emit: (e) => e.emit,
    $options: (e) => rs(e),
    $forceUpdate: (e) => e.f || (e.f = () => {
      e.effect.dirty = !0, Bn(e.update);
    }),
    $nextTick: (e) => e.n || (e.n = Da.bind(e.proxy)),
    $watch: (e) => Cu.bind(e)
  })
), tn = (e, t) => e !== Z && !e.__isScriptSetup && H(e, t), ru = {
  get({ _: e }, t) {
    if (t === "__v_skip")
      return !0;
    const { ctx: r, setupState: n, data: o, props: a, accessCache: s, type: i, appContext: l } = e;
    let c;
    if (t[0] !== "$") {
      const h = s[t];
      if (h !== void 0)
        switch (h) {
          case 1:
            return n[t];
          case 2:
            return o[t];
          case 4:
            return r[t];
          case 3:
            return a[t];
        }
      else {
        if (tn(n, t))
          return s[t] = 1, n[t];
        if (o !== Z && H(o, t))
          return s[t] = 2, o[t];
        if (
          // only cache other properties when instance has declared (thus stable)
          // props
          (c = e.propsOptions[0]) && H(c, t)
        )
          return s[t] = 3, a[t];
        if (r !== Z && H(r, t))
          return s[t] = 4, r[t];
        hn && (s[t] = 0);
      }
    }
    const u = Jt[t];
    let p, b;
    if (u)
      return t === "$attrs" && ke(e.attrs, "get", ""), u(e);
    if (
      // css module (injected by vue-loader)
      (p = i.__cssModules) && (p = p[t])
    )
      return p;
    if (r !== Z && H(r, t))
      return s[t] = 4, r[t];
    if (
      // global properties
      b = l.config.globalProperties, H(b, t)
    )
      return b[t];
  },
  set({ _: e }, t, r) {
    const { data: n, setupState: o, ctx: a } = e;
    return tn(o, t) ? (o[t] = r, !0) : n !== Z && H(n, t) ? (n[t] = r, !0) : H(e.props, t) || t[0] === "$" && t.slice(1) in e ? !1 : (a[t] = r, !0);
  },
  has({
    _: { data: e, setupState: t, accessCache: r, ctx: n, appContext: o, propsOptions: a }
  }, s) {
    let i;
    return !!r[s] || e !== Z && H(e, s) || tn(t, s) || (i = a[0]) && H(i, s) || H(n, s) || H(Jt, s) || H(o.config.globalProperties, s);
  },
  defineProperty(e, t, r) {
    return r.get != null ? e._.accessCache[t] = 0 : H(r, "value") && this.set(e, t, r.value, null), Reflect.defineProperty(e, t, r);
  }
};
function _o(e) {
  return L(e) ? e.reduce(
    (t, r) => (t[r] = null, t),
    {}
  ) : e;
}
let hn = !0;
function nu(e) {
  const t = rs(e), r = e.proxy, n = e.ctx;
  hn = !1, t.beforeCreate && So(t.beforeCreate, e, "bc");
  const {
    // state
    data: o,
    computed: a,
    methods: s,
    watch: i,
    provide: l,
    inject: c,
    // lifecycle
    created: u,
    beforeMount: p,
    mounted: b,
    beforeUpdate: h,
    updated: w,
    activated: C,
    deactivated: A,
    beforeDestroy: z,
    beforeUnmount: I,
    destroyed: v,
    unmounted: P,
    render: U,
    renderTracked: E,
    renderTriggered: ne,
    errorCaptured: te,
    serverPrefetch: $e,
    // public API
    expose: ue,
    inheritAttrs: be,
    // assets
    components: Te,
    directives: Pe,
    filters: Oe
  } = t;
  if (c && ou(c, n, null), s)
    for (const K in s) {
      const B = s[K];
      R(B) && (n[K] = B.bind(r));
    }
  if (o) {
    const K = o.call(r, r);
    X(K) && (e.data = Hr(K));
  }
  if (hn = !0, a)
    for (const K in a) {
      const B = a[K], ge = R(B) ? B.bind(r, r) : R(B.get) ? B.get.bind(r, r) : Ie, he = !R(B) && R(B.set) ? B.set.bind(r) : Ie, oe = Gu({
        get: ge,
        set: he
      });
      Object.defineProperty(n, K, {
        enumerable: !0,
        configurable: !0,
        get: () => oe.value,
        set: (ae) => oe.value = ae
      });
    }
  if (i)
    for (const K in i)
      ts(i[K], n, r, K);
  if (l) {
    const K = R(l) ? l.call(r) : l;
    Reflect.ownKeys(K).forEach((B) => {
      uu(B, K[B]);
    });
  }
  u && So(u, e, "c");
  function ee(K, B) {
    L(B) ? B.forEach((ge) => K(ge.bind(r))) : B && K(B.bind(r));
  }
  if (ee(Kc, p), ee(Dn, b), ee(Wc, h), ee(Gc, w), ee(Dc, C), ee(Hc, A), ee(Zc, te), ee(Qc, E), ee(Jc, ne), ee(qc, I), ee(Za, P), ee(Yc, $e), L(ue))
    if (ue.length) {
      const K = e.exposed || (e.exposed = {});
      ue.forEach((B) => {
        Object.defineProperty(K, B, {
          get: () => r[B],
          set: (ge) => r[B] = ge
        });
      });
    } else e.exposed || (e.exposed = {});
  U && e.render === Ie && (e.render = U), be != null && (e.inheritAttrs = be), Te && (e.components = Te), Pe && (e.directives = Pe);
}
function ou(e, t, r = Ie) {
  L(e) && (e = mn(e));
  for (const n in e) {
    const o = e[n];
    let a;
    X(o) ? "default" in o ? a = Qt(
      o.from || n,
      o.default,
      !0
    ) : a = Qt(o.from || n) : a = Qt(o), we(a) ? Object.defineProperty(t, n, {
      enumerable: !0,
      configurable: !0,
      get: () => a.value,
      set: (s) => a.value = s
    }) : t[n] = a;
  }
}
function So(e, t, r) {
  Me(
    L(e) ? e.map((n) => n.bind(t.proxy)) : e.bind(t.proxy),
    t,
    r
  );
}
function ts(e, t, r, n) {
  const o = n.includes(".") ? hs(r, n) : () => r[n];
  if (re(e)) {
    const a = t[e];
    R(a) && ct(o, a);
  } else if (R(e))
    ct(o, e.bind(r));
  else if (X(e))
    if (L(e))
      e.forEach((a) => ts(a, t, r, n));
    else {
      const a = R(e.handler) ? e.handler.bind(r) : t[e.handler];
      R(a) && ct(o, a, e);
    }
}
function rs(e) {
  const t = e.type, { mixins: r, extends: n } = t, {
    mixins: o,
    optionsCache: a,
    config: { optionMergeStrategies: s }
  } = e.appContext, i = a.get(t);
  let l;
  return i ? l = i : !o.length && !r && !n ? l = t : (l = {}, o.length && o.forEach(
    (c) => zr(l, c, s, !0)
  ), zr(l, t, s)), X(t) && a.set(t, l), l;
}
function zr(e, t, r, n = !1) {
  const { mixins: o, extends: a } = t;
  a && zr(e, a, r, !0), o && o.forEach(
    (s) => zr(e, s, r, !0)
  );
  for (const s in t)
    if (!(n && s === "expose")) {
      const i = au[s] || r && r[s];
      e[s] = i ? i(e[s], t[s]) : t[s];
    }
  return e;
}
const au = {
  data: Co,
  props: $o,
  emits: $o,
  // objects
  methods: Ht,
  computed: Ht,
  // lifecycle
  beforeCreate: fe,
  created: fe,
  beforeMount: fe,
  mounted: fe,
  beforeUpdate: fe,
  updated: fe,
  beforeDestroy: fe,
  beforeUnmount: fe,
  destroyed: fe,
  unmounted: fe,
  activated: fe,
  deactivated: fe,
  errorCaptured: fe,
  serverPrefetch: fe,
  // assets
  components: Ht,
  directives: Ht,
  // watch
  watch: iu,
  // provide / inject
  provide: Co,
  inject: su
};
function Co(e, t) {
  return t ? e ? function() {
    return ye(
      R(e) ? e.call(this, this) : e,
      R(t) ? t.call(this, this) : t
    );
  } : t : e;
}
function su(e, t) {
  return Ht(mn(e), mn(t));
}
function mn(e) {
  if (L(e)) {
    const t = {};
    for (let r = 0; r < e.length; r++)
      t[e[r]] = e[r];
    return t;
  }
  return e;
}
function fe(e, t) {
  return e ? [...new Set([].concat(e, t))] : t;
}
function Ht(e, t) {
  return e ? ye(/* @__PURE__ */ Object.create(null), e, t) : t;
}
function $o(e, t) {
  return e ? L(e) && L(t) ? [.../* @__PURE__ */ new Set([...e, ...t])] : ye(
    /* @__PURE__ */ Object.create(null),
    _o(e),
    _o(t ?? {})
  ) : t;
}
function iu(e, t) {
  if (!e) return t;
  if (!t) return e;
  const r = ye(/* @__PURE__ */ Object.create(null), e);
  for (const n in t)
    r[n] = fe(e[n], t[n]);
  return r;
}
function ns() {
  return {
    app: null,
    config: {
      isNativeTag: Yl,
      performance: !1,
      globalProperties: {},
      optionMergeStrategies: {},
      errorHandler: void 0,
      warnHandler: void 0,
      compilerOptions: {}
    },
    mixins: [],
    components: {},
    directives: {},
    provides: /* @__PURE__ */ Object.create(null),
    optionsCache: /* @__PURE__ */ new WeakMap(),
    propsCache: /* @__PURE__ */ new WeakMap(),
    emitsCache: /* @__PURE__ */ new WeakMap()
  };
}
let lu = 0;
function cu(e, t) {
  return function(n, o = null) {
    R(n) || (n = ye({}, n)), o != null && !X(o) && (o = null);
    const a = ns(), s = /* @__PURE__ */ new WeakSet();
    let i = !1;
    const l = a.app = {
      _uid: lu++,
      _component: n,
      _props: o,
      _container: null,
      _context: a,
      _instance: null,
      version: qu,
      get config() {
        return a.config;
      },
      set config(c) {
      },
      use(c, ...u) {
        return s.has(c) || (c && R(c.install) ? (s.add(c), c.install(l, ...u)) : R(c) && (s.add(c), c(l, ...u))), l;
      },
      mixin(c) {
        return a.mixins.includes(c) || a.mixins.push(c), l;
      },
      component(c, u) {
        return u ? (a.components[c] = u, l) : a.components[c];
      },
      directive(c, u) {
        return u ? (a.directives[c] = u, l) : a.directives[c];
      },
      mount(c, u, p) {
        if (!i) {
          const b = Ce(n, o);
          return b.appContext = a, p === !0 ? p = "svg" : p === !1 && (p = void 0), e(b, c, p), i = !0, l._container = c, c.__vue_app__ = l, Yr(b.component);
        }
      },
      unmount() {
        i && (e(null, l._container), delete l._container.__vue_app__);
      },
      provide(c, u) {
        return a.provides[c] = u, l;
      },
      runWithContext(c) {
        const u = Et;
        Et = l;
        try {
          return c();
        } finally {
          Et = u;
        }
      }
    };
    return l;
  };
}
let Et = null;
function uu(e, t) {
  if (ie) {
    let r = ie.provides;
    const n = ie.parent && ie.parent.provides;
    n === r && (r = ie.provides = Object.create(n)), r[e] = t;
  }
}
function Qt(e, t, r = !1) {
  const n = ie || se;
  if (n || Et) {
    const o = Et ? Et._context.provides : n ? n.parent == null ? n.vnode.appContext && n.vnode.appContext.provides : n.parent.provides : void 0;
    if (o && e in o)
      return o[e];
    if (arguments.length > 1)
      return r && R(t) ? t.call(n && n.proxy) : t;
  }
}
const os = {}, as = () => Object.create(os), ss = (e) => Object.getPrototypeOf(e) === os;
function du(e, t, r, n = !1) {
  const o = {}, a = as();
  e.propsDefaults = /* @__PURE__ */ Object.create(null), is(e, t, o, a);
  for (const s in e.propsOptions[0])
    s in o || (o[s] = void 0);
  r ? e.props = n ? o : jc(o) : e.type.props ? e.props = o : e.props = a, e.attrs = a;
}
function fu(e, t, r, n) {
  const {
    props: o,
    attrs: a,
    vnode: { patchFlag: s }
  } = e, i = W(o), [l] = e.propsOptions;
  let c = !1;
  if (
    // always force full diff in dev
    // - #1942 if hmr is enabled with sfc component
    // - vite#872 non-sfc component used by sfc component
    (n || s > 0) && !(s & 16)
  ) {
    if (s & 8) {
      const u = e.vnode.dynamicProps;
      for (let p = 0; p < u.length; p++) {
        let b = u[p];
        if (Wr(e.emitsOptions, b))
          continue;
        const h = t[b];
        if (l)
          if (H(a, b))
            h !== a[b] && (a[b] = h, c = !0);
          else {
            const w = Be(b);
            o[w] = vn(
              l,
              i,
              w,
              h,
              e,
              !1
            );
          }
        else
          h !== a[b] && (a[b] = h, c = !0);
      }
    }
  } else {
    is(e, t, o, a) && (c = !0);
    let u;
    for (const p in i)
      (!t || // for camelCase
      !H(t, p) && // it's possible the original props was passed in as kebab-case
      // and converted to camelCase (#955)
      ((u = $t(p)) === p || !H(t, u))) && (l ? r && // for camelCase
      (r[p] !== void 0 || // for kebab-case
      r[u] !== void 0) && (o[p] = vn(
        l,
        i,
        p,
        void 0,
        e,
        !0
      )) : delete o[p]);
    if (a !== i)
      for (const p in a)
        (!t || !H(t, p)) && (delete a[p], c = !0);
  }
  c && Xe(e.attrs, "set", "");
}
function is(e, t, r, n) {
  const [o, a] = e.propsOptions;
  let s = !1, i;
  if (t)
    for (let l in t) {
      if (Gt(l))
        continue;
      const c = t[l];
      let u;
      o && H(o, u = Be(l)) ? !a || !a.includes(u) ? r[u] = c : (i || (i = {}))[u] = c : Wr(e.emitsOptions, l) || (!(l in n) || c !== n[l]) && (n[l] = c, s = !0);
    }
  if (a) {
    const l = W(r), c = i || Z;
    for (let u = 0; u < a.length; u++) {
      const p = a[u];
      r[p] = vn(
        o,
        l,
        p,
        c[p],
        e,
        !H(c, p)
      );
    }
  }
  return s;
}
function vn(e, t, r, n, o, a) {
  const s = e[r];
  if (s != null) {
    const i = H(s, "default");
    if (i && n === void 0) {
      const l = s.default;
      if (s.type !== Function && !s.skipFactory && R(l)) {
        const { propsDefaults: c } = o;
        if (r in c)
          n = c[r];
        else {
          const u = pr(o);
          n = c[r] = l.call(
            null,
            t
          ), u();
        }
      } else
        n = l;
    }
    s[
      0
      /* shouldCast */
    ] && (a && !i ? n = !1 : s[
      1
      /* shouldCastTrue */
    ] && (n === "" || n === $t(r)) && (n = !0));
  }
  return n;
}
const pu = /* @__PURE__ */ new WeakMap();
function ls(e, t, r = !1) {
  const n = r ? pu : t.propsCache, o = n.get(e);
  if (o)
    return o;
  const a = e.props, s = {}, i = [];
  let l = !1;
  if (!R(e)) {
    const u = (p) => {
      l = !0;
      const [b, h] = ls(p, t, !0);
      ye(s, b), h && i.push(...h);
    };
    !r && t.mixins.length && t.mixins.forEach(u), e.extends && u(e.extends), e.mixins && e.mixins.forEach(u);
  }
  if (!a && !l)
    return X(e) && n.set(e, At), At;
  if (L(a))
    for (let u = 0; u < a.length; u++) {
      const p = Be(a[u]);
      To(p) && (s[p] = Z);
    }
  else if (a)
    for (const u in a) {
      const p = Be(u);
      if (To(p)) {
        const b = a[u], h = s[p] = L(b) || R(b) ? { type: b } : ye({}, b), w = h.type;
        let C = !1, A = !0;
        if (L(w))
          for (let z = 0; z < w.length; ++z) {
            const I = w[z], v = R(I) && I.name;
            if (v === "Boolean") {
              C = !0;
              break;
            } else v === "String" && (A = !1);
          }
        else
          C = R(w) && w.name === "Boolean";
        h[
          0
          /* shouldCast */
        ] = C, h[
          1
          /* shouldCastTrue */
        ] = A, (C || H(h, "default")) && i.push(p);
      }
    }
  const c = [s, i];
  return X(e) && n.set(e, c), c;
}
function To(e) {
  return e[0] !== "$" && !Gt(e);
}
const cs = (e) => e[0] === "_" || e === "$stable", Kn = (e) => L(e) ? e.map(We) : [We(e)], bu = (e, t, r) => {
  if (t._n)
    return t;
  const n = Ga((...o) => Kn(t(...o)), r);
  return n._c = !1, n;
}, us = (e, t, r) => {
  const n = e._ctx;
  for (const o in e) {
    if (cs(o)) continue;
    const a = e[o];
    if (R(a))
      t[o] = bu(o, a, n);
    else if (a != null) {
      const s = Kn(a);
      t[o] = () => s;
    }
  }
}, ds = (e, t) => {
  const r = Kn(t);
  e.slots.default = () => r;
}, fs = (e, t, r) => {
  for (const n in t)
    (r || n !== "_") && (e[n] = t[n]);
}, gu = (e, t, r) => {
  const n = e.slots = as();
  if (e.vnode.shapeFlag & 32) {
    const o = t._;
    o ? (fs(n, t, r), r && ya(n, "_", o, !0)) : us(t, n);
  } else t && ds(e, t);
}, hu = (e, t, r) => {
  const { vnode: n, slots: o } = e;
  let a = !0, s = Z;
  if (n.shapeFlag & 32) {
    const i = t._;
    i ? r && i === 1 ? a = !1 : fs(o, t, r) : (a = !t.$stable, us(t, o)), s = t;
  } else t && (ds(e, t), s = { default: 1 });
  if (a)
    for (const i in o)
      !cs(i) && s[i] == null && delete o[i];
};
function xn(e, t, r, n, o = !1) {
  if (L(e)) {
    e.forEach(
      (b, h) => xn(
        b,
        t && (L(t) ? t[h] : t),
        r,
        n,
        o
      )
    );
    return;
  }
  if (Yt(n) && !o)
    return;
  const a = n.shapeFlag & 4 ? Yr(n.component) : n.el, s = o ? null : a, { i, r: l } = e, c = t && t.r, u = i.refs === Z ? i.refs = {} : i.refs, p = i.setupState;
  if (c != null && c !== l && (re(c) ? (u[c] = null, H(p, c) && (p[c] = null)) : we(c) && (c.value = null)), R(l))
    dt(l, i, 12, [s, u]);
  else {
    const b = re(l), h = we(l);
    if (b || h) {
      const w = () => {
        if (e.f) {
          const C = b ? H(p, l) ? p[l] : u[l] : l.value;
          o ? L(C) && Pn(C, a) : L(C) ? C.includes(a) || C.push(a) : b ? (u[l] = [a], H(p, l) && (p[l] = u[l])) : (l.value = [a], e.k && (u[e.k] = l.value));
        } else b ? (u[l] = s, H(p, l) && (p[l] = s)) : h && (l.value = s, e.k && (u[e.k] = s));
      };
      s ? (w.id = -1, me(w, r)) : w();
    }
  }
}
const mu = Symbol("_vte"), vu = (e) => e.__isTeleport, me = zu;
function xu(e) {
  return yu(e);
}
function yu(e, t) {
  const r = ka();
  r.__VUE__ = !0;
  const {
    insert: n,
    remove: o,
    patchProp: a,
    createElement: s,
    createText: i,
    createComment: l,
    setText: c,
    setElementText: u,
    parentNode: p,
    nextSibling: b,
    setScopeId: h = Ie,
    insertStaticContent: w
  } = e, C = (d, f, g, y = null, m = null, k = null, $ = void 0, _ = null, S = !!f.dynamicChildren) => {
    if (d === f)
      return;
    d && !Bt(d, f) && (y = Tt(d), ae(d, m, k, !0), d = null), f.patchFlag === -2 && (S = !1, f.dynamicChildren = null);
    const { type: x, ref: T, shapeFlag: j } = f;
    switch (x) {
      case Gr:
        A(d, f, g, y);
        break;
      case pt:
        z(d, f, g, y);
        break;
      case nn:
        d == null && I(f, g, y, $);
        break;
      case Fe:
        Te(
          d,
          f,
          g,
          y,
          m,
          k,
          $,
          _,
          S
        );
        break;
      default:
        j & 1 ? U(
          d,
          f,
          g,
          y,
          m,
          k,
          $,
          _,
          S
        ) : j & 6 ? Pe(
          d,
          f,
          g,
          y,
          m,
          k,
          $,
          _,
          S
        ) : (j & 64 || j & 128) && x.process(
          d,
          f,
          g,
          y,
          m,
          k,
          $,
          _,
          S,
          vt
        );
    }
    T != null && m && xn(T, d && d.ref, k, f || d, !f);
  }, A = (d, f, g, y) => {
    if (d == null)
      n(
        f.el = i(f.children),
        g,
        y
      );
    else {
      const m = f.el = d.el;
      f.children !== d.children && c(m, f.children);
    }
  }, z = (d, f, g, y) => {
    d == null ? n(
      f.el = l(f.children || ""),
      g,
      y
    ) : f.el = d.el;
  }, I = (d, f, g, y) => {
    [d.el, d.anchor] = w(
      d.children,
      f,
      g,
      y,
      d.el,
      d.anchor
    );
  }, v = ({ el: d, anchor: f }, g, y) => {
    let m;
    for (; d && d !== f; )
      m = b(d), n(d, g, y), d = m;
    n(f, g, y);
  }, P = ({ el: d, anchor: f }) => {
    let g;
    for (; d && d !== f; )
      g = b(d), o(d), d = g;
    o(f);
  }, U = (d, f, g, y, m, k, $, _, S) => {
    f.type === "svg" ? $ = "svg" : f.type === "math" && ($ = "mathml"), d == null ? E(
      f,
      g,
      y,
      m,
      k,
      $,
      _,
      S
    ) : $e(
      d,
      f,
      m,
      k,
      $,
      _,
      S
    );
  }, E = (d, f, g, y, m, k, $, _) => {
    let S, x;
    const { props: T, shapeFlag: j, transition: O, dirs: N } = d;
    if (S = d.el = s(
      d.type,
      k,
      T && T.is,
      T
    ), j & 8 ? u(S, d.children) : j & 16 && te(
      d.children,
      S,
      null,
      y,
      m,
      rn(d, k),
      $,
      _
    ), N && xt(d, null, y, "created"), ne(S, d, d.scopeId, $, y), T) {
      for (const Y in T)
        Y !== "value" && !Gt(Y) && a(S, Y, null, T[Y], k, y);
      "value" in T && a(S, "value", null, T.value, k), (x = T.onVnodeBeforeMount) && Ue(x, y, d);
    }
    N && xt(d, null, y, "beforeMount");
    const V = ku(m, O);
    V && O.beforeEnter(S), n(S, f, g), ((x = T && T.onVnodeMounted) || V || N) && me(() => {
      x && Ue(x, y, d), V && O.enter(S), N && xt(d, null, y, "mounted");
    }, m);
  }, ne = (d, f, g, y, m) => {
    if (g && h(d, g), y)
      for (let k = 0; k < y.length; k++)
        h(d, y[k]);
    if (m) {
      let k = m.subTree;
      if (f === k) {
        const $ = m.vnode;
        ne(
          d,
          $,
          $.scopeId,
          $.slotScopeIds,
          m.parent
        );
      }
    }
  }, te = (d, f, g, y, m, k, $, _, S = 0) => {
    for (let x = S; x < d.length; x++) {
      const T = d[x] = _ ? at(d[x]) : We(d[x]);
      C(
        null,
        T,
        f,
        g,
        y,
        m,
        k,
        $,
        _
      );
    }
  }, $e = (d, f, g, y, m, k, $) => {
    const _ = f.el = d.el;
    let { patchFlag: S, dynamicChildren: x, dirs: T } = f;
    S |= d.patchFlag & 16;
    const j = d.props || Z, O = f.props || Z;
    let N;
    if (g && yt(g, !1), (N = O.onVnodeBeforeUpdate) && Ue(N, g, f, d), T && xt(f, d, g, "beforeUpdate"), g && yt(g, !0), (j.innerHTML && O.innerHTML == null || j.textContent && O.textContent == null) && u(_, ""), x ? ue(
      d.dynamicChildren,
      x,
      _,
      g,
      y,
      rn(f, m),
      k
    ) : $ || B(
      d,
      f,
      _,
      null,
      g,
      y,
      rn(f, m),
      k,
      !1
    ), S > 0) {
      if (S & 16)
        be(_, j, O, g, m);
      else if (S & 2 && j.class !== O.class && a(_, "class", null, O.class, m), S & 4 && a(_, "style", j.style, O.style, m), S & 8) {
        const V = f.dynamicProps;
        for (let Y = 0; Y < V.length; Y++) {
          const G = V[Y], de = j[G], Ae = O[G];
          (Ae !== de || G === "value") && a(_, G, de, Ae, m, g);
        }
      }
      S & 1 && d.children !== f.children && u(_, f.children);
    } else !$ && x == null && be(_, j, O, g, m);
    ((N = O.onVnodeUpdated) || T) && me(() => {
      N && Ue(N, g, f, d), T && xt(f, d, g, "updated");
    }, y);
  }, ue = (d, f, g, y, m, k, $) => {
    for (let _ = 0; _ < f.length; _++) {
      const S = d[_], x = f[_], T = (
        // oldVNode may be an errored async setup() component inside Suspense
        // which will not have a mounted element
        S.el && // - In the case of a Fragment, we need to provide the actual parent
        // of the Fragment itself so it can move its children.
        (S.type === Fe || // - In the case of different nodes, there is going to be a replacement
        // which also requires the correct parent container
        !Bt(S, x) || // - In the case of a component, it could contain anything.
        S.shapeFlag & 70) ? p(S.el) : (
          // In other cases, the parent container is not actually used so we
          // just pass the block element here to avoid a DOM parentNode call.
          g
        )
      );
      C(
        S,
        x,
        T,
        null,
        y,
        m,
        k,
        $,
        !0
      );
    }
  }, be = (d, f, g, y, m) => {
    if (f !== g) {
      if (f !== Z)
        for (const k in f)
          !Gt(k) && !(k in g) && a(
            d,
            k,
            f[k],
            null,
            m,
            y
          );
      for (const k in g) {
        if (Gt(k)) continue;
        const $ = g[k], _ = f[k];
        $ !== _ && k !== "value" && a(d, k, _, $, m, y);
      }
      "value" in g && a(d, "value", f.value, g.value, m);
    }
  }, Te = (d, f, g, y, m, k, $, _, S) => {
    const x = f.el = d ? d.el : i(""), T = f.anchor = d ? d.anchor : i("");
    let { patchFlag: j, dynamicChildren: O, slotScopeIds: N } = f;
    N && (_ = _ ? _.concat(N) : N), d == null ? (n(x, g, y), n(T, g, y), te(
      // #10007
      // such fragment like `<></>` will be compiled into
      // a fragment which doesn't have a children.
      // In this case fallback to an empty array
      f.children || [],
      g,
      T,
      m,
      k,
      $,
      _,
      S
    )) : j > 0 && j & 64 && O && // #2715 the previous fragment could've been a BAILed one as a result
    // of renderSlot() with no valid children
    d.dynamicChildren ? (ue(
      d.dynamicChildren,
      O,
      g,
      m,
      k,
      $,
      _
    ), // #2080 if the stable fragment has a key, it's a <template v-for> that may
    //  get moved around. Make sure all root level vnodes inherit el.
    // #2134 or if it's a component root, it may also get moved around
    // as the component is being moved.
    (f.key != null || m && f === m.subTree) && ps(
      d,
      f,
      !0
      /* shallow */
    )) : B(
      d,
      f,
      g,
      T,
      m,
      k,
      $,
      _,
      S
    );
  }, Pe = (d, f, g, y, m, k, $, _, S) => {
    f.slotScopeIds = _, d == null ? f.shapeFlag & 512 ? m.ctx.activate(
      f,
      g,
      y,
      $,
      S
    ) : Oe(
      f,
      g,
      y,
      m,
      k,
      $,
      S
    ) : De(d, f, S);
  }, Oe = (d, f, g, y, m, k, $) => {
    const _ = d.component = Vu(
      d,
      y,
      m
    );
    if (Ja(d) && (_.ctx.renderer = vt), Bu(_, !1, $), _.asyncDep) {
      if (m && m.registerDep(_, ee, $), !d.el) {
        const S = _.subTree = Ce(pt);
        z(null, S, f, g);
      }
    } else
      ee(
        _,
        d,
        f,
        g,
        m,
        k,
        $
      );
  }, De = (d, f, g) => {
    const y = f.component = d.component;
    if (ju(d, f, g))
      if (y.asyncDep && !y.asyncResolved) {
        K(y, f, g);
        return;
      } else
        y.next = f, Fc(y.update), y.effect.dirty = !0, y.update();
    else
      f.el = d.el, y.vnode = f;
  }, ee = (d, f, g, y, m, k, $) => {
    const _ = () => {
      if (d.isMounted) {
        let { next: T, bu: j, u: O, parent: N, vnode: V } = d;
        {
          const Pt = bs(d);
          if (Pt) {
            T && (T.el = V.el, K(d, T, $)), Pt.asyncDep.then(() => {
              d.isUnmounted || _();
            });
            return;
          }
        }
        let Y = T, G;
        yt(d, !1), T ? (T.el = V.el, K(d, T, $)) : T = V, j && Cr(j), (G = T.props && T.props.onVnodeBeforeUpdate) && Ue(G, N, T, V), yt(d, !0);
        const de = Oo(d), Ae = d.subTree;
        d.subTree = de, C(
          Ae,
          de,
          // parent may have changed if it's in a teleport
          p(Ae.el),
          // anchor may have changed if it's in a fragment
          Tt(Ae),
          d,
          m,
          k
        ), T.el = de.el, Y === null && Iu(d, de.el), O && me(O, m), (G = T.props && T.props.onVnodeUpdated) && me(
          () => Ue(G, N, T, V),
          m
        );
      } else {
        let T;
        const { el: j, props: O } = f, { bm: N, m: V, parent: Y } = d, G = Yt(f);
        yt(d, !1), N && Cr(N), !G && (T = O && O.onVnodeBeforeMount) && Ue(T, Y, f), yt(d, !0);
        {
          const de = d.subTree = Oo(d);
          C(
            null,
            de,
            g,
            y,
            d,
            m,
            k
          ), f.el = de.el;
        }
        if (V && me(V, m), !G && (T = O && O.onVnodeMounted)) {
          const de = f;
          me(
            () => Ue(T, Y, de),
            m
          );
        }
        (f.shapeFlag & 256 || Y && Yt(Y.vnode) && Y.vnode.shapeFlag & 256) && d.a && me(d.a, m), d.isMounted = !0, f = g = y = null;
      }
    }, S = d.effect = new An(
      _,
      Ie,
      () => Bn(x),
      d.scope
      // track it in component's effect scope
    ), x = d.update = () => {
      S.dirty && S.run();
    };
    x.i = d, x.id = d.uid, yt(d, !0), x();
  }, K = (d, f, g) => {
    f.component = d;
    const y = d.vnode.props;
    d.vnode = f, d.next = null, fu(d, f.props, y, g), hu(d, f.children, g), gt(), yo(d), ht();
  }, B = (d, f, g, y, m, k, $, _, S = !1) => {
    const x = d && d.children, T = d ? d.shapeFlag : 0, j = f.children, { patchFlag: O, shapeFlag: N } = f;
    if (O > 0) {
      if (O & 128) {
        he(
          x,
          j,
          g,
          y,
          m,
          k,
          $,
          _,
          S
        );
        return;
      } else if (O & 256) {
        ge(
          x,
          j,
          g,
          y,
          m,
          k,
          $,
          _,
          S
        );
        return;
      }
    }
    N & 8 ? (T & 16 && rt(x, m, k), j !== x && u(g, j)) : T & 16 ? N & 16 ? he(
      x,
      j,
      g,
      y,
      m,
      k,
      $,
      _,
      S
    ) : rt(x, m, k, !0) : (T & 8 && u(g, ""), N & 16 && te(
      j,
      g,
      y,
      m,
      k,
      $,
      _,
      S
    ));
  }, ge = (d, f, g, y, m, k, $, _, S) => {
    d = d || At, f = f || At;
    const x = d.length, T = f.length, j = Math.min(x, T);
    let O;
    for (O = 0; O < j; O++) {
      const N = f[O] = S ? at(f[O]) : We(f[O]);
      C(
        d[O],
        N,
        g,
        null,
        m,
        k,
        $,
        _,
        S
      );
    }
    x > T ? rt(
      d,
      m,
      k,
      !0,
      !1,
      j
    ) : te(
      f,
      g,
      y,
      m,
      k,
      $,
      _,
      S,
      j
    );
  }, he = (d, f, g, y, m, k, $, _, S) => {
    let x = 0;
    const T = f.length;
    let j = d.length - 1, O = T - 1;
    for (; x <= j && x <= O; ) {
      const N = d[x], V = f[x] = S ? at(f[x]) : We(f[x]);
      if (Bt(N, V))
        C(
          N,
          V,
          g,
          null,
          m,
          k,
          $,
          _,
          S
        );
      else
        break;
      x++;
    }
    for (; x <= j && x <= O; ) {
      const N = d[j], V = f[O] = S ? at(f[O]) : We(f[O]);
      if (Bt(N, V))
        C(
          N,
          V,
          g,
          null,
          m,
          k,
          $,
          _,
          S
        );
      else
        break;
      j--, O--;
    }
    if (x > j) {
      if (x <= O) {
        const N = O + 1, V = N < T ? f[N].el : y;
        for (; x <= O; )
          C(
            null,
            f[x] = S ? at(f[x]) : We(f[x]),
            g,
            V,
            m,
            k,
            $,
            _,
            S
          ), x++;
      }
    } else if (x > O)
      for (; x <= j; )
        ae(d[x], m, k, !0), x++;
    else {
      const N = x, V = x, Y = /* @__PURE__ */ new Map();
      for (x = V; x <= O; x++) {
        const _e = f[x] = S ? at(f[x]) : We(f[x]);
        _e.key != null && Y.set(_e.key, x);
      }
      let G, de = 0;
      const Ae = O - V + 1;
      let Pt = !1, qn = 0;
      const Mt = new Array(Ae);
      for (x = 0; x < Ae; x++) Mt[x] = 0;
      for (x = N; x <= j; x++) {
        const _e = d[x];
        if (de >= Ae) {
          ae(_e, m, k, !0);
          continue;
        }
        let He;
        if (_e.key != null)
          He = Y.get(_e.key);
        else
          for (G = V; G <= O; G++)
            if (Mt[G - V] === 0 && Bt(_e, f[G])) {
              He = G;
              break;
            }
        He === void 0 ? ae(_e, m, k, !0) : (Mt[He - V] = x + 1, He >= qn ? qn = He : Pt = !0, C(
          _e,
          f[He],
          g,
          null,
          m,
          k,
          $,
          _,
          S
        ), de++);
      }
      const Yn = Pt ? wu(Mt) : At;
      for (G = Yn.length - 1, x = Ae - 1; x >= 0; x--) {
        const _e = V + x, He = f[_e], Jn = _e + 1 < T ? f[_e + 1].el : y;
        Mt[x] === 0 ? C(
          null,
          He,
          g,
          Jn,
          m,
          k,
          $,
          _,
          S
        ) : Pt && (G < 0 || x !== Yn[G] ? oe(He, g, Jn, 2) : G--);
      }
    }
  }, oe = (d, f, g, y, m = null) => {
    const { el: k, type: $, transition: _, children: S, shapeFlag: x } = d;
    if (x & 6) {
      oe(d.component.subTree, f, g, y);
      return;
    }
    if (x & 128) {
      d.suspense.move(f, g, y);
      return;
    }
    if (x & 64) {
      $.move(d, f, g, vt);
      return;
    }
    if ($ === Fe) {
      n(k, f, g);
      for (let j = 0; j < S.length; j++)
        oe(S[j], f, g, y);
      n(d.anchor, f, g);
      return;
    }
    if ($ === nn) {
      v(d, f, g);
      return;
    }
    if (y !== 2 && x & 1 && _)
      if (y === 0)
        _.beforeEnter(k), n(k, f, g), me(() => _.enter(k), m);
      else {
        const { leave: j, delayLeave: O, afterLeave: N } = _, V = () => n(k, f, g), Y = () => {
          j(k, () => {
            V(), N && N();
          });
        };
        O ? O(k, V, Y) : Y();
      }
    else
      n(k, f, g);
  }, ae = (d, f, g, y = !1, m = !1) => {
    const {
      type: k,
      props: $,
      ref: _,
      children: S,
      dynamicChildren: x,
      shapeFlag: T,
      patchFlag: j,
      dirs: O,
      cacheIndex: N
    } = d;
    if (j === -2 && (m = !1), _ != null && xn(_, null, g, d, !0), N != null && (f.renderCache[N] = void 0), T & 256) {
      f.ctx.deactivate(d);
      return;
    }
    const V = T & 1 && O, Y = !Yt(d);
    let G;
    if (Y && (G = $ && $.onVnodeBeforeUnmount) && Ue(G, f, d), T & 6)
      br(d.component, g, y);
    else {
      if (T & 128) {
        d.suspense.unmount(g, y);
        return;
      }
      V && xt(d, null, f, "beforeUnmount"), T & 64 ? d.type.remove(
        d,
        f,
        g,
        vt,
        y
      ) : x && // #5154
      // when v-once is used inside a block, setBlockTracking(-1) marks the
      // parent block with hasOnce: true
      // so that it doesn't take the fast path during unmount - otherwise
      // components nested in v-once are never unmounted.
      !x.hasOnce && // #1153: fast path should not be taken for non-stable (v-for) fragments
      (k !== Fe || j > 0 && j & 64) ? rt(
        x,
        f,
        g,
        !1,
        !0
      ) : (k === Fe && j & 384 || !m && T & 16) && rt(S, f, g), y && mt(d);
    }
    (Y && (G = $ && $.onVnodeUnmounted) || V) && me(() => {
      G && Ue(G, f, d), V && xt(d, null, f, "unmounted");
    }, g);
  }, mt = (d) => {
    const { type: f, el: g, anchor: y, transition: m } = d;
    if (f === Fe) {
      tt(g, y);
      return;
    }
    if (f === nn) {
      P(d);
      return;
    }
    const k = () => {
      o(g), m && !m.persisted && m.afterLeave && m.afterLeave();
    };
    if (d.shapeFlag & 1 && m && !m.persisted) {
      const { leave: $, delayLeave: _ } = m, S = () => $(g, k);
      _ ? _(d.el, k, S) : S();
    } else
      k();
  }, tt = (d, f) => {
    let g;
    for (; d !== f; )
      g = b(d), o(d), d = g;
    o(f);
  }, br = (d, f, g) => {
    const { bum: y, scope: m, update: k, subTree: $, um: _, m: S, a: x } = d;
    Po(S), Po(x), y && Cr(y), m.stop(), k && (k.active = !1, ae($, d, f, g)), _ && me(_, f), me(() => {
      d.isUnmounted = !0;
    }, f), f && f.pendingBranch && !f.isUnmounted && d.asyncDep && !d.asyncResolved && d.suspenseId === f.pendingId && (f.deps--, f.deps === 0 && f.resolve());
  }, rt = (d, f, g, y = !1, m = !1, k = 0) => {
    for (let $ = k; $ < d.length; $++)
      ae(d[$], f, g, y, m);
  }, Tt = (d) => {
    if (d.shapeFlag & 6)
      return Tt(d.component.subTree);
    if (d.shapeFlag & 128)
      return d.suspense.next();
    const f = b(d.anchor || d.el), g = f && f[mu];
    return g ? b(g) : f;
  };
  let Vt = !1;
  const gr = (d, f, g) => {
    d == null ? f._vnode && ae(f._vnode, null, null, !0) : C(
      f._vnode || null,
      d,
      f,
      null,
      null,
      null,
      g
    ), f._vnode = d, Vt || (Vt = !0, yo(), Ua(), Vt = !1);
  }, vt = {
    p: C,
    um: ae,
    m: oe,
    r: mt,
    mt: Oe,
    mc: te,
    pc: B,
    pbc: ue,
    n: Tt,
    o: e
  };
  return {
    render: gr,
    hydrate: void 0,
    createApp: cu(gr)
  };
}
function rn({ type: e, props: t }, r) {
  return r === "svg" && e === "foreignObject" || r === "mathml" && e === "annotation-xml" && t && t.encoding && t.encoding.includes("html") ? void 0 : r;
}
function yt({ effect: e, update: t }, r) {
  e.allowRecurse = t.allowRecurse = r;
}
function ku(e, t) {
  return (!e || e && !e.pendingBranch) && t && !t.persisted;
}
function ps(e, t, r = !1) {
  const n = e.children, o = t.children;
  if (L(n) && L(o))
    for (let a = 0; a < n.length; a++) {
      const s = n[a];
      let i = o[a];
      i.shapeFlag & 1 && !i.dynamicChildren && ((i.patchFlag <= 0 || i.patchFlag === 32) && (i = o[a] = at(o[a]), i.el = s.el), !r && i.patchFlag !== -2 && ps(s, i)), i.type === Gr && (i.el = s.el);
    }
}
function wu(e) {
  const t = e.slice(), r = [0];
  let n, o, a, s, i;
  const l = e.length;
  for (n = 0; n < l; n++) {
    const c = e[n];
    if (c !== 0) {
      if (o = r[r.length - 1], e[o] < c) {
        t[n] = o, r.push(n);
        continue;
      }
      for (a = 0, s = r.length - 1; a < s; )
        i = a + s >> 1, e[r[i]] < c ? a = i + 1 : s = i;
      c < e[r[a]] && (a > 0 && (t[n] = r[a - 1]), r[a] = n);
    }
  }
  for (a = r.length, s = r[a - 1]; a-- > 0; )
    r[a] = s, s = t[s];
  return r;
}
function bs(e) {
  const t = e.subTree.component;
  if (t)
    return t.asyncDep && !t.asyncResolved ? t : bs(t);
}
function Po(e) {
  if (e)
    for (let t = 0; t < e.length; t++) e[t].active = !1;
}
const _u = Symbol.for("v-scx"), Su = () => Qt(_u), wr = {};
function ct(e, t, r) {
  return gs(e, t, r);
}
function gs(e, t, {
  immediate: r,
  deep: n,
  flush: o,
  once: a,
  onTrack: s,
  onTrigger: i
} = Z) {
  if (t && a) {
    const E = t;
    t = (...ne) => {
      E(...ne), U();
    };
  }
  const l = ie, c = (E) => n === !0 ? E : (
    // for deep: false, only traverse root-level properties
    st(E, n === !1 ? 1 : void 0)
  );
  let u, p = !1, b = !1;
  if (we(e) ? (u = () => e.value, p = Nt(e)) : qt(e) ? (u = () => c(e), p = !0) : L(e) ? (b = !0, p = e.some((E) => qt(E) || Nt(E)), u = () => e.map((E) => {
    if (we(E))
      return E.value;
    if (qt(E))
      return c(E);
    if (R(E))
      return dt(E, l, 2);
  })) : R(e) ? t ? u = () => dt(e, l, 2) : u = () => (h && h(), Me(
    e,
    l,
    3,
    [w]
  )) : u = Ie, t && n) {
    const E = u;
    u = () => st(E());
  }
  let h, w = (E) => {
    h = v.onStop = () => {
      dt(E, l, 4), h = v.onStop = void 0;
    };
  }, C;
  if (qr)
    if (w = Ie, t ? r && Me(t, l, 3, [
      u(),
      b ? [] : void 0,
      w
    ]) : u(), o === "sync") {
      const E = Su();
      C = E.__watcherHandles || (E.__watcherHandles = []);
    } else
      return Ie;
  let A = b ? new Array(e.length).fill(wr) : wr;
  const z = () => {
    if (!(!v.active || !v.dirty))
      if (t) {
        const E = v.run();
        (n || p || (b ? E.some((ne, te) => ft(ne, A[te])) : ft(E, A))) && (h && h(), Me(t, l, 3, [
          E,
          // pass undefined as the old value when it's changed for the first time
          A === wr ? void 0 : b && A[0] === wr ? [] : A,
          w
        ]), A = E);
      } else
        v.run();
  };
  z.allowRecurse = !!t;
  let I;
  o === "sync" ? I = z : o === "post" ? I = () => me(z, l && l.suspense) : (z.pre = !0, l && (z.id = l.uid), I = () => Bn(z));
  const v = new An(u, Ie, I), P = uc(), U = () => {
    v.stop(), P && Pn(P.effects, v);
  };
  return t ? r ? z() : A = v.run() : o === "post" ? me(
    v.run.bind(v),
    l && l.suspense
  ) : v.run(), C && C.push(U), U;
}
function Cu(e, t, r) {
  const n = this.proxy, o = re(e) ? e.includes(".") ? hs(n, e) : () => n[e] : e.bind(n, n);
  let a;
  R(t) ? a = t : (a = t.handler, r = t);
  const s = pr(this), i = gs(o, a.bind(n), r);
  return s(), i;
}
function hs(e, t) {
  const r = t.split(".");
  return () => {
    let n = e;
    for (let o = 0; o < r.length && n; o++)
      n = n[r[o]];
    return n;
  };
}
function st(e, t = 1 / 0, r) {
  if (t <= 0 || !X(e) || e.__v_skip || (r = r || /* @__PURE__ */ new Set(), r.has(e)))
    return e;
  if (r.add(e), t--, we(e))
    st(e.value, t, r);
  else if (L(e))
    for (let n = 0; n < e.length; n++)
      st(e[n], t, r);
  else if (Fr(e) || zt(e))
    e.forEach((n) => {
      st(n, t, r);
    });
  else if (xa(e)) {
    for (const n in e)
      st(e[n], t, r);
    for (const n of Object.getOwnPropertySymbols(e))
      Object.prototype.propertyIsEnumerable.call(e, n) && st(e[n], t, r);
  }
  return e;
}
const $u = (e, t) => t === "modelValue" || t === "model-value" ? e.modelModifiers : e[`${t}Modifiers`] || e[`${Be(t)}Modifiers`] || e[`${$t(t)}Modifiers`];
function Tu(e, t, ...r) {
  if (e.isUnmounted) return;
  const n = e.vnode.props || Z;
  let o = r;
  const a = t.startsWith("update:"), s = a && $u(n, t.slice(7));
  s && (s.trim && (o = r.map((u) => re(u) ? u.trim() : u)), s.number && (o = r.map(ec)));
  let i, l = n[i = Xr(t)] || // also try camelCase event handler (#2249)
  n[i = Xr(Be(t))];
  !l && a && (l = n[i = Xr($t(t))]), l && Me(
    l,
    e,
    6,
    o
  );
  const c = n[i + "Once"];
  if (c) {
    if (!e.emitted)
      e.emitted = {};
    else if (e.emitted[i])
      return;
    e.emitted[i] = !0, Me(
      c,
      e,
      6,
      o
    );
  }
}
function ms(e, t, r = !1) {
  const n = t.emitsCache, o = n.get(e);
  if (o !== void 0)
    return o;
  const a = e.emits;
  let s = {}, i = !1;
  if (!R(e)) {
    const l = (c) => {
      const u = ms(c, t, !0);
      u && (i = !0, ye(s, u));
    };
    !r && t.mixins.length && t.mixins.forEach(l), e.extends && l(e.extends), e.mixins && e.mixins.forEach(l);
  }
  return !a && !i ? (X(e) && n.set(e, null), null) : (L(a) ? a.forEach((l) => s[l] = null) : ye(s, a), X(e) && n.set(e, s), s);
}
function Wr(e, t) {
  return !e || !Rr(t) ? !1 : (t = t.slice(2).replace(/Once$/, ""), H(e, t[0].toLowerCase() + t.slice(1)) || H(e, $t(t)) || H(e, t));
}
function Oo(e) {
  const {
    type: t,
    vnode: r,
    proxy: n,
    withProxy: o,
    propsOptions: [a],
    slots: s,
    attrs: i,
    emit: l,
    render: c,
    renderCache: u,
    props: p,
    data: b,
    setupState: h,
    ctx: w,
    inheritAttrs: C
  } = e, A = Ar(e);
  let z, I;
  try {
    if (r.shapeFlag & 4) {
      const P = o || n, U = P;
      z = We(
        c.call(
          U,
          P,
          u,
          p,
          h,
          b,
          w
        )
      ), I = i;
    } else {
      const P = t;
      z = We(
        P.length > 1 ? P(
          p,
          { attrs: i, slots: s, emit: l }
        ) : P(
          p,
          null
        )
      ), I = t.props ? i : Pu(i);
    }
  } catch (P) {
    Zt.length = 0, Ur(P, e, 1), z = Ce(pt);
  }
  let v = z;
  if (I && C !== !1) {
    const P = Object.keys(I), { shapeFlag: U } = v;
    P.length && U & 7 && (a && P.some(Tn) && (I = Ou(
      I,
      a
    )), v = Ft(v, I, !1, !0));
  }
  return r.dirs && (v = Ft(v, null, !1, !0), v.dirs = v.dirs ? v.dirs.concat(r.dirs) : r.dirs), r.transition && (v.transition = r.transition), z = v, Ar(A), z;
}
const Pu = (e) => {
  let t;
  for (const r in e)
    (r === "class" || r === "style" || Rr(r)) && ((t || (t = {}))[r] = e[r]);
  return t;
}, Ou = (e, t) => {
  const r = {};
  for (const n in e)
    (!Tn(n) || !(n.slice(9) in t)) && (r[n] = e[n]);
  return r;
};
function ju(e, t, r) {
  const { props: n, children: o, component: a } = e, { props: s, children: i, patchFlag: l } = t, c = a.emitsOptions;
  if (t.dirs || t.transition)
    return !0;
  if (r && l >= 0) {
    if (l & 1024)
      return !0;
    if (l & 16)
      return n ? jo(n, s, c) : !!s;
    if (l & 8) {
      const u = t.dynamicProps;
      for (let p = 0; p < u.length; p++) {
        const b = u[p];
        if (s[b] !== n[b] && !Wr(c, b))
          return !0;
      }
    }
  } else
    return (o || i) && (!i || !i.$stable) ? !0 : n === s ? !1 : n ? s ? jo(n, s, c) : !0 : !!s;
  return !1;
}
function jo(e, t, r) {
  const n = Object.keys(t);
  if (n.length !== Object.keys(e).length)
    return !0;
  for (let o = 0; o < n.length; o++) {
    const a = n[o];
    if (t[a] !== e[a] && !Wr(r, a))
      return !0;
  }
  return !1;
}
function Iu({ vnode: e, parent: t }, r) {
  for (; t; ) {
    const n = t.subTree;
    if (n.suspense && n.suspense.activeBranch === e && (n.el = e.el), n === e)
      (e = t.vnode).el = r, t = t.parent;
    else
      break;
  }
}
const Au = (e) => e.__isSuspense;
function zu(e, t) {
  t && t.pendingBranch ? L(e) ? t.effects.push(...e) : t.effects.push(e) : Vc(e);
}
const Fe = Symbol.for("v-fgt"), Gr = Symbol.for("v-txt"), pt = Symbol.for("v-cmt"), nn = Symbol.for("v-stc"), Zt = [];
let Se = null;
function Ve(e = !1) {
  Zt.push(Se = e ? null : []);
}
function Lu() {
  Zt.pop(), Se = Zt[Zt.length - 1] || null;
}
let nr = 1;
function Io(e) {
  nr += e, e < 0 && Se && (Se.hasOnce = !0);
}
function vs(e) {
  return e.dynamicChildren = nr > 0 ? Se || At : null, Lu(), nr > 0 && Se && Se.push(e), e;
}
function Rt(e, t, r, n, o, a) {
  return vs(
    pe(
      e,
      t,
      r,
      n,
      o,
      a,
      !0
    )
  );
}
function Xt(e, t, r, n, o) {
  return vs(
    Ce(
      e,
      t,
      r,
      n,
      o,
      !0
    )
  );
}
function xs(e) {
  return e ? e.__v_isVNode === !0 : !1;
}
function Bt(e, t) {
  return e.type === t.type && e.key === t.key;
}
const ys = ({ key: e }) => e ?? null, Pr = ({
  ref: e,
  ref_key: t,
  ref_for: r
}) => (typeof e == "number" && (e = "" + e), e != null ? re(e) || we(e) || R(e) ? { i: se, r: e, k: t, f: !!r } : e : null);
function pe(e, t = null, r = null, n = 0, o = null, a = e === Fe ? 0 : 1, s = !1, i = !1) {
  const l = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e,
    props: t,
    key: t && ys(t),
    ref: t && Pr(t),
    scopeId: Wa,
    slotScopeIds: null,
    children: r,
    component: null,
    suspense: null,
    ssContent: null,
    ssFallback: null,
    dirs: null,
    transition: null,
    el: null,
    anchor: null,
    target: null,
    targetStart: null,
    targetAnchor: null,
    staticCount: 0,
    shapeFlag: a,
    patchFlag: n,
    dynamicProps: o,
    dynamicChildren: null,
    appContext: null,
    ctx: se
  };
  return i ? (Wn(l, r), a & 128 && e.normalize(l)) : r && (l.shapeFlag |= re(r) ? 8 : 16), nr > 0 && // avoid a block node from tracking itself
  !s && // has current parent block
  Se && // presence of a patch flag indicates this node needs patching on updates.
  // component nodes also should always be patched, because even if the
  // component doesn't need to update, it needs to persist the instance on to
  // the next vnode so that it can be properly unmounted later.
  (l.patchFlag > 0 || a & 6) && // the EVENTS flag is only for hydration and if it is the only flag, the
  // vnode should not be considered dynamic due to handler caching.
  l.patchFlag !== 32 && Se.push(l), l;
}
const Ce = Eu;
function Eu(e, t = null, r = null, n = 0, o = null, a = !1) {
  if ((!e || e === Xa) && (e = pt), xs(e)) {
    const i = Ft(
      e,
      t,
      !0
      /* mergeRef: true */
    );
    return r && Wn(i, r), nr > 0 && !a && Se && (i.shapeFlag & 6 ? Se[Se.indexOf(e)] = i : Se.push(i)), i.patchFlag = -2, i;
  }
  if (Wu(e) && (e = e.__vccOpts), t) {
    t = Nu(t);
    let { class: i, style: l } = t;
    i && !re(i) && (t.class = wt(i)), X(l) && (Ra(l) && !L(l) && (l = ye({}, l)), t.style = jn(l));
  }
  const s = re(e) ? 1 : Au(e) ? 128 : vu(e) ? 64 : X(e) ? 4 : R(e) ? 2 : 0;
  return pe(
    e,
    t,
    r,
    n,
    o,
    s,
    a,
    !0
  );
}
function Nu(e) {
  return e ? Ra(e) || ss(e) ? ye({}, e) : e : null;
}
function Ft(e, t, r = !1, n = !1) {
  const { props: o, ref: a, patchFlag: s, children: i, transition: l } = e, c = t ? ve(o || {}, t) : o, u = {
    __v_isVNode: !0,
    __v_skip: !0,
    type: e.type,
    props: c,
    key: c && ys(c),
    ref: t && t.ref ? (
      // #2078 in the case of <component :is="vnode" ref="extra"/>
      // if the vnode itself already has a ref, cloneVNode will need to merge
      // the refs so the single vnode can be set on multiple refs
      r && a ? L(a) ? a.concat(Pr(t)) : [a, Pr(t)] : Pr(t)
    ) : a,
    scopeId: e.scopeId,
    slotScopeIds: e.slotScopeIds,
    children: i,
    target: e.target,
    targetStart: e.targetStart,
    targetAnchor: e.targetAnchor,
    staticCount: e.staticCount,
    shapeFlag: e.shapeFlag,
    // if the vnode is cloned with extra props, we can no longer assume its
    // existing patch flag to be reliable and need to add the FULL_PROPS flag.
    // note: preserve flag for fragments since they use the flag for children
    // fast paths only.
    patchFlag: t && e.type !== Fe ? s === -1 ? 16 : s | 16 : s,
    dynamicProps: e.dynamicProps,
    dynamicChildren: e.dynamicChildren,
    appContext: e.appContext,
    dirs: e.dirs,
    transition: l,
    // These should technically only be non-null on mounted VNodes. However,
    // they *should* be copied for kept-alive vnodes. So we just always copy
    // them since them being non-null during a mount doesn't affect the logic as
    // they will simply be overwritten.
    component: e.component,
    suspense: e.suspense,
    ssContent: e.ssContent && Ft(e.ssContent),
    ssFallback: e.ssFallback && Ft(e.ssFallback),
    el: e.el,
    anchor: e.anchor,
    ctx: e.ctx,
    ce: e.ce
  };
  return l && n && Ya(
    u,
    l.clone(u)
  ), u;
}
function ks(e = " ", t = 0) {
  return Ce(Gr, null, e, t);
}
function Ao(e = "", t = !1) {
  return t ? (Ve(), Xt(pt, null, e)) : Ce(pt, null, e);
}
function We(e) {
  return e == null || typeof e == "boolean" ? Ce(pt) : L(e) ? Ce(
    Fe,
    null,
    // #3666, avoid reference pollution when reusing vnode
    e.slice()
  ) : typeof e == "object" ? at(e) : Ce(Gr, null, String(e));
}
function at(e) {
  return e.el === null && e.patchFlag !== -1 || e.memo ? e : Ft(e);
}
function Wn(e, t) {
  let r = 0;
  const { shapeFlag: n } = e;
  if (t == null)
    t = null;
  else if (L(t))
    r = 16;
  else if (typeof t == "object")
    if (n & 65) {
      const o = t.default;
      o && (o._c && (o._d = !1), Wn(e, o()), o._c && (o._d = !0));
      return;
    } else {
      r = 32;
      const o = t._;
      !o && !ss(t) ? t._ctx = se : o === 3 && se && (se.slots._ === 1 ? t._ = 1 : (t._ = 2, e.patchFlag |= 1024));
    }
  else R(t) ? (t = { default: t, _ctx: se }, r = 32) : (t = String(t), n & 64 ? (r = 16, t = [ks(t)]) : r = 8);
  e.children = t, e.shapeFlag |= r;
}
function ve(...e) {
  const t = {};
  for (let r = 0; r < e.length; r++) {
    const n = e[r];
    for (const o in n)
      if (o === "class")
        t.class !== n.class && (t.class = wt([t.class, n.class]));
      else if (o === "style")
        t.style = jn([t.style, n.style]);
      else if (Rr(o)) {
        const a = t[o], s = n[o];
        s && a !== s && !(L(a) && a.includes(s)) && (t[o] = a ? [].concat(a, s) : s);
      } else o !== "" && (t[o] = n[o]);
  }
  return t;
}
function Ue(e, t, r, n = null) {
  Me(e, t, 7, [
    r,
    n
  ]);
}
const Ru = ns();
let Fu = 0;
function Vu(e, t, r) {
  const n = e.type, o = (t ? t.appContext : e.appContext) || Ru, a = {
    uid: Fu++,
    vnode: e,
    type: n,
    parent: t,
    appContext: o,
    root: null,
    // to be immediately set
    next: null,
    subTree: null,
    // will be set synchronously right after creation
    effect: null,
    update: null,
    // will be set synchronously right after creation
    scope: new lc(
      !0
      /* detached */
    ),
    render: null,
    proxy: null,
    exposed: null,
    exposeProxy: null,
    withProxy: null,
    provides: t ? t.provides : Object.create(o.provides),
    accessCache: null,
    renderCache: [],
    // local resolved assets
    components: null,
    directives: null,
    // resolved props and emits options
    propsOptions: ls(n, o),
    emitsOptions: ms(n, o),
    // emit
    emit: null,
    // to be set immediately
    emitted: null,
    // props default value
    propsDefaults: Z,
    // inheritAttrs
    inheritAttrs: n.inheritAttrs,
    // state
    ctx: Z,
    data: Z,
    props: Z,
    attrs: Z,
    slots: Z,
    refs: Z,
    setupState: Z,
    setupContext: null,
    // suspense related
    suspense: r,
    suspenseId: r ? r.pendingId : 0,
    asyncDep: null,
    asyncResolved: !1,
    // lifecycle hooks
    // not using enums here because it results in computed properties
    isMounted: !1,
    isUnmounted: !1,
    isDeactivated: !1,
    bc: null,
    c: null,
    bm: null,
    m: null,
    bu: null,
    u: null,
    um: null,
    bum: null,
    da: null,
    a: null,
    rtg: null,
    rtc: null,
    ec: null,
    sp: null
  };
  return a.ctx = { _: a }, a.root = t ? t.root : a, a.emit = Tu.bind(null, a), e.ce && e.ce(a), a;
}
let ie = null;
const Mu = () => ie || se;
let Lr, yn;
{
  const e = ka(), t = (r, n) => {
    let o;
    return (o = e[r]) || (o = e[r] = []), o.push(n), (a) => {
      o.length > 1 ? o.forEach((s) => s(a)) : o[0](a);
    };
  };
  Lr = t(
    "__VUE_INSTANCE_SETTERS__",
    (r) => ie = r
  ), yn = t(
    "__VUE_SSR_SETTERS__",
    (r) => qr = r
  );
}
const pr = (e) => {
  const t = ie;
  return Lr(e), e.scope.on(), () => {
    e.scope.off(), Lr(t);
  };
}, zo = () => {
  ie && ie.scope.off(), Lr(null);
};
function ws(e) {
  return e.vnode.shapeFlag & 4;
}
let qr = !1;
function Bu(e, t = !1, r = !1) {
  t && yn(t);
  const { props: n, children: o } = e.vnode, a = ws(e);
  du(e, n, a, t), gu(e, o, r);
  const s = a ? Du(e, t) : void 0;
  return t && yn(!1), s;
}
function Du(e, t) {
  const r = e.type;
  e.accessCache = /* @__PURE__ */ Object.create(null), e.proxy = new Proxy(e.ctx, ru);
  const { setup: n } = r;
  if (n) {
    const o = e.setupContext = n.length > 1 ? Uu(e) : null, a = pr(e);
    gt();
    const s = dt(
      n,
      e,
      0,
      [
        e.props,
        o
      ]
    );
    if (ht(), a(), ma(s)) {
      if (s.then(zo, zo), t)
        return s.then((i) => {
          Lo(e, i);
        }).catch((i) => {
          Ur(i, e, 0);
        });
      e.asyncDep = s;
    } else
      Lo(e, s);
  } else
    _s(e);
}
function Lo(e, t, r) {
  R(t) ? e.type.__ssrInlineRender ? e.ssrRender = t : e.render = t : X(t) && (e.setupState = Ma(t)), _s(e);
}
function _s(e, t, r) {
  const n = e.type;
  e.render || (e.render = n.render || Ie);
  {
    const o = pr(e);
    gt();
    try {
      nu(e);
    } finally {
      ht(), o();
    }
  }
}
const Hu = {
  get(e, t) {
    return ke(e, "get", ""), e[t];
  }
};
function Uu(e) {
  const t = (r) => {
    e.exposed = r || {};
  };
  return {
    attrs: new Proxy(e.attrs, Hu),
    slots: e.slots,
    emit: e.emit,
    expose: t
  };
}
function Yr(e) {
  return e.exposed ? e.exposeProxy || (e.exposeProxy = new Proxy(Ma(Ic(e.exposed)), {
    get(t, r) {
      if (r in t)
        return t[r];
      if (r in Jt)
        return Jt[r](e);
    },
    has(t, r) {
      return r in t || r in Jt;
    }
  })) : e.proxy;
}
function Ku(e, t = !0) {
  return R(e) ? e.displayName || e.name : e.name || t && e.__name;
}
function Wu(e) {
  return R(e) && "__vccOpts" in e;
}
const Gu = (e, t) => Ac(e, t, qr), qu = "3.4.37";
/**
* @vue/runtime-dom v3.4.37
* (c) 2018-present Yuxi (Evan) You and Vue contributors
* @license MIT
**/
const Yu = "http://www.w3.org/2000/svg", Ju = "http://www.w3.org/1998/Math/MathML", Qe = typeof document < "u" ? document : null, Eo = Qe && /* @__PURE__ */ Qe.createElement("template"), Qu = {
  insert: (e, t, r) => {
    t.insertBefore(e, r || null);
  },
  remove: (e) => {
    const t = e.parentNode;
    t && t.removeChild(e);
  },
  createElement: (e, t, r, n) => {
    const o = t === "svg" ? Qe.createElementNS(Yu, e) : t === "mathml" ? Qe.createElementNS(Ju, e) : r ? Qe.createElement(e, { is: r }) : Qe.createElement(e);
    return e === "select" && n && n.multiple != null && o.setAttribute("multiple", n.multiple), o;
  },
  createText: (e) => Qe.createTextNode(e),
  createComment: (e) => Qe.createComment(e),
  setText: (e, t) => {
    e.nodeValue = t;
  },
  setElementText: (e, t) => {
    e.textContent = t;
  },
  parentNode: (e) => e.parentNode,
  nextSibling: (e) => e.nextSibling,
  querySelector: (e) => Qe.querySelector(e),
  setScopeId(e, t) {
    e.setAttribute(t, "");
  },
  // __UNSAFE__
  // Reason: innerHTML.
  // Static content here can only come from compiled templates.
  // As long as the user only uses trusted templates, this is safe.
  insertStaticContent(e, t, r, n, o, a) {
    const s = r ? r.previousSibling : t.lastChild;
    if (o && (o === a || o.nextSibling))
      for (; t.insertBefore(o.cloneNode(!0), r), !(o === a || !(o = o.nextSibling)); )
        ;
    else {
      Eo.innerHTML = n === "svg" ? `<svg>${e}</svg>` : n === "mathml" ? `<math>${e}</math>` : e;
      const i = Eo.content;
      if (n === "svg" || n === "mathml") {
        const l = i.firstChild;
        for (; l.firstChild; )
          i.appendChild(l.firstChild);
        i.removeChild(l);
      }
      t.insertBefore(i, r);
    }
    return [
      // first
      s ? s.nextSibling : t.firstChild,
      // last
      r ? r.previousSibling : t.lastChild
    ];
  }
}, Zu = Symbol("_vtc");
function Xu(e, t, r) {
  const n = e[Zu];
  n && (t = (t ? [t, ...n] : [...n]).join(" ")), t == null ? e.removeAttribute("class") : r ? e.setAttribute("class", t) : e.className = t;
}
const No = Symbol("_vod"), ed = Symbol("_vsh"), td = Symbol(""), rd = /(^|;)\s*display\s*:/;
function nd(e, t, r) {
  const n = e.style, o = re(r);
  let a = !1;
  if (r && !o) {
    if (t)
      if (re(t))
        for (const s of t.split(";")) {
          const i = s.slice(0, s.indexOf(":")).trim();
          r[i] == null && Or(n, i, "");
        }
      else
        for (const s in t)
          r[s] == null && Or(n, s, "");
    for (const s in r)
      s === "display" && (a = !0), Or(n, s, r[s]);
  } else if (o) {
    if (t !== r) {
      const s = n[td];
      s && (r += ";" + s), n.cssText = r, a = rd.test(r);
    }
  } else t && e.removeAttribute("style");
  No in e && (e[No] = a ? n.display : "", e[ed] && (n.display = "none"));
}
const Ro = /\s*!important$/;
function Or(e, t, r) {
  if (L(r))
    r.forEach((n) => Or(e, t, n));
  else if (r == null && (r = ""), t.startsWith("--"))
    e.setProperty(t, r);
  else {
    const n = od(e, t);
    Ro.test(r) ? e.setProperty(
      $t(n),
      r.replace(Ro, ""),
      "important"
    ) : e[n] = r;
  }
}
const Fo = ["Webkit", "Moz", "ms"], on = {};
function od(e, t) {
  const r = on[t];
  if (r)
    return r;
  let n = Be(t);
  if (n !== "filter" && n in e)
    return on[t] = n;
  n = Mr(n);
  for (let o = 0; o < Fo.length; o++) {
    const a = Fo[o] + n;
    if (a in e)
      return on[t] = a;
  }
  return t;
}
const Vo = "http://www.w3.org/1999/xlink";
function Mo(e, t, r, n, o, a = sc(t)) {
  n && t.startsWith("xlink:") ? r == null ? e.removeAttributeNS(Vo, t.slice(6, t.length)) : e.setAttributeNS(Vo, t, r) : r == null || a && !wa(r) ? e.removeAttribute(t) : e.setAttribute(
    t,
    a ? "" : Ye(r) ? String(r) : r
  );
}
function ad(e, t, r, n) {
  if (t === "innerHTML" || t === "textContent") {
    if (r == null) return;
    e[t] = r;
    return;
  }
  const o = e.tagName;
  if (t === "value" && o !== "PROGRESS" && // custom elements may use _value internally
  !o.includes("-")) {
    const s = o === "OPTION" ? e.getAttribute("value") || "" : e.value, i = r == null ? "" : String(r);
    (s !== i || !("_value" in e)) && (e.value = i), r == null && e.removeAttribute(t), e._value = r;
    return;
  }
  let a = !1;
  if (r === "" || r == null) {
    const s = typeof e[t];
    s === "boolean" ? r = wa(r) : r == null && s === "string" ? (r = "", a = !0) : s === "number" && (r = 0, a = !0);
  }
  try {
    e[t] = r;
  } catch {
  }
  a && e.removeAttribute(t);
}
function Ss(e, t, r, n) {
  e.addEventListener(t, r, n);
}
function sd(e, t, r, n) {
  e.removeEventListener(t, r, n);
}
const Bo = Symbol("_vei");
function id(e, t, r, n, o = null) {
  const a = e[Bo] || (e[Bo] = {}), s = a[t];
  if (n && s)
    s.value = n;
  else {
    const [i, l] = ld(t);
    if (n) {
      const c = a[t] = dd(
        n,
        o
      );
      Ss(e, i, c, l);
    } else s && (sd(e, i, s, l), a[t] = void 0);
  }
}
const Do = /(?:Once|Passive|Capture)$/;
function ld(e) {
  let t;
  if (Do.test(e)) {
    t = {};
    let n;
    for (; n = e.match(Do); )
      e = e.slice(0, e.length - n[0].length), t[n[0].toLowerCase()] = !0;
  }
  return [e[2] === ":" ? e.slice(3) : $t(e.slice(2)), t];
}
let an = 0;
const cd = /* @__PURE__ */ Promise.resolve(), ud = () => an || (cd.then(() => an = 0), an = Date.now());
function dd(e, t) {
  const r = (n) => {
    if (!n._vts)
      n._vts = Date.now();
    else if (n._vts <= r.attached)
      return;
    Me(
      fd(n, r.value),
      t,
      5,
      [n]
    );
  };
  return r.value = e, r.attached = ud(), r;
}
function fd(e, t) {
  if (L(t)) {
    const r = e.stopImmediatePropagation;
    return e.stopImmediatePropagation = () => {
      r.call(e), e._stopped = !0;
    }, t.map(
      (n) => (o) => !o._stopped && n && n(o)
    );
  } else
    return t;
}
const Ho = (e) => e.charCodeAt(0) === 111 && e.charCodeAt(1) === 110 && // lowercase letter
e.charCodeAt(2) > 96 && e.charCodeAt(2) < 123, pd = (e, t, r, n, o, a) => {
  const s = o === "svg";
  t === "class" ? Xu(e, n, s) : t === "style" ? nd(e, r, n) : Rr(t) ? Tn(t) || id(e, t, r, n, a) : (t[0] === "." ? (t = t.slice(1), !0) : t[0] === "^" ? (t = t.slice(1), !1) : bd(e, t, n, s)) ? (ad(e, t, n), !e.tagName.includes("-") && (t === "value" || t === "checked" || t === "selected") && Mo(e, t, n, s, a, t !== "value")) : (t === "true-value" ? e._trueValue = n : t === "false-value" && (e._falseValue = n), Mo(e, t, n, s));
};
function bd(e, t, r, n) {
  if (n)
    return !!(t === "innerHTML" || t === "textContent" || t in e && Ho(t) && R(r));
  if (t === "spellcheck" || t === "draggable" || t === "translate" || t === "form" || t === "list" && e.tagName === "INPUT" || t === "type" && e.tagName === "TEXTAREA")
    return !1;
  if (t === "width" || t === "height") {
    const o = e.tagName;
    if (o === "IMG" || o === "VIDEO" || o === "CANVAS" || o === "SOURCE")
      return !1;
  }
  return Ho(t) && re(r) ? !1 : t in e;
}
const Uo = (e) => {
  const t = e.props["onUpdate:modelValue"] || !1;
  return L(t) ? (r) => Cr(t, r) : t;
}, sn = Symbol("_assign"), gd = {
  // #4096 array checkboxes need to be deep traversed
  deep: !0,
  created(e, t, r) {
    e[sn] = Uo(r), Ss(e, "change", () => {
      const n = e._modelValue, o = hd(e), a = e.checked, s = e[sn];
      if (L(n)) {
        const i = _a(n, o), l = i !== -1;
        if (a && !l)
          s(n.concat(o));
        else if (!a && l) {
          const c = [...n];
          c.splice(i, 1), s(c);
        }
      } else if (Fr(n)) {
        const i = new Set(n);
        a ? i.add(o) : i.delete(o), s(i);
      } else
        s(Cs(e, a));
    });
  },
  // set initial checked on mount to wait for true-value/false-value
  mounted: Ko,
  beforeUpdate(e, t, r) {
    e[sn] = Uo(r), Ko(e, t, r);
  }
};
function Ko(e, { value: t, oldValue: r }, n) {
  e._modelValue = t, L(t) ? e.checked = _a(t, n.props.value) > -1 : Fr(t) ? e.checked = t.has(n.props.value) : t !== r && (e.checked = Br(t, Cs(e, !0)));
}
function hd(e) {
  return "_value" in e ? e._value : e.value;
}
function Cs(e, t) {
  const r = t ? "_trueValue" : "_falseValue";
  return r in e ? e[r] : t;
}
const md = /* @__PURE__ */ ye({ patchProp: pd }, Qu);
let Wo;
function vd() {
  return Wo || (Wo = xu(md));
}
const xd = (...e) => {
  const t = vd().createApp(...e), { mount: r } = t;
  return t.mount = (n) => {
    const o = kd(n);
    if (!o) return;
    const a = t._component;
    !R(a) && !a.render && !a.template && (a.template = o.innerHTML), o.innerHTML = "";
    const s = r(o, !1, yd(o));
    return o instanceof Element && (o.removeAttribute("v-cloak"), o.setAttribute("data-v-app", "")), s;
  }, t;
};
function yd(e) {
  if (e instanceof SVGElement)
    return "svg";
  if (typeof MathMLElement == "function" && e instanceof MathMLElement)
    return "mathml";
}
function kd(e) {
  return re(e) ? document.querySelector(e) : e;
}
function or(e) {
  "@babel/helpers - typeof";
  return or = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, or(e);
}
function Go(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(o) {
      return Object.getOwnPropertyDescriptor(e, o).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function qo(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Go(Object(r), !0).forEach(function(n) {
      wd(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Go(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function wd(e, t, r) {
  return (t = _d(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function _d(e) {
  var t = Sd(e, "string");
  return or(t) == "symbol" ? t : t + "";
}
function Sd(e, t) {
  if (or(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (or(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
function Cd(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
  Mu() ? Dn(e) : t ? e() : Da(e);
}
var $d = 0;
function Td(e) {
  var t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, r = lt(!1), n = lt(e), o = lt(null), a = ga() ? window.document : void 0, s = t.document, i = s === void 0 ? a : s, l = t.immediate, c = l === void 0 ? !0 : l, u = t.manual, p = u === void 0 ? !1 : u, b = t.name, h = b === void 0 ? "style_".concat(++$d) : b, w = t.id, C = w === void 0 ? void 0 : w, A = t.media, z = A === void 0 ? void 0 : A, I = t.nonce, v = I === void 0 ? void 0 : I, P = t.first, U = P === void 0 ? !1 : P, E = t.onMounted, ne = E === void 0 ? void 0 : E, te = t.onUpdated, $e = te === void 0 ? void 0 : te, ue = t.onLoad, be = ue === void 0 ? void 0 : ue, Te = t.props, Pe = Te === void 0 ? {} : Te, Oe = function() {
  }, De = function(B) {
    var ge = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if (i) {
      var he = qo(qo({}, Pe), ge), oe = he.name || h, ae = he.id || C, mt = he.nonce || v;
      o.value = i.querySelector('style[data-primevue-style-id="'.concat(oe, '"]')) || i.getElementById(ae) || i.createElement("style"), o.value.isConnected || (n.value = B || e, Ir(o.value, {
        type: "text/css",
        id: ae,
        media: z,
        nonce: mt
      }), U ? i.head.prepend(o.value) : i.head.appendChild(o.value), ql(o.value, "data-primevue-style-id", oe), Ir(o.value, he), o.value.onload = function(tt) {
        return be == null ? void 0 : be(tt, {
          name: oe
        });
      }, ne == null || ne(oe)), !r.value && (Oe = ct(n, function(tt) {
        o.value.textContent = tt, $e == null || $e(oe);
      }, {
        immediate: !0
      }), r.value = !0);
    }
  }, ee = function() {
    !i || !r.value || (Oe(), Gl(o.value) && i.head.removeChild(o.value), r.value = !1);
  };
  return c && !p && Cd(De), {
    id: C,
    name: h,
    el: o,
    css: n,
    unload: ee,
    load: De,
    isLoaded: Rn(r)
  };
}
function ar(e) {
  "@babel/helpers - typeof";
  return ar = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, ar(e);
}
function Yo(e, t) {
  return Id(e) || jd(e, t) || Od(e, t) || Pd();
}
function Pd() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Od(e, t) {
  if (e) {
    if (typeof e == "string") return Jo(e, t);
    var r = {}.toString.call(e).slice(8, -1);
    return r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set" ? Array.from(e) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? Jo(e, t) : void 0;
  }
}
function Jo(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function jd(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, o, a, s, i = [], l = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(l = (n = a.call(r)).done) && (i.push(n.value), i.length !== t); l = !0) ;
    } catch (u) {
      c = !0, o = u;
    } finally {
      try {
        if (!l && r.return != null && (s = r.return(), Object(s) !== s)) return;
      } finally {
        if (c) throw o;
      }
    }
    return i;
  }
}
function Id(e) {
  if (Array.isArray(e)) return e;
}
function Qo(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(o) {
      return Object.getOwnPropertyDescriptor(e, o).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function ln(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Qo(Object(r), !0).forEach(function(n) {
      Ad(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Qo(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Ad(e, t, r) {
  return (t = zd(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function zd(e) {
  var t = Ld(e, "string");
  return ar(t) == "symbol" ? t : t + "";
}
function Ld(e, t) {
  if (ar(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (ar(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Ed = function(t) {
  var r = t.dt;
  return `
* {
    box-sizing: border-box;
}

/* Non vue overlay animations */
.p-connected-overlay {
    opacity: 0;
    transform: scaleY(0.8);
    transition: transform 0.12s cubic-bezier(0, 0, 0.2, 1),
        opacity 0.12s cubic-bezier(0, 0, 0.2, 1);
}

.p-connected-overlay-visible {
    opacity: 1;
    transform: scaleY(1);
}

.p-connected-overlay-hidden {
    opacity: 0;
    transform: scaleY(1);
    transition: opacity 0.1s linear;
}

/* Vue based overlay animations */
.p-connected-overlay-enter-from {
    opacity: 0;
    transform: scaleY(0.8);
}

.p-connected-overlay-leave-to {
    opacity: 0;
}

.p-connected-overlay-enter-active {
    transition: transform 0.12s cubic-bezier(0, 0, 0.2, 1),
        opacity 0.12s cubic-bezier(0, 0, 0.2, 1);
}

.p-connected-overlay-leave-active {
    transition: opacity 0.1s linear;
}

/* Toggleable Content */
.p-toggleable-content-enter-from,
.p-toggleable-content-leave-to {
    max-height: 0;
}

.p-toggleable-content-enter-to,
.p-toggleable-content-leave-from {
    max-height: 1000px;
}

.p-toggleable-content-leave-active {
    overflow: hidden;
    transition: max-height 0.45s cubic-bezier(0, 1, 0, 1);
}

.p-toggleable-content-enter-active {
    overflow: hidden;
    transition: max-height 1s ease-in-out;
}

.p-disabled,
.p-disabled * {
    cursor: default;
    pointer-events: none;
    user-select: none;
}

.p-disabled,
.p-component:disabled {
    opacity: `.concat(r("disabled.opacity"), `;
}

.pi {
    font-size: `).concat(r("icon.size"), `;
}

.p-icon {
    width: `).concat(r("icon.size"), `;
    height: `).concat(r("icon.size"), `;
}

.p-overlay-mask {
    background: `).concat(r("mask.background"), `;
    color: `).concat(r("mask.color"), `;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
}

.p-overlay-mask-enter {
    animation: p-overlay-mask-enter-animation `).concat(r("mask.transition.duration"), ` forwards;
}

.p-overlay-mask-leave {
    animation: p-overlay-mask-leave-animation `).concat(r("mask.transition.duration"), ` forwards;
}

@keyframes p-overlay-mask-enter-animation {
    from {
        background: transparent;
    }
    to {
        background: `).concat(r("mask.background"), `;
    }
}
@keyframes p-overlay-mask-leave-animation {
    from {
        background: `).concat(r("mask.background"), `;
    }
    to {
        background: transparent;
    }
}
`);
}, Nd = function(t) {
  var r = t.dt;
  return `
.p-hidden-accessible {
    border: 0;
    clip: rect(0 0 0 0);
    height: 1px;
    margin: -1px;
    overflow: hidden;
    padding: 0;
    position: absolute;
    width: 1px;
}

.p-hidden-accessible input,
.p-hidden-accessible select {
    transform: scale(0);
}

.p-overflow-hidden {
    overflow: hidden;
    padding-right: `.concat(r("scrollbar.width"), `;
}
`);
}, Rd = {}, Fd = {}, Q = {
  name: "base",
  css: Nd,
  theme: Ed,
  classes: Rd,
  inlineStyles: Fd,
  load: function(t) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : function(a) {
      return a;
    }, o = n(je(t, {
      dt: Wt
    }));
    return J(o) ? Td(Kt(o), ln({
      name: this.name
    }, r)) : {};
  },
  loadCSS: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {};
    return this.load(this.css, t);
  },
  loadTheme: function() {
    var t = this, r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
    return this.load(this.theme, r, function() {
      var o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "";
      return q.transformCSS(r.name || t.name, "".concat(o).concat(n));
    });
  },
  getCommonTheme: function(t) {
    return q.getCommon(this.name, t);
  },
  getComponentTheme: function(t) {
    return q.getComponent(this.name, t);
  },
  getDirectiveTheme: function(t) {
    return q.getDirective(this.name, t);
  },
  getPresetTheme: function(t, r, n) {
    return q.getCustomPreset(this.name, t, r, n);
  },
  getLayerOrderThemeCSS: function() {
    return q.getLayerOrderCSS(this.name);
  },
  getStyleSheet: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    if (this.css) {
      var n = je(this.css, {
        dt: Wt
      }) || "", o = Kt("".concat(n).concat(t)), a = Object.entries(r).reduce(function(s, i) {
        var l = Yo(i, 2), c = l[0], u = l[1];
        return s.push("".concat(c, '="').concat(u, '"')) && s;
      }, []).join(" ");
      return J(o) ? '<style type="text/css" data-primevue-style-id="'.concat(this.name, '" ').concat(a, ">").concat(o, "</style>") : "";
    }
    return "";
  },
  getCommonThemeStyleSheet: function(t) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
    return q.getCommonStyleSheet(this.name, t, r);
  },
  getThemeStyleSheet: function(t) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, n = [q.getStyleSheet(this.name, t, r)];
    if (this.theme) {
      var o = this.name === "base" ? "global-style" : "".concat(this.name, "-style"), a = je(this.theme, {
        dt: Wt
      }), s = Kt(q.transformCSS(o, a)), i = Object.entries(r).reduce(function(l, c) {
        var u = Yo(c, 2), p = u[0], b = u[1];
        return l.push("".concat(p, '="').concat(b, '"')) && l;
      }, []).join(" ");
      J(s) && n.push('<style type="text/css" data-primevue-style-id="'.concat(o, '" ').concat(i, ">").concat(s, "</style>"));
    }
    return n.join("");
  },
  extend: function(t) {
    return ln(ln({}, this), {}, {
      css: void 0,
      theme: void 0
    }, t);
  }
}, jt = ua();
function sr(e) {
  "@babel/helpers - typeof";
  return sr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, sr(e);
}
function Zo(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(o) {
      return Object.getOwnPropertyDescriptor(e, o).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function _r(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? Zo(Object(r), !0).forEach(function(n) {
      Vd(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : Zo(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Vd(e, t, r) {
  return (t = Md(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Md(e) {
  var t = Bd(e, "string");
  return sr(t) == "symbol" ? t : t + "";
}
function Bd(e, t) {
  if (sr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (sr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Dd = {
  ripple: !1,
  inputStyle: null,
  inputVariant: null,
  locale: {
    startsWith: "Starts with",
    contains: "Contains",
    notContains: "Not contains",
    endsWith: "Ends with",
    equals: "Equals",
    notEquals: "Not equals",
    noFilter: "No Filter",
    lt: "Less than",
    lte: "Less than or equal to",
    gt: "Greater than",
    gte: "Greater than or equal to",
    dateIs: "Date is",
    dateIsNot: "Date is not",
    dateBefore: "Date is before",
    dateAfter: "Date is after",
    clear: "Clear",
    apply: "Apply",
    matchAll: "Match All",
    matchAny: "Match Any",
    addRule: "Add Rule",
    removeRule: "Remove Rule",
    accept: "Yes",
    reject: "No",
    choose: "Choose",
    upload: "Upload",
    cancel: "Cancel",
    completed: "Completed",
    pending: "Pending",
    fileSizeTypes: ["B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"],
    dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
    monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
    monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    chooseYear: "Choose Year",
    chooseMonth: "Choose Month",
    chooseDate: "Choose Date",
    prevDecade: "Previous Decade",
    nextDecade: "Next Decade",
    prevYear: "Previous Year",
    nextYear: "Next Year",
    prevMonth: "Previous Month",
    nextMonth: "Next Month",
    prevHour: "Previous Hour",
    nextHour: "Next Hour",
    prevMinute: "Previous Minute",
    nextMinute: "Next Minute",
    prevSecond: "Previous Second",
    nextSecond: "Next Second",
    am: "am",
    pm: "pm",
    today: "Today",
    weekHeader: "Wk",
    firstDayOfWeek: 0,
    showMonthAfterYear: !1,
    dateFormat: "mm/dd/yy",
    weak: "Weak",
    medium: "Medium",
    strong: "Strong",
    passwordPrompt: "Enter a password",
    emptyFilterMessage: "No results found",
    searchMessage: "{0} results are available",
    selectionMessage: "{0} items selected",
    emptySelectionMessage: "No selected item",
    emptySearchMessage: "No results found",
    fileChosenMessage: "{0} files",
    noFileChosenMessage: "No file chosen",
    emptyMessage: "No available options",
    aria: {
      trueLabel: "True",
      falseLabel: "False",
      nullLabel: "Not Selected",
      star: "1 star",
      stars: "{star} stars",
      selectAll: "All items selected",
      unselectAll: "All items unselected",
      close: "Close",
      previous: "Previous",
      next: "Next",
      navigation: "Navigation",
      scrollTop: "Scroll Top",
      moveTop: "Move Top",
      moveUp: "Move Up",
      moveDown: "Move Down",
      moveBottom: "Move Bottom",
      moveToTarget: "Move to Target",
      moveToSource: "Move to Source",
      moveAllToTarget: "Move All to Target",
      moveAllToSource: "Move All to Source",
      pageLabel: "Page {page}",
      firstPageLabel: "First Page",
      lastPageLabel: "Last Page",
      nextPageLabel: "Next Page",
      prevPageLabel: "Previous Page",
      rowsPerPageLabel: "Rows per page",
      jumpToPageDropdownLabel: "Jump to Page Dropdown",
      jumpToPageInputLabel: "Jump to Page Input",
      selectRow: "Row Selected",
      unselectRow: "Row Unselected",
      expandRow: "Row Expanded",
      collapseRow: "Row Collapsed",
      showFilterMenu: "Show Filter Menu",
      hideFilterMenu: "Hide Filter Menu",
      filterOperator: "Filter Operator",
      filterConstraint: "Filter Constraint",
      editRow: "Row Edit",
      saveEdit: "Save Edit",
      cancelEdit: "Cancel Edit",
      listView: "List View",
      gridView: "Grid View",
      slide: "Slide",
      slideNumber: "{slideNumber}",
      zoomImage: "Zoom Image",
      zoomIn: "Zoom In",
      zoomOut: "Zoom Out",
      rotateRight: "Rotate Right",
      rotateLeft: "Rotate Left",
      listLabel: "Option List"
    }
  },
  filterMatchModeOptions: {
    text: [le.STARTS_WITH, le.CONTAINS, le.NOT_CONTAINS, le.ENDS_WITH, le.EQUALS, le.NOT_EQUALS],
    numeric: [le.EQUALS, le.NOT_EQUALS, le.LESS_THAN, le.LESS_THAN_OR_EQUAL_TO, le.GREATER_THAN, le.GREATER_THAN_OR_EQUAL_TO],
    date: [le.DATE_IS, le.DATE_IS_NOT, le.DATE_BEFORE, le.DATE_AFTER]
  },
  zIndex: {
    modal: 1100,
    overlay: 1e3,
    menu: 1e3,
    tooltip: 1100
  },
  theme: void 0,
  unstyled: !1,
  pt: void 0,
  ptOptions: {
    mergeSections: !0,
    mergeProps: !1
  },
  csp: {
    nonce: void 0
  }
}, Hd = Symbol();
function Ud(e, t) {
  var r = {
    config: Hr(t)
  };
  return e.config.globalProperties.$primevue = r, e.provide(Hd, r), Kd(), Wd(e, r), r;
}
var It = [];
function Kd() {
  Ee.clear(), It.forEach(function(e) {
    return e == null ? void 0 : e();
  }), It = [];
}
function Wd(e, t) {
  var r = lt(!1), n = function() {
    var c;
    if (((c = t.config) === null || c === void 0 ? void 0 : c.theme) !== "none" && !q.isStyleNameLoaded("common")) {
      var u, p, b = ((u = Q.getCommonTheme) === null || u === void 0 ? void 0 : u.call(Q)) || {}, h = b.primitive, w = b.semantic, C = b.global, A = b.style, z = {
        nonce: (p = t.config) === null || p === void 0 || (p = p.csp) === null || p === void 0 ? void 0 : p.nonce
      };
      Q.load(h == null ? void 0 : h.css, _r({
        name: "primitive-variables"
      }, z)), Q.load(w == null ? void 0 : w.css, _r({
        name: "semantic-variables"
      }, z)), Q.load(C == null ? void 0 : C.css, _r({
        name: "global-variables"
      }, z)), Q.loadTheme(_r({
        name: "global-style"
      }, z), A), q.setLoadedStyleName("common");
    }
  };
  Ee.on("theme:change", function(l) {
    r.value || (e.config.globalProperties.$primevue.config.theme = l, r.value = !0);
  });
  var o = ct(t.config, function(l, c) {
    jt.emit("config:change", {
      newValue: l,
      oldValue: c
    });
  }, {
    immediate: !0,
    deep: !0
  }), a = ct(function() {
    return t.config.ripple;
  }, function(l, c) {
    jt.emit("config:ripple:change", {
      newValue: l,
      oldValue: c
    });
  }, {
    immediate: !0,
    deep: !0
  }), s = ct(function() {
    return t.config.theme;
  }, function(l, c) {
    r.value || q.setTheme(l), t.config.unstyled || n(), r.value = !1, jt.emit("config:theme:change", {
      newValue: l,
      oldValue: c
    });
  }, {
    immediate: !0,
    deep: !0
  }), i = ct(function() {
    return t.config.unstyled;
  }, function(l, c) {
    !l && t.config.theme && n(), jt.emit("config:unstyled:change", {
      newValue: l,
      oldValue: c
    });
  }, {
    immediate: !0,
    deep: !0
  });
  It.push(o), It.push(a), It.push(s), It.push(i);
}
var Gd = {
  install: function(t, r) {
    var n = Tl(Dd, r);
    Ud(t, n);
  }
}, it = {
  _loadedStyleNames: /* @__PURE__ */ new Set(),
  getLoadedStyleNames: function() {
    return this._loadedStyleNames;
  },
  isStyleNameLoaded: function(t) {
    return this._loadedStyleNames.has(t);
  },
  setLoadedStyleName: function(t) {
    this._loadedStyleNames.add(t);
  },
  deleteLoadedStyleName: function(t) {
    this._loadedStyleNames.delete(t);
  },
  clearLoadedStyleNames: function() {
    this._loadedStyleNames.clear();
  }
}, Xo = Q.extend({
  name: "common"
});
function ir(e) {
  "@babel/helpers - typeof";
  return ir = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, ir(e);
}
function qd(e) {
  return Ps(e) || Yd(e) || Ts(e) || $s();
}
function Yd(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function Sr(e, t) {
  return Ps(e) || Jd(e, t) || Ts(e, t) || $s();
}
function $s() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Ts(e, t) {
  if (e) {
    if (typeof e == "string") return ea(e, t);
    var r = {}.toString.call(e).slice(8, -1);
    return r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set" ? Array.from(e) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? ea(e, t) : void 0;
  }
}
function ea(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function Jd(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, o, a, s, i = [], l = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t === 0) {
        if (Object(r) !== r) return;
        l = !1;
      } else for (; !(l = (n = a.call(r)).done) && (i.push(n.value), i.length !== t); l = !0) ;
    } catch (u) {
      c = !0, o = u;
    } finally {
      try {
        if (!l && r.return != null && (s = r.return(), Object(s) !== s)) return;
      } finally {
        if (c) throw o;
      }
    }
    return i;
  }
}
function Ps(e) {
  if (Array.isArray(e)) return e;
}
function ta(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(o) {
      return Object.getOwnPropertyDescriptor(e, o).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function M(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? ta(Object(r), !0).forEach(function(n) {
      Ut(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ta(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function Ut(e, t, r) {
  return (t = Qd(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Qd(e) {
  var t = Zd(e, "string");
  return ir(t) == "symbol" ? t : t + "";
}
function Zd(e, t) {
  if (ir(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (ir(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Jr = {
  name: "BaseComponent",
  props: {
    pt: {
      type: Object,
      default: void 0
    },
    ptOptions: {
      type: Object,
      default: void 0
    },
    unstyled: {
      type: Boolean,
      default: void 0
    },
    dt: {
      type: Object,
      default: void 0
    }
  },
  inject: {
    $parentInstance: {
      default: void 0
    }
  },
  watch: {
    isUnstyled: {
      immediate: !0,
      handler: function(t) {
        t || (this._loadCoreStyles(), this._themeChangeListener(this._loadCoreStyles));
      }
    },
    dt: {
      immediate: !0,
      handler: function(t) {
        var r = this;
        t ? (this._loadScopedThemeStyles(t), this._themeChangeListener(function() {
          return r._loadScopedThemeStyles(t);
        })) : this._unloadScopedThemeStyles();
      }
    }
  },
  scopedStyleEl: void 0,
  rootEl: void 0,
  $attrSelector: void 0,
  beforeCreate: function() {
    var t, r, n, o, a, s, i, l, c, u, p, b = (t = this.pt) === null || t === void 0 ? void 0 : t._usept, h = b ? (r = this.pt) === null || r === void 0 || (r = r.originalValue) === null || r === void 0 ? void 0 : r[this.$.type.name] : void 0, w = b ? (n = this.pt) === null || n === void 0 || (n = n.value) === null || n === void 0 ? void 0 : n[this.$.type.name] : this.pt;
    (o = w || h) === null || o === void 0 || (o = o.hooks) === null || o === void 0 || (a = o.onBeforeCreate) === null || a === void 0 || a.call(o);
    var C = (s = this.$primevueConfig) === null || s === void 0 || (s = s.pt) === null || s === void 0 ? void 0 : s._usept, A = C ? (i = this.$primevue) === null || i === void 0 || (i = i.config) === null || i === void 0 || (i = i.pt) === null || i === void 0 ? void 0 : i.originalValue : void 0, z = C ? (l = this.$primevue) === null || l === void 0 || (l = l.config) === null || l === void 0 || (l = l.pt) === null || l === void 0 ? void 0 : l.value : (c = this.$primevue) === null || c === void 0 || (c = c.config) === null || c === void 0 ? void 0 : c.pt;
    (u = z || A) === null || u === void 0 || (u = u[this.$.type.name]) === null || u === void 0 || (u = u.hooks) === null || u === void 0 || (p = u.onBeforeCreate) === null || p === void 0 || p.call(u), this.$attrSelector = ha("pc");
  },
  created: function() {
    this._hook("onCreated");
  },
  beforeMount: function() {
    this.rootEl = Dl(this.$el, '[data-pc-name="'.concat(Ne(this.$.type.name), '"]')), this.rootEl && (this.$attrSelector && !this.rootEl.hasAttribute(this.$attrSelector) && this.rootEl.setAttribute(this.$attrSelector, ""), this.rootEl.$pc = M({
      name: this.$.type.name,
      attrSelector: this.$attrSelector
    }, this.$params)), this._loadStyles(), this._hook("onBeforeMount");
  },
  mounted: function() {
    this._hook("onMounted");
  },
  beforeUpdate: function() {
    this._hook("onBeforeUpdate");
  },
  updated: function() {
    this._hook("onUpdated");
  },
  beforeUnmount: function() {
    this._hook("onBeforeUnmount");
  },
  unmounted: function() {
    this._unloadScopedThemeStyles(), this._hook("onUnmounted");
  },
  methods: {
    _hook: function(t) {
      if (!this.$options.hostName) {
        var r = this._usePT(this._getPT(this.pt, this.$.type.name), this._getOptionValue, "hooks.".concat(t)), n = this._useDefaultPT(this._getOptionValue, "hooks.".concat(t));
        r == null || r(), n == null || n();
      }
    },
    _mergeProps: function(t) {
      for (var r = arguments.length, n = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++)
        n[o - 1] = arguments[o];
      return Sn(t) ? t.apply(void 0, n) : ve.apply(void 0, n);
    },
    _loadStyles: function() {
      var t = this, r = function() {
        it.isStyleNameLoaded("base") || (Q.loadCSS(t.$styleOptions), t._loadGlobalStyles(), it.setLoadedStyleName("base")), t._loadThemeStyles();
      };
      r(), this._themeChangeListener(r);
    },
    _loadCoreStyles: function() {
      var t, r;
      !it.isStyleNameLoaded((t = this.$style) === null || t === void 0 ? void 0 : t.name) && (r = this.$style) !== null && r !== void 0 && r.name && (Xo.loadCSS(this.$styleOptions), this.$options.style && this.$style.loadCSS(this.$styleOptions), it.setLoadedStyleName(this.$style.name));
    },
    _loadGlobalStyles: function() {
      var t = this._useGlobalPT(this._getOptionValue, "global.css", this.$params);
      J(t) && Q.load(t, M({
        name: "global"
      }, this.$styleOptions));
    },
    _loadThemeStyles: function() {
      var t, r;
      if (!(this.isUnstyled || this.$theme === "none")) {
        if (!q.isStyleNameLoaded("common")) {
          var n, o, a = ((n = this.$style) === null || n === void 0 || (o = n.getCommonTheme) === null || o === void 0 ? void 0 : o.call(n)) || {}, s = a.primitive, i = a.semantic, l = a.global, c = a.style;
          Q.load(s == null ? void 0 : s.css, M({
            name: "primitive-variables"
          }, this.$styleOptions)), Q.load(i == null ? void 0 : i.css, M({
            name: "semantic-variables"
          }, this.$styleOptions)), Q.load(l == null ? void 0 : l.css, M({
            name: "global-variables"
          }, this.$styleOptions)), Q.loadTheme(M({
            name: "global-style"
          }, this.$styleOptions), c), q.setLoadedStyleName("common");
        }
        if (!q.isStyleNameLoaded((t = this.$style) === null || t === void 0 ? void 0 : t.name) && (r = this.$style) !== null && r !== void 0 && r.name) {
          var u, p, b, h, w = ((u = this.$style) === null || u === void 0 || (p = u.getComponentTheme) === null || p === void 0 ? void 0 : p.call(u)) || {}, C = w.css, A = w.style;
          (b = this.$style) === null || b === void 0 || b.load(C, M({
            name: "".concat(this.$style.name, "-variables")
          }, this.$styleOptions)), (h = this.$style) === null || h === void 0 || h.loadTheme(M({
            name: "".concat(this.$style.name, "-style")
          }, this.$styleOptions), A), q.setLoadedStyleName(this.$style.name);
        }
        if (!q.isStyleNameLoaded("layer-order")) {
          var z, I, v = (z = this.$style) === null || z === void 0 || (I = z.getLayerOrderThemeCSS) === null || I === void 0 ? void 0 : I.call(z);
          Q.load(v, M({
            name: "layer-order",
            first: !0
          }, this.$styleOptions)), q.setLoadedStyleName("layer-order");
        }
      }
    },
    _loadScopedThemeStyles: function(t) {
      var r, n, o, a = ((r = this.$style) === null || r === void 0 || (n = r.getPresetTheme) === null || n === void 0 ? void 0 : n.call(r, t, "[".concat(this.$attrSelector, "]"))) || {}, s = a.css, i = (o = this.$style) === null || o === void 0 ? void 0 : o.load(s, M({
        name: "".concat(this.$attrSelector, "-").concat(this.$style.name)
      }, this.$styleOptions));
      this.scopedStyleEl = i.el;
    },
    _unloadScopedThemeStyles: function() {
      var t;
      (t = this.scopedStyleEl) === null || t === void 0 || (t = t.value) === null || t === void 0 || t.remove();
    },
    _themeChangeListener: function() {
      var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function() {
      };
      it.clearLoadedStyleNames(), Ee.on("theme:change", t);
    },
    _getHostInstance: function(t) {
      return t ? this.$options.hostName ? t.$.type.name === this.$options.hostName ? t : this._getHostInstance(t.$parentInstance) : t.$parentInstance : void 0;
    },
    _getPropValue: function(t) {
      var r;
      return this[t] || ((r = this._getHostInstance(this)) === null || r === void 0 ? void 0 : r[t]);
    },
    _getOptionValue: function(t) {
      var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "", n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      return Cn(t, r, n);
    },
    _getPTValue: function() {
      var t, r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "", o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, a = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : !0, s = /./g.test(n) && !!o[n.split(".")[0]], i = this._getPropValue("ptOptions") || ((t = this.$primevueConfig) === null || t === void 0 ? void 0 : t.ptOptions) || {}, l = i.mergeSections, c = l === void 0 ? !0 : l, u = i.mergeProps, p = u === void 0 ? !1 : u, b = a ? s ? this._useGlobalPT(this._getPTClassValue, n, o) : this._useDefaultPT(this._getPTClassValue, n, o) : void 0, h = s ? void 0 : this._getPTSelf(r, this._getPTClassValue, n, M(M({}, o), {}, {
        global: b || {}
      })), w = this._getPTDatasets(n);
      return c || !c && h ? p ? this._mergeProps(p, b, h, w) : M(M(M({}, b), h), w) : M(M({}, h), w);
    },
    _getPTSelf: function() {
      for (var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, r = arguments.length, n = new Array(r > 1 ? r - 1 : 0), o = 1; o < r; o++)
        n[o - 1] = arguments[o];
      return ve(
        this._usePT.apply(this, [this._getPT(t, this.$name)].concat(n)),
        // Exp; <component :pt="{}"
        this._usePT.apply(this, [this.$_attrsPT].concat(n))
        // Exp; <component :pt:[passthrough_key]:[attribute]="{value}" or <component :pt:[passthrough_key]="() =>{value}"
      );
    },
    _getPTDatasets: function() {
      var t, r, n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", o = "data-pc-", a = n === "root" && J((t = this.pt) === null || t === void 0 ? void 0 : t["data-pc-section"]);
      return n !== "transition" && M(M({}, n === "root" && M(M(Ut({}, "".concat(o, "name"), Ne(a ? (r = this.pt) === null || r === void 0 ? void 0 : r["data-pc-section"] : this.$.type.name)), a && Ut({}, "".concat(o, "extend"), Ne(this.$.type.name))), ga() && Ut({}, "".concat(this.$attrSelector), ""))), {}, Ut({}, "".concat(o, "section"), Ne(n)));
    },
    _getPTClassValue: function() {
      var t = this._getOptionValue.apply(this, arguments);
      return xe(t) || Er(t) ? {
        class: t
      } : t;
    },
    _getPT: function(t) {
      var r = this, n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "", o = arguments.length > 2 ? arguments[2] : void 0, a = function(i) {
        var l, c = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, u = o ? o(i) : i, p = Ne(n), b = Ne(r.$name);
        return (l = c ? p !== b ? u == null ? void 0 : u[p] : void 0 : u == null ? void 0 : u[p]) !== null && l !== void 0 ? l : u;
      };
      return t != null && t.hasOwnProperty("_usept") ? {
        _usept: t._usept,
        originalValue: a(t.originalValue),
        value: a(t.value)
      } : a(t, !0);
    },
    _usePT: function(t, r, n, o) {
      var a = function(C) {
        return r(C, n, o);
      };
      if (t != null && t.hasOwnProperty("_usept")) {
        var s, i = t._usept || ((s = this.$primevueConfig) === null || s === void 0 ? void 0 : s.ptOptions) || {}, l = i.mergeSections, c = l === void 0 ? !0 : l, u = i.mergeProps, p = u === void 0 ? !1 : u, b = a(t.originalValue), h = a(t.value);
        return b === void 0 && h === void 0 ? void 0 : xe(h) ? h : xe(b) ? b : c || !c && h ? p ? this._mergeProps(p, b, h) : M(M({}, b), h) : h;
      }
      return a(t);
    },
    _useGlobalPT: function(t, r, n) {
      return this._usePT(this.globalPT, t, r, n);
    },
    _useDefaultPT: function(t, r, n) {
      return this._usePT(this.defaultPT, t, r, n);
    },
    ptm: function() {
      var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return this._getPTValue(this.pt, t, M(M({}, this.$params), r));
    },
    ptmi: function() {
      var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return ve(this.$_attrsWithoutPT, this.ptm(t, r));
    },
    ptmo: function() {
      var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "", n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      return this._getPTValue(t, r, M({
        instance: this
      }, n), !1);
    },
    cx: function() {
      var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
      return this.isUnstyled ? void 0 : this._getOptionValue(this.$style.classes, t, M(M({}, this.$params), r));
    },
    sx: function() {
      var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0, n = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
      if (r) {
        var o = this._getOptionValue(this.$style.inlineStyles, t, M(M({}, this.$params), n)), a = this._getOptionValue(Xo.inlineStyles, t, M(M({}, this.$params), n));
        return [a, o];
      }
    }
  },
  computed: {
    globalPT: function() {
      var t, r = this;
      return this._getPT((t = this.$primevueConfig) === null || t === void 0 ? void 0 : t.pt, void 0, function(n) {
        return je(n, {
          instance: r
        });
      });
    },
    defaultPT: function() {
      var t, r = this;
      return this._getPT((t = this.$primevueConfig) === null || t === void 0 ? void 0 : t.pt, void 0, function(n) {
        return r._getOptionValue(n, r.$name, M({}, r.$params)) || je(n, M({}, r.$params));
      });
    },
    isUnstyled: function() {
      var t;
      return this.unstyled !== void 0 ? this.unstyled : (t = this.$primevueConfig) === null || t === void 0 ? void 0 : t.unstyled;
    },
    $theme: function() {
      var t;
      return (t = this.$primevueConfig) === null || t === void 0 ? void 0 : t.theme;
    },
    $style: function() {
      return M(M({
        classes: void 0,
        inlineStyles: void 0,
        load: function() {
        },
        loadCSS: function() {
        },
        loadTheme: function() {
        }
      }, (this._getHostInstance(this) || {}).$style), this.$options.style);
    },
    $styleOptions: function() {
      var t;
      return {
        nonce: (t = this.$primevueConfig) === null || t === void 0 || (t = t.csp) === null || t === void 0 ? void 0 : t.nonce
      };
    },
    $primevueConfig: function() {
      var t;
      return (t = this.$primevue) === null || t === void 0 ? void 0 : t.config;
    },
    $name: function() {
      return this.$options.hostName || this.$.type.name;
    },
    $params: function() {
      var t = this._getHostInstance(this) || this.$parent;
      return {
        instance: this,
        props: this.$props,
        state: this.$data,
        attrs: this.$attrs,
        parent: {
          instance: t,
          props: t == null ? void 0 : t.$props,
          state: t == null ? void 0 : t.$data,
          attrs: t == null ? void 0 : t.$attrs
        }
      };
    },
    $_attrsPT: function() {
      return Object.entries(this.$attrs || {}).filter(function(t) {
        var r = Sr(t, 1), n = r[0];
        return n == null ? void 0 : n.startsWith("pt:");
      }).reduce(function(t, r) {
        var n = Sr(r, 2), o = n[0], a = n[1], s = o.split(":"), i = qd(s), l = i.slice(1);
        return l == null || l.reduce(function(c, u, p, b) {
          return !c[u] && (c[u] = p === b.length - 1 ? a : {}), c[u];
        }, t), t;
      }, {});
    },
    $_attrsWithoutPT: function() {
      return Object.entries(this.$attrs || {}).filter(function(t) {
        var r = Sr(t, 1), n = r[0];
        return !(n != null && n.startsWith("pt:"));
      }).reduce(function(t, r) {
        var n = Sr(r, 2), o = n[0], a = n[1];
        return t[o] = a, t;
      }, {});
    }
  }
}, Xd = `
.p-icon {
    display: inline-block;
    vertical-align: baseline;
}

.p-icon-spin {
    -webkit-animation: p-icon-spin 2s infinite linear;
    animation: p-icon-spin 2s infinite linear;
}

@-webkit-keyframes p-icon-spin {
    0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(359deg);
        transform: rotate(359deg);
    }
}

@keyframes p-icon-spin {
    0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg);
    }
    100% {
        -webkit-transform: rotate(359deg);
        transform: rotate(359deg);
    }
}
`, ef = Q.extend({
  name: "baseicon",
  css: Xd
});
function lr(e) {
  "@babel/helpers - typeof";
  return lr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, lr(e);
}
function ra(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(o) {
      return Object.getOwnPropertyDescriptor(e, o).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function na(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? ra(Object(r), !0).forEach(function(n) {
      tf(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : ra(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function tf(e, t, r) {
  return (t = rf(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function rf(e) {
  var t = nf(e, "string");
  return lr(t) == "symbol" ? t : t + "";
}
function nf(e, t) {
  if (lr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (lr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var of = {
  name: "BaseIcon",
  extends: Jr,
  props: {
    label: {
      type: String,
      default: void 0
    },
    spin: {
      type: Boolean,
      default: !1
    }
  },
  style: ef,
  provide: function() {
    return {
      $pcIcon: this,
      $parentInstance: this
    };
  },
  methods: {
    pti: function() {
      var t = bt(this.label);
      return na(na({}, !this.isUnstyled && {
        class: ["p-icon", {
          "p-icon-spin": this.spin
        }]
      }), {}, {
        role: t ? void 0 : "img",
        "aria-label": t ? void 0 : this.label,
        "aria-hidden": t
      });
    }
  }
}, Os = {
  name: "SpinnerIcon",
  extends: of
};
function af(e, t, r, n, o, a) {
  return Ve(), Rt("svg", ve({
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    fill: "none",
    xmlns: "http://www.w3.org/2000/svg"
  }, e.pti()), t[0] || (t[0] = [pe("path", {
    d: "M6.99701 14C5.85441 13.999 4.72939 13.7186 3.72012 13.1832C2.71084 12.6478 1.84795 11.8737 1.20673 10.9284C0.565504 9.98305 0.165424 8.89526 0.041387 7.75989C-0.0826496 6.62453 0.073125 5.47607 0.495122 4.4147C0.917119 3.35333 1.59252 2.4113 2.46241 1.67077C3.33229 0.930247 4.37024 0.413729 5.4857 0.166275C6.60117 -0.0811796 7.76026 -0.0520535 8.86188 0.251112C9.9635 0.554278 10.9742 1.12227 11.8057 1.90555C11.915 2.01493 11.9764 2.16319 11.9764 2.31778C11.9764 2.47236 11.915 2.62062 11.8057 2.73C11.7521 2.78503 11.688 2.82877 11.6171 2.85864C11.5463 2.8885 11.4702 2.90389 11.3933 2.90389C11.3165 2.90389 11.2404 2.8885 11.1695 2.85864C11.0987 2.82877 11.0346 2.78503 10.9809 2.73C9.9998 1.81273 8.73246 1.26138 7.39226 1.16876C6.05206 1.07615 4.72086 1.44794 3.62279 2.22152C2.52471 2.99511 1.72683 4.12325 1.36345 5.41602C1.00008 6.70879 1.09342 8.08723 1.62775 9.31926C2.16209 10.5513 3.10478 11.5617 4.29713 12.1803C5.48947 12.7989 6.85865 12.988 8.17414 12.7157C9.48963 12.4435 10.6711 11.7264 11.5196 10.6854C12.3681 9.64432 12.8319 8.34282 12.8328 7C12.8328 6.84529 12.8943 6.69692 13.0038 6.58752C13.1132 6.47812 13.2616 6.41667 13.4164 6.41667C13.5712 6.41667 13.7196 6.47812 13.8291 6.58752C13.9385 6.69692 14 6.84529 14 7C14 8.85651 13.2622 10.637 11.9489 11.9497C10.6356 13.2625 8.85432 14 6.99701 14Z",
    fill: "currentColor"
  }, null, -1)]), 16);
}
Os.render = af;
var sf = function(t) {
  var r = t.dt;
  return `
.p-badge {
    display: inline-flex;
    border-radius: `.concat(r("badge.border.radius"), `;
    align-items: center;
    justify-content: center;
    padding: `).concat(r("badge.padding"), `;
    background: `).concat(r("badge.primary.background"), `;
    color: `).concat(r("badge.primary.color"), `;
    font-size: `).concat(r("badge.font.size"), `;
    font-weight: `).concat(r("badge.font.weight"), `;
    min-width: `).concat(r("badge.min.width"), `;
    height: `).concat(r("badge.height"), `;
}

.p-badge-dot {
    width: `).concat(r("badge.dot.size"), `;
    min-width: `).concat(r("badge.dot.size"), `;
    height: `).concat(r("badge.dot.size"), `;
    border-radius: 50%;
    padding: 0;
}

.p-badge-circle {
    padding: 0;
    border-radius: 50%;
}

.p-badge-secondary {
    background: `).concat(r("badge.secondary.background"), `;
    color: `).concat(r("badge.secondary.color"), `;
}

.p-badge-success {
    background: `).concat(r("badge.success.background"), `;
    color: `).concat(r("badge.success.color"), `;
}

.p-badge-info {
    background: `).concat(r("badge.info.background"), `;
    color: `).concat(r("badge.info.color"), `;
}

.p-badge-warn {
    background: `).concat(r("badge.warn.background"), `;
    color: `).concat(r("badge.warn.color"), `;
}

.p-badge-danger {
    background: `).concat(r("badge.danger.background"), `;
    color: `).concat(r("badge.danger.color"), `;
}

.p-badge-contrast {
    background: `).concat(r("badge.contrast.background"), `;
    color: `).concat(r("badge.contrast.color"), `;
}

.p-badge-sm {
    font-size: `).concat(r("badge.sm.font.size"), `;
    min-width: `).concat(r("badge.sm.min.width"), `;
    height: `).concat(r("badge.sm.height"), `;
}

.p-badge-lg {
    font-size: `).concat(r("badge.lg.font.size"), `;
    min-width: `).concat(r("badge.lg.min.width"), `;
    height: `).concat(r("badge.lg.height"), `;
}

.p-badge-xl {
    font-size: `).concat(r("badge.xl.font.size"), `;
    min-width: `).concat(r("badge.xl.min.width"), `;
    height: `).concat(r("badge.xl.height"), `;
}
`);
}, lf = {
  root: function(t) {
    var r = t.props, n = t.instance;
    return ["p-badge p-component", {
      "p-badge-circle": J(r.value) && String(r.value).length === 1,
      "p-badge-dot": bt(r.value) && !n.$slots.default,
      "p-badge-sm": r.size === "small",
      "p-badge-lg": r.size === "large",
      "p-badge-xl": r.size === "xlarge",
      "p-badge-info": r.severity === "info",
      "p-badge-success": r.severity === "success",
      "p-badge-warn": r.severity === "warn",
      "p-badge-danger": r.severity === "danger",
      "p-badge-secondary": r.severity === "secondary",
      "p-badge-contrast": r.severity === "contrast"
    }];
  }
}, cf = Q.extend({
  name: "badge",
  theme: sf,
  classes: lf
}), uf = {
  name: "BaseBadge",
  extends: Jr,
  props: {
    value: {
      type: [String, Number],
      default: null
    },
    severity: {
      type: String,
      default: null
    },
    size: {
      type: String,
      default: null
    }
  },
  style: cf,
  provide: function() {
    return {
      $pcBadge: this,
      $parentInstance: this
    };
  }
}, js = {
  name: "Badge",
  extends: uf,
  inheritAttrs: !1
};
function df(e, t, r, n, o, a) {
  return Ve(), Rt("span", ve({
    class: e.cx("root")
  }, e.ptmi("root")), [Dt(e.$slots, "default", {}, function() {
    return [ks(In(e.value), 1)];
  })], 16);
}
js.render = df;
function cr(e) {
  "@babel/helpers - typeof";
  return cr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, cr(e);
}
function oa(e, t) {
  return gf(e) || bf(e, t) || pf(e, t) || ff();
}
function ff() {
  throw new TypeError(`Invalid attempt to destructure non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function pf(e, t) {
  if (e) {
    if (typeof e == "string") return aa(e, t);
    var r = {}.toString.call(e).slice(8, -1);
    return r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set" ? Array.from(e) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? aa(e, t) : void 0;
  }
}
function aa(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function bf(e, t) {
  var r = e == null ? null : typeof Symbol < "u" && e[Symbol.iterator] || e["@@iterator"];
  if (r != null) {
    var n, o, a, s, i = [], l = !0, c = !1;
    try {
      if (a = (r = r.call(e)).next, t !== 0) for (; !(l = (n = a.call(r)).done) && (i.push(n.value), i.length !== t); l = !0) ;
    } catch (u) {
      c = !0, o = u;
    } finally {
      try {
        if (!l && r.return != null && (s = r.return(), Object(s) !== s)) return;
      } finally {
        if (c) throw o;
      }
    }
    return i;
  }
}
function gf(e) {
  if (Array.isArray(e)) return e;
}
function sa(e, t) {
  var r = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var n = Object.getOwnPropertySymbols(e);
    t && (n = n.filter(function(o) {
      return Object.getOwnPropertyDescriptor(e, o).enumerable;
    })), r.push.apply(r, n);
  }
  return r;
}
function D(e) {
  for (var t = 1; t < arguments.length; t++) {
    var r = arguments[t] != null ? arguments[t] : {};
    t % 2 ? sa(Object(r), !0).forEach(function(n) {
      kn(e, n, r[n]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(r)) : sa(Object(r)).forEach(function(n) {
      Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(r, n));
    });
  }
  return e;
}
function kn(e, t, r) {
  return (t = hf(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function hf(e) {
  var t = mf(e, "string");
  return cr(t) == "symbol" ? t : t + "";
}
function mf(e, t) {
  if (cr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (cr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var F = {
  _getMeta: function() {
    return [qe(arguments.length <= 0 ? void 0 : arguments[0]) || arguments.length <= 0 ? void 0 : arguments[0], je(qe(arguments.length <= 0 ? void 0 : arguments[0]) ? arguments.length <= 0 ? void 0 : arguments[0] : arguments.length <= 1 ? void 0 : arguments[1])];
  },
  _getConfig: function(t, r) {
    var n, o, a;
    return (n = (t == null || (o = t.instance) === null || o === void 0 ? void 0 : o.$primevue) || (r == null || (a = r.ctx) === null || a === void 0 || (a = a.appContext) === null || a === void 0 || (a = a.config) === null || a === void 0 || (a = a.globalProperties) === null || a === void 0 ? void 0 : a.$primevue)) === null || n === void 0 ? void 0 : n.config;
  },
  _getOptionValue: Cn,
  _getPTValue: function() {
    var t, r, n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, o = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, a = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : "", s = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : {}, i = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : !0, l = function() {
      var I = F._getOptionValue.apply(F, arguments);
      return xe(I) || Er(I) ? {
        class: I
      } : I;
    }, c = ((t = n.binding) === null || t === void 0 || (t = t.value) === null || t === void 0 ? void 0 : t.ptOptions) || ((r = n.$primevueConfig) === null || r === void 0 ? void 0 : r.ptOptions) || {}, u = c.mergeSections, p = u === void 0 ? !0 : u, b = c.mergeProps, h = b === void 0 ? !1 : b, w = i ? F._useDefaultPT(n, n.defaultPT(), l, a, s) : void 0, C = F._usePT(n, F._getPT(o, n.$name), l, a, D(D({}, s), {}, {
      global: w || {}
    })), A = F._getPTDatasets(n, a);
    return p || !p && C ? h ? F._mergeProps(n, h, w, C, A) : D(D(D({}, w), C), A) : D(D({}, C), A);
  },
  _getPTDatasets: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "", n = "data-pc-";
    return D(D({}, r === "root" && kn({}, "".concat(n, "name"), Ne(t.$name))), {}, kn({}, "".concat(n, "section"), Ne(r)));
  },
  _getPT: function(t) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "", n = arguments.length > 2 ? arguments[2] : void 0, o = function(s) {
      var i, l = n ? n(s) : s, c = Ne(r);
      return (i = l == null ? void 0 : l[c]) !== null && i !== void 0 ? i : l;
    };
    return t != null && t.hasOwnProperty("_usept") ? {
      _usept: t._usept,
      originalValue: o(t.originalValue),
      value: o(t.value)
    } : o(t);
  },
  _usePT: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, r = arguments.length > 1 ? arguments[1] : void 0, n = arguments.length > 2 ? arguments[2] : void 0, o = arguments.length > 3 ? arguments[3] : void 0, a = arguments.length > 4 ? arguments[4] : void 0, s = function(A) {
      return n(A, o, a);
    };
    if (r != null && r.hasOwnProperty("_usept")) {
      var i, l = r._usept || ((i = t.$primevueConfig) === null || i === void 0 ? void 0 : i.ptOptions) || {}, c = l.mergeSections, u = c === void 0 ? !0 : c, p = l.mergeProps, b = p === void 0 ? !1 : p, h = s(r.originalValue), w = s(r.value);
      return h === void 0 && w === void 0 ? void 0 : xe(w) ? w : xe(h) ? h : u || !u && w ? b ? F._mergeProps(t, b, h, w) : D(D({}, h), w) : w;
    }
    return s(r);
  },
  _useDefaultPT: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, n = arguments.length > 2 ? arguments[2] : void 0, o = arguments.length > 3 ? arguments[3] : void 0, a = arguments.length > 4 ? arguments[4] : void 0;
    return F._usePT(t, r, n, o, a);
  },
  _loadStyles: function(t, r, n) {
    var o, a = F._getConfig(r, n), s = {
      nonce: a == null || (o = a.csp) === null || o === void 0 ? void 0 : o.nonce
    };
    F._loadCoreStyles(t.$instance, s), F._loadThemeStyles(t.$instance, s), F._loadScopedThemeStyles(t.$instance, s), F._themeChangeListener(function() {
      return F._loadThemeStyles(t.$instance, s);
    });
  },
  _loadCoreStyles: function() {
    var t, r, n = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, o = arguments.length > 1 ? arguments[1] : void 0;
    if (!it.isStyleNameLoaded((t = n.$style) === null || t === void 0 ? void 0 : t.name) && (r = n.$style) !== null && r !== void 0 && r.name) {
      var a;
      Q.loadCSS(o), (a = n.$style) === null || a === void 0 || a.loadCSS(o), it.setLoadedStyleName(n.$style.name);
    }
  },
  _loadThemeStyles: function() {
    var t, r, n, o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, a = arguments.length > 1 ? arguments[1] : void 0;
    if (!(o != null && o.isUnstyled() || (o == null || (t = o.theme) === null || t === void 0 ? void 0 : t.call(o)) === "none")) {
      if (!q.isStyleNameLoaded("common")) {
        var s, i, l = ((s = o.$style) === null || s === void 0 || (i = s.getCommonTheme) === null || i === void 0 ? void 0 : i.call(s)) || {}, c = l.primitive, u = l.semantic, p = l.global, b = l.style;
        Q.load(c == null ? void 0 : c.css, D({
          name: "primitive-variables"
        }, a)), Q.load(u == null ? void 0 : u.css, D({
          name: "semantic-variables"
        }, a)), Q.load(p == null ? void 0 : p.css, D({
          name: "global-variables"
        }, a)), Q.loadTheme(D({
          name: "global-style"
        }, a), b), q.setLoadedStyleName("common");
      }
      if (!q.isStyleNameLoaded((r = o.$style) === null || r === void 0 ? void 0 : r.name) && (n = o.$style) !== null && n !== void 0 && n.name) {
        var h, w, C, A, z = ((h = o.$style) === null || h === void 0 || (w = h.getDirectiveTheme) === null || w === void 0 ? void 0 : w.call(h)) || {}, I = z.css, v = z.style;
        (C = o.$style) === null || C === void 0 || C.load(I, D({
          name: "".concat(o.$style.name, "-variables")
        }, a)), (A = o.$style) === null || A === void 0 || A.loadTheme(D({
          name: "".concat(o.$style.name, "-style")
        }, a), v), q.setLoadedStyleName(o.$style.name);
      }
      if (!q.isStyleNameLoaded("layer-order")) {
        var P, U, E = (P = o.$style) === null || P === void 0 || (U = P.getLayerOrderThemeCSS) === null || U === void 0 ? void 0 : U.call(P);
        Q.load(E, D({
          name: "layer-order",
          first: !0
        }, a)), q.setLoadedStyleName("layer-order");
      }
    }
  },
  _loadScopedThemeStyles: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, r = arguments.length > 1 ? arguments[1] : void 0, n = t.preset();
    if (n && t.$attrSelector) {
      var o, a, s, i = ((o = t.$style) === null || o === void 0 || (a = o.getPresetTheme) === null || a === void 0 ? void 0 : a.call(o, n, "[".concat(t.$attrSelector, "]"))) || {}, l = i.css, c = (s = t.$style) === null || s === void 0 ? void 0 : s.load(l, D({
        name: "".concat(t.$attrSelector, "-").concat(t.$style.name)
      }, r));
      t.scopedStyleEl = c.el;
    }
  },
  _themeChangeListener: function() {
    var t = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : function() {
    };
    it.clearLoadedStyleNames(), Ee.on("theme:change", t);
  },
  _hook: function(t, r, n, o, a, s) {
    var i, l, c = "on".concat(Pl(r)), u = F._getConfig(o, a), p = n == null ? void 0 : n.$instance, b = F._usePT(p, F._getPT(o == null || (i = o.value) === null || i === void 0 ? void 0 : i.pt, t), F._getOptionValue, "hooks.".concat(c)), h = F._useDefaultPT(p, u == null || (l = u.pt) === null || l === void 0 || (l = l.directives) === null || l === void 0 ? void 0 : l[t], F._getOptionValue, "hooks.".concat(c)), w = {
      el: n,
      binding: o,
      vnode: a,
      prevVnode: s
    };
    b == null || b(p, w), h == null || h(p, w);
  },
  _mergeProps: function() {
    for (var t = arguments.length > 1 ? arguments[1] : void 0, r = arguments.length, n = new Array(r > 2 ? r - 2 : 0), o = 2; o < r; o++)
      n[o - 2] = arguments[o];
    return Sn(t) ? t.apply(void 0, n) : ve.apply(void 0, n);
  },
  _extend: function(t) {
    var r = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {}, n = function(s, i, l, c, u) {
      var p, b, h, w;
      i._$instances = i._$instances || {};
      var C = F._getConfig(l, c), A = i._$instances[t] || {}, z = bt(A) ? D(D({}, r), r == null ? void 0 : r.methods) : {};
      i._$instances[t] = D(D({}, A), {}, {
        /* new instance variables to pass in directive methods */
        $name: t,
        $host: i,
        $binding: l,
        $modifiers: l == null ? void 0 : l.modifiers,
        $value: l == null ? void 0 : l.value,
        $el: A.$el || i || void 0,
        $style: D({
          classes: void 0,
          inlineStyles: void 0,
          load: function() {
          },
          loadCSS: function() {
          },
          loadTheme: function() {
          }
        }, r == null ? void 0 : r.style),
        $primevueConfig: C,
        $attrSelector: (p = i.$pd) === null || p === void 0 || (p = p[t]) === null || p === void 0 ? void 0 : p.attrSelector,
        /* computed instance variables */
        defaultPT: function() {
          return F._getPT(C == null ? void 0 : C.pt, void 0, function(v) {
            var P;
            return v == null || (P = v.directives) === null || P === void 0 ? void 0 : P[t];
          });
        },
        isUnstyled: function() {
          var v, P;
          return ((v = i.$instance) === null || v === void 0 || (v = v.$binding) === null || v === void 0 || (v = v.value) === null || v === void 0 ? void 0 : v.unstyled) !== void 0 ? (P = i.$instance) === null || P === void 0 || (P = P.$binding) === null || P === void 0 || (P = P.value) === null || P === void 0 ? void 0 : P.unstyled : C == null ? void 0 : C.unstyled;
        },
        theme: function() {
          var v;
          return (v = i.$instance) === null || v === void 0 || (v = v.$primevueConfig) === null || v === void 0 ? void 0 : v.theme;
        },
        preset: function() {
          var v;
          return (v = i.$instance) === null || v === void 0 || (v = v.$binding) === null || v === void 0 || (v = v.value) === null || v === void 0 ? void 0 : v.dt;
        },
        /* instance's methods */
        ptm: function() {
          var v, P = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", U = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          return F._getPTValue(i.$instance, (v = i.$instance) === null || v === void 0 || (v = v.$binding) === null || v === void 0 || (v = v.value) === null || v === void 0 ? void 0 : v.pt, P, D({}, U));
        },
        ptmo: function() {
          var v = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : {}, P = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "", U = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
          return F._getPTValue(i.$instance, v, P, U, !1);
        },
        cx: function() {
          var v, P, U = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", E = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
          return (v = i.$instance) !== null && v !== void 0 && v.isUnstyled() ? void 0 : F._getOptionValue((P = i.$instance) === null || P === void 0 || (P = P.$style) === null || P === void 0 ? void 0 : P.classes, U, D({}, E));
        },
        sx: function() {
          var v, P = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : "", U = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0, E = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {};
          return U ? F._getOptionValue((v = i.$instance) === null || v === void 0 || (v = v.$style) === null || v === void 0 ? void 0 : v.inlineStyles, P, D({}, E)) : void 0;
        }
      }, z), i.$instance = i._$instances[t], (b = (h = i.$instance)[s]) === null || b === void 0 || b.call(h, i, l, c, u), i["$".concat(t)] = i.$instance, F._hook(t, s, i, l, c, u), i.$pd || (i.$pd = {}), i.$pd[t] = D(D({}, (w = i.$pd) === null || w === void 0 ? void 0 : w[t]), {}, {
        name: t,
        instance: i.$instance
      });
    }, o = function(s) {
      var i, l, c, u, p, b = (i = s.$instance) === null || i === void 0 ? void 0 : i.watch;
      b == null || (l = b.config) === null || l === void 0 || l.call(s.$instance, (c = s.$instance) === null || c === void 0 ? void 0 : c.$primevueConfig), jt.on("config:change", function(h) {
        var w, C = h.newValue, A = h.oldValue;
        return b == null || (w = b.config) === null || w === void 0 ? void 0 : w.call(s.$instance, C, A);
      }), b == null || (u = b["config.ripple"]) === null || u === void 0 || u.call(s.$instance, (p = s.$instance) === null || p === void 0 || (p = p.$primevueConfig) === null || p === void 0 ? void 0 : p.ripple), jt.on("config:ripple:change", function(h) {
        var w, C = h.newValue, A = h.oldValue;
        return b == null || (w = b["config.ripple"]) === null || w === void 0 ? void 0 : w.call(s.$instance, C, A);
      });
    };
    return {
      created: function(s, i, l, c) {
        s.$pd || (s.$pd = {}), s.$pd[t] = {
          name: t,
          attrSelector: ha("pd")
        }, n("created", s, i, l, c);
      },
      beforeMount: function(s, i, l, c) {
        F._loadStyles(s, i, l), n("beforeMount", s, i, l, c), o(s);
      },
      mounted: function(s, i, l, c) {
        F._loadStyles(s, i, l), n("mounted", s, i, l, c);
      },
      beforeUpdate: function(s, i, l, c) {
        n("beforeUpdate", s, i, l, c);
      },
      updated: function(s, i, l, c) {
        F._loadStyles(s, i, l), n("updated", s, i, l, c);
      },
      beforeUnmount: function(s, i, l, c) {
        n("beforeUnmount", s, i, l, c);
      },
      unmounted: function(s, i, l, c) {
        var u;
        (u = s.$instance) === null || u === void 0 || (u = u.scopedStyleEl) === null || u === void 0 || (u = u.value) === null || u === void 0 || u.remove(), n("unmounted", s, i, l, c);
      }
    };
  },
  extend: function() {
    var t = F._getMeta.apply(F, arguments), r = oa(t, 2), n = r[0], o = r[1];
    return D({
      extend: function() {
        var s = F._getMeta.apply(F, arguments), i = oa(s, 2), l = i[0], c = i[1];
        return F.extend(l, D(D(D({}, o), o == null ? void 0 : o.methods), c));
      }
    }, F._extend(n, o));
  }
}, vf = function(t) {
  var r = t.dt;
  return `
.p-ink {
    display: block;
    position: absolute;
    background: `.concat(r("ripple.background"), `;
    border-radius: 100%;
    transform: scale(0);
    pointer-events: none;
}

.p-ink-active {
    animation: ripple 0.4s linear;
}

@keyframes ripple {
    100% {
        opacity: 0;
        transform: scale(2.5);
    }
}
`);
}, xf = {
  root: "p-ink"
}, yf = Q.extend({
  name: "ripple-directive",
  theme: vf,
  classes: xf
}), kf = F.extend({
  style: yf
});
function ur(e) {
  "@babel/helpers - typeof";
  return ur = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, ur(e);
}
function wf(e) {
  return $f(e) || Cf(e) || Sf(e) || _f();
}
function _f() {
  throw new TypeError(`Invalid attempt to spread non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
}
function Sf(e, t) {
  if (e) {
    if (typeof e == "string") return wn(e, t);
    var r = {}.toString.call(e).slice(8, -1);
    return r === "Object" && e.constructor && (r = e.constructor.name), r === "Map" || r === "Set" ? Array.from(e) : r === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(r) ? wn(e, t) : void 0;
  }
}
function Cf(e) {
  if (typeof Symbol < "u" && e[Symbol.iterator] != null || e["@@iterator"] != null) return Array.from(e);
}
function $f(e) {
  if (Array.isArray(e)) return wn(e);
}
function wn(e, t) {
  (t == null || t > e.length) && (t = e.length);
  for (var r = 0, n = Array(t); r < t; r++) n[r] = e[r];
  return n;
}
function ia(e, t, r) {
  return (t = Tf(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function Tf(e) {
  var t = Pf(e, "string");
  return ur(t) == "symbol" ? t : t + "";
}
function Pf(e, t) {
  if (ur(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (ur(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Of = kf.extend("ripple", {
  watch: {
    "config.ripple": function(t) {
      t ? (this.createRipple(this.$host), this.bindEvents(this.$host), this.$host.setAttribute("data-pd-ripple", !0), this.$host.style.overflow = "hidden", this.$host.style.position = "relative") : (this.remove(this.$host), this.$host.removeAttribute("data-pd-ripple"));
    }
  },
  unmounted: function(t) {
    this.remove(t);
  },
  timeout: void 0,
  methods: {
    bindEvents: function(t) {
      t.addEventListener("mousedown", this.onMouseDown.bind(this));
    },
    unbindEvents: function(t) {
      t.removeEventListener("mousedown", this.onMouseDown.bind(this));
    },
    createRipple: function(t) {
      var r = Bl("span", ia(ia({
        role: "presentation",
        "aria-hidden": !0,
        "data-p-ink": !0,
        "data-p-ink-active": !1,
        class: !this.isUnstyled() && this.cx("root"),
        onAnimationEnd: this.onAnimationEnd.bind(this)
      }, this.$attrSelector, ""), "p-bind", this.ptm("root")));
      t.appendChild(r), this.$el = r;
    },
    remove: function(t) {
      var r = this.getInk(t);
      r && (this.$host.style.overflow = "", this.$host.style.position = "", this.unbindEvents(t), r.removeEventListener("animationend", this.onAnimationEnd), r.remove());
    },
    onMouseDown: function(t) {
      var r = this, n = t.currentTarget, o = this.getInk(n);
      if (!(!o || getComputedStyle(o, null).display === "none")) {
        if (!this.isUnstyled() && Zr(o, "p-ink-active"), o.setAttribute("data-p-ink-active", "false"), !lo(o) && !co(o)) {
          var a = Math.max(Ml(n), Wl(n));
          o.style.height = a + "px", o.style.width = a + "px";
        }
        var s = Kl(n), i = t.pageX - s.left + document.body.scrollTop - co(o) / 2, l = t.pageY - s.top + document.body.scrollLeft - lo(o) / 2;
        o.style.top = l + "px", o.style.left = i + "px", !this.isUnstyled() && Vl(o, "p-ink-active"), o.setAttribute("data-p-ink-active", "true"), this.timeout = setTimeout(function() {
          o && (!r.isUnstyled() && Zr(o, "p-ink-active"), o.setAttribute("data-p-ink-active", "false"));
        }, 401);
      }
    },
    onAnimationEnd: function(t) {
      this.timeout && clearTimeout(this.timeout), !this.isUnstyled() && Zr(t.currentTarget, "p-ink-active"), t.currentTarget.setAttribute("data-p-ink-active", "false");
    },
    getInk: function(t) {
      return t && t.children ? wf(t.children).find(function(r) {
        return Hl(r, "data-pc-name") === "ripple";
      }) : void 0;
    }
  }
});
function dr(e) {
  "@babel/helpers - typeof";
  return dr = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(t) {
    return typeof t;
  } : function(t) {
    return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t;
  }, dr(e);
}
function Ke(e, t, r) {
  return (t = jf(t)) in e ? Object.defineProperty(e, t, { value: r, enumerable: !0, configurable: !0, writable: !0 }) : e[t] = r, e;
}
function jf(e) {
  var t = If(e, "string");
  return dr(t) == "symbol" ? t : t + "";
}
function If(e, t) {
  if (dr(e) != "object" || !e) return e;
  var r = e[Symbol.toPrimitive];
  if (r !== void 0) {
    var n = r.call(e, t);
    if (dr(n) != "object") return n;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (t === "string" ? String : Number)(e);
}
var Af = function(t) {
  var r = t.dt;
  return `
.p-button {
    display: inline-flex;
    cursor: pointer;
    user-select: none;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
    color: `.concat(r("button.primary.color"), `;
    background: `).concat(r("button.primary.background"), `;
    border: 1px solid `).concat(r("button.primary.border.color"), `;
    padding: `).concat(r("button.padding.y"), " ").concat(r("button.padding.x"), `;
    font-size: 1rem;
    font-family: inherit;
    font-feature-settings: inherit;
    transition: background `).concat(r("button.transition.duration"), ", color ").concat(r("button.transition.duration"), ", border-color ").concat(r("button.transition.duration"), `,
            outline-color `).concat(r("button.transition.duration"), ", box-shadow ").concat(r("button.transition.duration"), `;
    border-radius: `).concat(r("button.border.radius"), `;
    outline-color: transparent;
    gap: `).concat(r("button.gap"), `;
}

.p-button:disabled {
    cursor: default;
}

.p-button-icon-right {
    order: 1;
}

.p-button-icon-bottom {
    order: 2;
}

.p-button-icon-only {
    width: `).concat(r("button.icon.only.width"), `;
    padding-left: 0;
    padding-right: 0;
    gap: 0;
}

.p-button-icon-only.p-button-rounded {
    border-radius: 50%;
    height: `).concat(r("button.icon.only.width"), `;
}

.p-button-icon-only .p-button-label {
    visibility: hidden;
    width: 0;
}

.p-button-sm {
    font-size: `).concat(r("button.sm.font.size"), `;
    padding: `).concat(r("button.sm.padding.y"), " ").concat(r("button.sm.padding.x"), `;
}

.p-button-sm .p-button-icon {
    font-size: `).concat(r("button.sm.font.size"), `;
}

.p-button-lg {
    font-size: `).concat(r("button.lg.font.size"), `;
    padding: `).concat(r("button.lg.padding.y"), " ").concat(r("button.lg.padding.x"), `;
}

.p-button-lg .p-button-icon {
    font-size: `).concat(r("button.lg.font.size"), `;
}

.p-button-vertical {
    flex-direction: column;
}

.p-button-label {
    font-weight: `).concat(r("button.label.font.weight"), `;
}

.p-button-fluid {
    width: 100%;
}

.p-button-fluid.p-button-icon-only {
    width: `).concat(r("button.icon.only.width"), `;
}

.p-button:not(:disabled):hover {
    background: `).concat(r("button.primary.hover.background"), `;
    border: 1px solid `).concat(r("button.primary.hover.border.color"), `;
    color: `).concat(r("button.primary.hover.color"), `;
}

.p-button:not(:disabled):active {
    background: `).concat(r("button.primary.active.background"), `;
    border: 1px solid `).concat(r("button.primary.active.border.color"), `;
    color: `).concat(r("button.primary.active.color"), `;
}

.p-button:focus-visible {
    box-shadow: `).concat(r("button.primary.focus.ring.shadow"), `;
    outline: `).concat(r("button.focus.ring.width"), " ").concat(r("button.focus.ring.style"), " ").concat(r("button.primary.focus.ring.color"), `;
    outline-offset: `).concat(r("button.focus.ring.offset"), `;
}

.p-button .p-badge {
    min-width: `).concat(r("button.badge.size"), `;
    height: `).concat(r("button.badge.size"), `;
    line-height: `).concat(r("button.badge.size"), `;
}

.p-button-raised {
    box-shadow: `).concat(r("button.raised.shadow"), `;
}

.p-button-rounded {
    border-radius: `).concat(r("button.rounded.border.radius"), `;
}

.p-button-secondary {
    background: `).concat(r("button.secondary.background"), `;
    border: 1px solid `).concat(r("button.secondary.border.color"), `;
    color: `).concat(r("button.secondary.color"), `;
}

.p-button-secondary:not(:disabled):hover {
    background: `).concat(r("button.secondary.hover.background"), `;
    border: 1px solid `).concat(r("button.secondary.hover.border.color"), `;
    color: `).concat(r("button.secondary.hover.color"), `;
}

.p-button-secondary:not(:disabled):active {
    background: `).concat(r("button.secondary.active.background"), `;
    border: 1px solid `).concat(r("button.secondary.active.border.color"), `;
    color: `).concat(r("button.secondary.active.color"), `;
}

.p-button-secondary:focus-visible {
    outline-color: `).concat(r("button.secondary.focus.ring.color"), `;
    box-shadow: `).concat(r("button.secondary.focus.ring.shadow"), `;
}

.p-button-success {
    background: `).concat(r("button.success.background"), `;
    border: 1px solid `).concat(r("button.success.border.color"), `;
    color: `).concat(r("button.success.color"), `;
}

.p-button-success:not(:disabled):hover {
    background: `).concat(r("button.success.hover.background"), `;
    border: 1px solid `).concat(r("button.success.hover.border.color"), `;
    color: `).concat(r("button.success.hover.color"), `;
}

.p-button-success:not(:disabled):active {
    background: `).concat(r("button.success.active.background"), `;
    border: 1px solid `).concat(r("button.success.active.border.color"), `;
    color: `).concat(r("button.success.active.color"), `;
}

.p-button-success:focus-visible {
    outline-color: `).concat(r("button.success.focus.ring.color"), `;
    box-shadow: `).concat(r("button.success.focus.ring.shadow"), `;
}

.p-button-info {
    background: `).concat(r("button.info.background"), `;
    border: 1px solid `).concat(r("button.info.border.color"), `;
    color: `).concat(r("button.info.color"), `;
}

.p-button-info:not(:disabled):hover {
    background: `).concat(r("button.info.hover.background"), `;
    border: 1px solid `).concat(r("button.info.hover.border.color"), `;
    color: `).concat(r("button.info.hover.color"), `;
}

.p-button-info:not(:disabled):active {
    background: `).concat(r("button.info.active.background"), `;
    border: 1px solid `).concat(r("button.info.active.border.color"), `;
    color: `).concat(r("button.info.active.color"), `;
}

.p-button-info:focus-visible {
    outline-color: `).concat(r("button.info.focus.ring.color"), `;
    box-shadow: `).concat(r("button.info.focus.ring.shadow"), `;
}

.p-button-warn {
    background: `).concat(r("button.warn.background"), `;
    border: 1px solid `).concat(r("button.warn.border.color"), `;
    color: `).concat(r("button.warn.color"), `;
}

.p-button-warn:not(:disabled):hover {
    background: `).concat(r("button.warn.hover.background"), `;
    border: 1px solid `).concat(r("button.warn.hover.border.color"), `;
    color: `).concat(r("button.warn.hover.color"), `;
}

.p-button-warn:not(:disabled):active {
    background: `).concat(r("button.warn.active.background"), `;
    border: 1px solid `).concat(r("button.warn.active.border.color"), `;
    color: `).concat(r("button.warn.active.color"), `;
}

.p-button-warn:focus-visible {
    outline-color: `).concat(r("button.warn.focus.ring.color"), `;
    box-shadow: `).concat(r("button.warn.focus.ring.shadow"), `;
}

.p-button-help {
    background: `).concat(r("button.help.background"), `;
    border: 1px solid `).concat(r("button.help.border.color"), `;
    color: `).concat(r("button.help.color"), `;
}

.p-button-help:not(:disabled):hover {
    background: `).concat(r("button.help.hover.background"), `;
    border: 1px solid `).concat(r("button.help.hover.border.color"), `;
    color: `).concat(r("button.help.hover.color"), `;
}

.p-button-help:not(:disabled):active {
    background: `).concat(r("button.help.active.background"), `;
    border: 1px solid `).concat(r("button.help.active.border.color"), `;
    color: `).concat(r("button.help.active.color"), `;
}

.p-button-help:focus-visible {
    outline-color: `).concat(r("button.help.focus.ring.color"), `;
    box-shadow: `).concat(r("button.help.focus.ring.shadow"), `;
}

.p-button-danger {
    background: `).concat(r("button.danger.background"), `;
    border: 1px solid `).concat(r("button.danger.border.color"), `;
    color: `).concat(r("button.danger.color"), `;
}

.p-button-danger:not(:disabled):hover {
    background: `).concat(r("button.danger.hover.background"), `;
    border: 1px solid `).concat(r("button.danger.hover.border.color"), `;
    color: `).concat(r("button.danger.hover.color"), `;
}

.p-button-danger:not(:disabled):active {
    background: `).concat(r("button.danger.active.background"), `;
    border: 1px solid `).concat(r("button.danger.active.border.color"), `;
    color: `).concat(r("button.danger.active.color"), `;
}

.p-button-danger:focus-visible {
    outline-color: `).concat(r("button.danger.focus.ring.color"), `;
    box-shadow: `).concat(r("button.danger.focus.ring.shadow"), `;
}

.p-button-contrast {
    background: `).concat(r("button.contrast.background"), `;
    border: 1px solid `).concat(r("button.contrast.border.color"), `;
    color: `).concat(r("button.contrast.color"), `;
}

.p-button-contrast:not(:disabled):hover {
    background: `).concat(r("button.contrast.hover.background"), `;
    border: 1px solid `).concat(r("button.contrast.hover.border.color"), `;
    color: `).concat(r("button.contrast.hover.color"), `;
}

.p-button-contrast:not(:disabled):active {
    background: `).concat(r("button.contrast.active.background"), `;
    border: 1px solid `).concat(r("button.contrast.active.border.color"), `;
    color: `).concat(r("button.contrast.active.color"), `;
}

.p-button-contrast:focus-visible {
    outline-color: `).concat(r("button.contrast.focus.ring.color"), `;
    box-shadow: `).concat(r("button.contrast.focus.ring.shadow"), `;
}

.p-button-outlined {
    background: transparent;
    border-color: `).concat(r("button.outlined.primary.border.color"), `;
    color: `).concat(r("button.outlined.primary.color"), `;
}

.p-button-outlined:not(:disabled):hover {
    background: `).concat(r("button.outlined.primary.hover.background"), `;
    border-color: `).concat(r("button.outlined.primary.border.color"), `;
    color: `).concat(r("button.outlined.primary.color"), `;
}

.p-button-outlined:not(:disabled):active {
    background: `).concat(r("button.outlined.primary.active.background"), `;
    border-color: `).concat(r("button.outlined.primary.border.color"), `;
    color: `).concat(r("button.outlined.primary.color"), `;
}

.p-button-outlined.p-button-secondary {
    border-color: `).concat(r("button.outlined.secondary.border.color"), `;
    color: `).concat(r("button.outlined.secondary.color"), `;
}

.p-button-outlined.p-button-secondary:not(:disabled):hover {
    background: `).concat(r("button.outlined.secondary.hover.background"), `;
    border-color: `).concat(r("button.outlined.secondary.border.color"), `;
    color: `).concat(r("button.outlined.secondary.color"), `;
}

.p-button-outlined.p-button-secondary:not(:disabled):active {
    background: `).concat(r("button.outlined.secondary.active.background"), `;
    border-color: `).concat(r("button.outlined.secondary.border.color"), `;
    color: `).concat(r("button.outlined.secondary.color"), `;
}

.p-button-outlined.p-button-success {
    border-color: `).concat(r("button.outlined.success.border.color"), `;
    color: `).concat(r("button.outlined.success.color"), `;
}

.p-button-outlined.p-button-success:not(:disabled):hover {
    background: `).concat(r("button.outlined.success.hover.background"), `;
    border-color: `).concat(r("button.outlined.success.border.color"), `;
    color: `).concat(r("button.outlined.success.color"), `;
}

.p-button-outlined.p-button-success:not(:disabled):active {
    background: `).concat(r("button.outlined.success.active.background"), `;
    border-color: `).concat(r("button.outlined.success.border.color"), `;
    color: `).concat(r("button.outlined.success.color"), `;
}

.p-button-outlined.p-button-info {
    border-color: `).concat(r("button.outlined.info.border.color"), `;
    color: `).concat(r("button.outlined.info.color"), `;
}

.p-button-outlined.p-button-info:not(:disabled):hover {
    background: `).concat(r("button.outlined.info.hover.background"), `;
    border-color: `).concat(r("button.outlined.info.border.color"), `;
    color: `).concat(r("button.outlined.info.color"), `;
}

.p-button-outlined.p-button-info:not(:disabled):active {
    background: `).concat(r("button.outlined.info.active.background"), `;
    border-color: `).concat(r("button.outlined.info.border.color"), `;
    color: `).concat(r("button.outlined.info.color"), `;
}

.p-button-outlined.p-button-warn {
    border-color: `).concat(r("button.outlined.warn.border.color"), `;
    color: `).concat(r("button.outlined.warn.color"), `;
}

.p-button-outlined.p-button-warn:not(:disabled):hover {
    background: `).concat(r("button.outlined.warn.hover.background"), `;
    border-color: `).concat(r("button.outlined.warn.border.color"), `;
    color: `).concat(r("button.outlined.warn.color"), `;
}

.p-button-outlined.p-button-warn:not(:disabled):active {
    background: `).concat(r("button.outlined.warn.active.background"), `;
    border-color: `).concat(r("button.outlined.warn.border.color"), `;
    color: `).concat(r("button.outlined.warn.color"), `;
}

.p-button-outlined.p-button-help {
    border-color: `).concat(r("button.outlined.help.border.color"), `;
    color: `).concat(r("button.outlined.help.color"), `;
}

.p-button-outlined.p-button-help:not(:disabled):hover {
    background: `).concat(r("button.outlined.help.hover.background"), `;
    border-color: `).concat(r("button.outlined.help.border.color"), `;
    color: `).concat(r("button.outlined.help.color"), `;
}

.p-button-outlined.p-button-help:not(:disabled):active {
    background: `).concat(r("button.outlined.help.active.background"), `;
    border-color: `).concat(r("button.outlined.help.border.color"), `;
    color: `).concat(r("button.outlined.help.color"), `;
}

.p-button-outlined.p-button-danger {
    border-color: `).concat(r("button.outlined.danger.border.color"), `;
    color: `).concat(r("button.outlined.danger.color"), `;
}

.p-button-outlined.p-button-danger:not(:disabled):hover {
    background: `).concat(r("button.outlined.danger.hover.background"), `;
    border-color: `).concat(r("button.outlined.danger.border.color"), `;
    color: `).concat(r("button.outlined.danger.color"), `;
}

.p-button-outlined.p-button-danger:not(:disabled):active {
    background: `).concat(r("button.outlined.danger.active.background"), `;
    border-color: `).concat(r("button.outlined.danger.border.color"), `;
    color: `).concat(r("button.outlined.danger.color"), `;
}

.p-button-outlined.p-button-contrast {
    border-color: `).concat(r("button.outlined.contrast.border.color"), `;
    color: `).concat(r("button.outlined.contrast.color"), `;
}

.p-button-outlined.p-button-contrast:not(:disabled):hover {
    background: `).concat(r("button.outlined.contrast.hover.background"), `;
    border-color: `).concat(r("button.outlined.contrast.border.color"), `;
    color: `).concat(r("button.outlined.contrast.color"), `;
}

.p-button-outlined.p-button-contrast:not(:disabled):active {
    background: `).concat(r("button.outlined.contrast.active.background"), `;
    border-color: `).concat(r("button.outlined.contrast.border.color"), `;
    color: `).concat(r("button.outlined.contrast.color"), `;
}

.p-button-outlined.p-button-plain {
    border-color: `).concat(r("button.outlined.plain.border.color"), `;
    color: `).concat(r("button.outlined.plain.color"), `;
}

.p-button-outlined.p-button-plain:not(:disabled):hover {
    background: `).concat(r("button.outlined.plain.hover.background"), `;
    border-color: `).concat(r("button.outlined.plain.border.color"), `;
    color: `).concat(r("button.outlined.plain.color"), `;
}

.p-button-outlined.p-button-plain:not(:disabled):active {
    background: `).concat(r("button.outlined.plain.active.background"), `;
    border-color: `).concat(r("button.outlined.plain.border.color"), `;
    color: `).concat(r("button.outlined.plain.color"), `;
}

.p-button-text {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.primary.color"), `;
}

.p-button-text:not(:disabled):hover {
    background: `).concat(r("button.text.primary.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.primary.color"), `;
}

.p-button-text:not(:disabled):active {
    background: `).concat(r("button.text.primary.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.primary.color"), `;
}

.p-button-text.p-button-secondary {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.secondary.color"), `;
}

.p-button-text.p-button-secondary:not(:disabled):hover {
    background: `).concat(r("button.text.secondary.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.secondary.color"), `;
}

.p-button-text.p-button-secondary:not(:disabled):active {
    background: `).concat(r("button.text.secondary.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.secondary.color"), `;
}

.p-button-text.p-button-success {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.success.color"), `;
}

.p-button-text.p-button-success:not(:disabled):hover {
    background: `).concat(r("button.text.success.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.success.color"), `;
}

.p-button-text.p-button-success:not(:disabled):active {
    background: `).concat(r("button.text.success.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.success.color"), `;
}

.p-button-text.p-button-info {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.info.color"), `;
}

.p-button-text.p-button-info:not(:disabled):hover {
    background: `).concat(r("button.text.info.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.info.color"), `;
}

.p-button-text.p-button-info:not(:disabled):active {
    background: `).concat(r("button.text.info.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.info.color"), `;
}

.p-button-text.p-button-warn {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.warn.color"), `;
}

.p-button-text.p-button-warn:not(:disabled):hover {
    background: `).concat(r("button.text.warn.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.warn.color"), `;
}

.p-button-text.p-button-warn:not(:disabled):active {
    background: `).concat(r("button.text.warn.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.warn.color"), `;
}

.p-button-text.p-button-help {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.help.color"), `;
}

.p-button-text.p-button-help:not(:disabled):hover {
    background: `).concat(r("button.text.help.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.help.color"), `;
}

.p-button-text.p-button-help:not(:disabled):active {
    background: `).concat(r("button.text.help.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.help.color"), `;
}

.p-button-text.p-button-danger {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.danger.color"), `;
}

.p-button-text.p-button-danger:not(:disabled):hover {
    background: `).concat(r("button.text.danger.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.danger.color"), `;
}

.p-button-text.p-button-danger:not(:disabled):active {
    background: `).concat(r("button.text.danger.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.danger.color"), `;
}

.p-button-text.p-button-plain {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.text.plain.color"), `;
}

.p-button-text.p-button-plain:not(:disabled):hover {
    background: `).concat(r("button.text.plain.hover.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.plain.color"), `;
}

.p-button-text.p-button-plain:not(:disabled):active {
    background: `).concat(r("button.text.plain.active.background"), `;
    border-color: transparent;
    color: `).concat(r("button.text.plain.color"), `;
}

.p-button-link {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.link.color"), `;
}

.p-button-link:not(:disabled):hover {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.link.hover.color"), `;
}

.p-button-link:not(:disabled):hover .p-button-label {
    text-decoration: underline;
}

.p-button-link:not(:disabled):active {
    background: transparent;
    border-color: transparent;
    color: `).concat(r("button.link.active.color"), `;
}
`);
}, zf = {
  root: function(t) {
    var r = t.instance, n = t.props;
    return ["p-button p-component", Ke(Ke(Ke(Ke(Ke(Ke(Ke(Ke(Ke({
      "p-button-icon-only": r.hasIcon && !n.label && !n.badge,
      "p-button-vertical": (n.iconPos === "top" || n.iconPos === "bottom") && n.label,
      "p-button-loading": n.loading,
      "p-button-link": n.link
    }, "p-button-".concat(n.severity), n.severity), "p-button-raised", n.raised), "p-button-rounded", n.rounded), "p-button-text", n.text), "p-button-outlined", n.outlined), "p-button-sm", n.size === "small"), "p-button-lg", n.size === "large"), "p-button-plain", n.plain), "p-button-fluid", r.hasFluid)];
  },
  loadingIcon: "p-button-loading-icon",
  icon: function(t) {
    var r = t.props;
    return ["p-button-icon", Ke({}, "p-button-icon-".concat(r.iconPos), r.label)];
  },
  label: "p-button-label"
}, Lf = Q.extend({
  name: "button",
  theme: Af,
  classes: zf
}), Ef = {
  name: "BaseButton",
  extends: Jr,
  props: {
    label: {
      type: String,
      default: null
    },
    icon: {
      type: String,
      default: null
    },
    iconPos: {
      type: String,
      default: "left"
    },
    iconClass: {
      type: [String, Object],
      default: null
    },
    badge: {
      type: String,
      default: null
    },
    badgeClass: {
      type: [String, Object],
      default: null
    },
    badgeSeverity: {
      type: String,
      default: "secondary"
    },
    loading: {
      type: Boolean,
      default: !1
    },
    loadingIcon: {
      type: String,
      default: void 0
    },
    as: {
      type: [String, Object],
      default: "BUTTON"
    },
    asChild: {
      type: Boolean,
      default: !1
    },
    link: {
      type: Boolean,
      default: !1
    },
    severity: {
      type: String,
      default: null
    },
    raised: {
      type: Boolean,
      default: !1
    },
    rounded: {
      type: Boolean,
      default: !1
    },
    text: {
      type: Boolean,
      default: !1
    },
    outlined: {
      type: Boolean,
      default: !1
    },
    size: {
      type: String,
      default: null
    },
    plain: {
      type: Boolean,
      default: !1
    },
    fluid: {
      type: Boolean,
      default: null
    }
  },
  style: Lf,
  provide: function() {
    return {
      $pcButton: this,
      $parentInstance: this
    };
  }
}, Is = {
  name: "Button",
  extends: Ef,
  inheritAttrs: !1,
  inject: {
    $pcFluid: {
      default: null
    }
  },
  methods: {
    getPTOptions: function(t) {
      var r = t === "root" ? this.ptmi : this.ptm;
      return r(t, {
        context: {
          disabled: this.disabled
        }
      });
    }
  },
  computed: {
    disabled: function() {
      return this.$attrs.disabled || this.$attrs.disabled === "" || this.loading;
    },
    defaultAriaLabel: function() {
      return this.label ? this.label + (this.badge ? " " + this.badge : "") : this.$attrs.ariaLabel;
    },
    hasIcon: function() {
      return this.icon || this.$slots.icon;
    },
    attrs: function() {
      return ve(this.asAttrs, this.a11yAttrs, this.getPTOptions("root"));
    },
    asAttrs: function() {
      return this.as === "BUTTON" ? {
        type: "button",
        disabled: this.disabled
      } : void 0;
    },
    a11yAttrs: function() {
      return {
        "aria-label": this.defaultAriaLabel,
        "data-pc-name": "button",
        "data-p-disabled": this.disabled,
        "data-p-severity": this.severity
      };
    },
    hasFluid: function() {
      return bt(this.fluid) ? !!this.$pcFluid : this.fluid;
    }
  },
  components: {
    SpinnerIcon: Os,
    Badge: js
  },
  directives: {
    ripple: Of
  }
};
function Nf(e, t, r, n, o, a) {
  var s = ko("SpinnerIcon"), i = ko("Badge"), l = tu("ripple");
  return e.asChild ? Dt(e.$slots, "default", {
    key: 1,
    class: wt(e.cx("root")),
    a11yAttrs: a.a11yAttrs
  }) : qa((Ve(), Xt(eu(e.as), ve({
    key: 0,
    class: e.cx("root")
  }, a.attrs), {
    default: Ga(function() {
      return [Dt(e.$slots, "default", {}, function() {
        return [e.loading ? Dt(e.$slots, "loadingicon", {
          key: 0,
          class: wt([e.cx("loadingIcon"), e.cx("icon")])
        }, function() {
          return [e.loadingIcon ? (Ve(), Rt("span", ve({
            key: 0,
            class: [e.cx("loadingIcon"), e.cx("icon"), e.loadingIcon]
          }, e.ptm("loadingIcon")), null, 16)) : (Ve(), Xt(s, ve({
            key: 1,
            class: [e.cx("loadingIcon"), e.cx("icon")],
            spin: ""
          }, e.ptm("loadingIcon")), null, 16, ["class"]))];
        }) : Dt(e.$slots, "icon", {
          key: 1,
          class: wt([e.cx("icon")])
        }, function() {
          return [e.icon ? (Ve(), Rt("span", ve({
            key: 0,
            class: [e.cx("icon"), e.icon, e.iconClass]
          }, e.ptm("icon")), null, 16)) : Ao("", !0)];
        }), pe("span", ve({
          class: e.cx("label")
        }, e.ptm("label")), In(e.label || " "), 17), e.badge ? (Ve(), Xt(i, {
          key: 2,
          value: e.badge,
          class: wt(e.badgeClass),
          severity: e.badgeSeverity,
          unstyled: e.unstyled,
          pt: e.ptm("pcBadge")
        }, null, 8, ["value", "class", "severity", "unstyled", "pt"])) : Ao("", !0)];
      })];
    }),
    _: 3
  }, 16, ["class"])), [[l]]);
}
Is.render = Nf;
var Rf = function(t) {
  var r = t.dt;
  return `
.p-inputtext {
    font-family: inherit;
    font-feature-settings: inherit;
    font-size: 1rem;
    color: `.concat(r("inputtext.color"), `;
    background: `).concat(r("inputtext.background"), `;
    padding: `).concat(r("inputtext.padding.y"), " ").concat(r("inputtext.padding.x"), `;
    border: 1px solid `).concat(r("inputtext.border.color"), `;
    transition: background `).concat(r("inputtext.transition.duration"), ", color ").concat(r("inputtext.transition.duration"), ", border-color ").concat(r("inputtext.transition.duration"), ", outline-color ").concat(r("inputtext.transition.duration"), ", box-shadow ").concat(r("inputtext.transition.duration"), `;
    appearance: none;
    border-radius: `).concat(r("inputtext.border.radius"), `;
    outline-color: transparent;
    box-shadow: `).concat(r("inputtext.shadow"), `;
}

.p-inputtext:enabled:hover {
    border-color: `).concat(r("inputtext.hover.border.color"), `;
}

.p-inputtext:enabled:focus {
    border-color: `).concat(r("inputtext.focus.border.color"), `;
    box-shadow: `).concat(r("inputtext.focus.ring.shadow"), `;
    outline: `).concat(r("inputtext.focus.ring.width"), " ").concat(r("inputtext.focus.ring.style"), " ").concat(r("inputtext.focus.ring.color"), `;
    outline-offset: `).concat(r("inputtext.focus.ring.offset"), `;
}

.p-inputtext.p-invalid {
    border-color: `).concat(r("inputtext.invalid.border.color"), `;
}

.p-inputtext.p-variant-filled {
    background: `).concat(r("inputtext.filled.background"), `;
}

.p-inputtext.p-variant-filled:enabled:hover {
    border-color: `).concat(r("inputtext.filled.hover.background"), `;
}

.p-inputtext.p-variant-filled:enabled:focus {
    background: `).concat(r("inputtext.filled.focus.background"), `;
}

.p-inputtext:disabled {
    opacity: 1;
    background: `).concat(r("inputtext.disabled.background"), `;
    color: `).concat(r("inputtext.disabled.color"), `;
}

.p-inputtext::placeholder {
    color: `).concat(r("inputtext.placeholder.color"), `;
}

.p-inputtext-sm {
    font-size: `).concat(r("inputtext.sm.font.size"), `;
    padding: `).concat(r("inputtext.sm.padding.y"), " ").concat(r("inputtext.sm.padding.x"), `;
}

.p-inputtext-lg {
    font-size: `).concat(r("inputtext.lg.font.size"), `;
    padding: `).concat(r("inputtext.lg.padding.y"), " ").concat(r("inputtext.lg.padding.x"), `;
}

.p-inputtext-fluid {
    width: 100%;
}
`);
}, Ff = {
  root: function(t) {
    var r = t.instance, n = t.props;
    return ["p-inputtext p-component", {
      "p-filled": r.filled,
      "p-inputtext-sm": n.size === "small",
      "p-inputtext-lg": n.size === "large",
      "p-invalid": n.invalid,
      "p-variant-filled": n.variant ? n.variant === "filled" : r.$primevue.config.inputStyle === "filled" || r.$primevue.config.inputVariant === "filled",
      "p-inputtext-fluid": r.hasFluid
    }];
  }
}, Vf = Q.extend({
  name: "inputtext",
  theme: Rf,
  classes: Ff
}), Mf = {
  name: "BaseInputText",
  extends: Jr,
  props: {
    modelValue: null,
    size: {
      type: String,
      default: null
    },
    invalid: {
      type: Boolean,
      default: !1
    },
    variant: {
      type: String,
      default: null
    },
    fluid: {
      type: Boolean,
      default: null
    }
  },
  style: Vf,
  provide: function() {
    return {
      $pcInputText: this,
      $parentInstance: this
    };
  }
}, _n = {
  name: "InputText",
  extends: Mf,
  inheritAttrs: !1,
  emits: ["update:modelValue"],
  inject: {
    $pcFluid: {
      default: null
    }
  },
  methods: {
    getPTOptions: function(t) {
      var r = t === "root" ? this.ptmi : this.ptm;
      return r(t, {
        context: {
          filled: this.filled,
          disabled: this.$attrs.disabled || this.$attrs.disabled === ""
        }
      });
    },
    onInput: function(t) {
      this.$emit("update:modelValue", t.target.value);
    }
  },
  computed: {
    filled: function() {
      return this.modelValue != null && this.modelValue.toString().length > 0;
    },
    hasFluid: function() {
      return bt(this.fluid) ? !!this.$pcFluid : this.fluid;
    }
  }
}, Bf = ["value", "aria-invalid"];
function Df(e, t, r, n, o, a) {
  return Ve(), Rt("input", ve({
    type: "text",
    class: e.cx("root"),
    value: e.modelValue,
    "aria-invalid": e.invalid || void 0,
    onInput: t[0] || (t[0] = function() {
      return a.onInput && a.onInput.apply(a, arguments);
    })
  }, a.getPTOptions("root")), null, 16, Bf);
}
_n.render = Df;
const As = Symbol("FrontendSDK"), Hf = (e, t) => {
  e.provide(As, t);
}, Uf = () => Qt(As), Kf = { class: "flex flex-col p-4 gap-4 max-w-sm" }, Wf = /* @__PURE__ */ pe(
  "div",
  null,
  [
    /* @__PURE__ */ pe("h1", { class: "text-xl font-bold" }, "JXScout Settings"),
    /* @__PURE__ */ pe("p", { class: "text-sm text-gray-600" }, "Configure ingestion from Caido to JXScout.")
  ],
  -1
  /* HOISTED */
), Gf = { class: "flex flex-col gap-4" }, qf = { class: "flex justify-between items-center" }, Yf = /* @__PURE__ */ pe(
  "label",
  { for: "host" },
  "Host:",
  -1
  /* HOISTED */
), Jf = { class: "flex justify-between items-center" }, Qf = /* @__PURE__ */ pe(
  "label",
  { for: "port" },
  "Port:",
  -1
  /* HOISTED */
), Zf = { class: "flex items-center justify-between" }, Xf = /* @__PURE__ */ pe(
  "label",
  { for: "filter" },
  "Filter in scope:",
  -1
  /* HOISTED */
), e0 = ["disabled"], t0 = /* @__PURE__ */ Bc({
  __name: "App",
  setup(e) {
    const t = Uf(), r = lt(""), n = lt(""), o = lt(!1), a = lt(!1), s = async () => {
      a.value = !0;
      try {
        const l = await t.backend.getSettings();
        if (!l.success) {
          t.window.showToast(`Failed to load settings: ${l.error}`, { variant: "error" });
          return;
        }
        const c = l.data;
        r.value = c.host, n.value = c.port, o.value = c.filterInScope;
      } catch (l) {
        t.window.showToast(`Failed to load settings: ${l}`, { variant: "error" });
      } finally {
        a.value = !1;
      }
    }, i = async () => {
      a.value = !0;
      try {
        await t.backend.saveSettings({
          host: r.value,
          port: parseInt(n.value),
          filterInScope: o.value
        }), alert("Settings saved successfully!");
      } catch (l) {
        console.error("Failed to save settings:", l);
      } finally {
        a.value = !1;
      }
    };
    return Dn(() => {
      s();
    }), (l, c) => (Ve(), Rt("div", Kf, [
      Wf,
      pe("div", Gf, [
        pe("div", qf, [
          Yf,
          Ce(Tr(_n), {
            id: "host",
            modelValue: r.value,
            "onUpdate:modelValue": c[0] || (c[0] = (u) => r.value = u),
            placeholder: "Host",
            disabled: a.value
          }, null, 8, ["modelValue", "disabled"])
        ]),
        pe("div", Jf, [
          Qf,
          Ce(Tr(_n), {
            id: "port",
            modelValue: n.value,
            "onUpdate:modelValue": c[1] || (c[1] = (u) => n.value = u),
            placeholder: "Port",
            disabled: a.value
          }, null, 8, ["modelValue", "disabled"])
        ]),
        pe("div", Zf, [
          Xf,
          qa(pe("input", {
            id: "filter",
            type: "checkbox",
            "onUpdate:modelValue": c[2] || (c[2] = (u) => o.value = u),
            disabled: a.value
          }, null, 8, e0), [
            [gd, o.value]
          ])
        ]),
        Ce(Tr(Is), {
          label: "Save Settings",
          onClick: i,
          disabled: a.value
        }, null, 8, ["disabled"])
      ])
    ]));
  }
}), r0 = (e) => {
  const t = xd(t0);
  t.use(Gd, {
    unstyled: !0,
    pt: wl
  }), t.use(Hf, e);
  const r = document.createElement("div");
  Object.assign(r.style, {
    height: "100%",
    width: "100%"
  }), r.id = "plugin--frontend-vue", t.mount(r), e.navigation.addPage("/jxscout", {
    body: r
  }), e.sidebar.registerItem("JXScout", "/jxscout");
};
export {
  r0 as init
};
