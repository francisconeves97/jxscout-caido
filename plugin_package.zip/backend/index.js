// packages/backend/src/index.ts
import { RequestSpec } from "caido:utils";
import * as path from "path";
import { writeFile, readFile } from "fs/promises";
var DEFAULT_SETTINGS = {
  port: 3333,
  host: "localhost",
  filterInScope: true
};
var globalSettings = null;
function ok(data) {
  return {
    success: true,
    data
  };
}
function error(message) {
  return {
    success: false,
    error: message
  };
}
var getSettingsFilePath = (sdk) => {
  return path.join(sdk.meta.path(), "settings.json");
};
var saveSettings = async (sdk, settings) => {
  const settingsFilePath = getSettingsFilePath(sdk);
  try {
    await writeFile(settingsFilePath, JSON.stringify(settings, null, 2));
    sdk.console.log(`Settings saved to ${settingsFilePath}`);
    globalSettings = settings;
    return ok(settings);
  } catch (err) {
    sdk.console.error(`Failed to save settings: ${err}`);
    return error(`Failed to save settings: ${err}`);
  }
};
var getSettings = async (sdk) => {
  const settingsFilePath = getSettingsFilePath(sdk);
  sdk.console.log(`Loading settings from ${settingsFilePath}`);
  try {
    const settings = await readFile(settingsFilePath, "utf-8");
    return ok(JSON.parse(settings));
  } catch (err) {
    sdk.console.error(`Failed to read settings: ${err}`);
    return ok(DEFAULT_SETTINGS);
  }
};
function init(sdk) {
  sdk.api.register("saveSettings", saveSettings);
  sdk.api.register("getSettings", getSettings);
  sdk.events.onInterceptResponse(async (sdk2, request, response) => {
    if (!globalSettings) {
      const settingsResponse = await getSettings(sdk2);
      if (settingsResponse.success) {
        globalSettings = settingsResponse.data;
      } else {
        sdk2.console.error(
          `jxscout-caido: failed to load settings ${settingsResponse.error}`
        );
        globalSettings = DEFAULT_SETTINGS;
      }
    }
    sdk2.console.log(`jxscout-caido: intercepting request ${request.getUrl()}`);
    const settings = globalSettings;
    if (settings.filterInScope && !sdk2.requests.inScope(request)) {
      sdk2.console.log(
        `jxscout-caido: request ${request.getUrl()} is out of scope`
      );
      return;
    }
    const requestSpec = new RequestSpec("http://" + settings.host);
    requestSpec.setPath("/caido-ingest");
    requestSpec.setPort(settings.port);
    requestSpec.setMethod("POST");
    requestSpec.setHeader("content-type", "application/json");
    requestSpec.setBody(
      JSON.stringify({
        requestUrl: request.getUrl(),
        request: request.getRaw().toText(),
        response: response.getRaw().toText()
      })
    );
    try {
      sdk2.console.log(
        `jxscout-caido: sending request ${request.getUrl()} to ${settings.host}:${settings.port}`
      );
      await sdk2.requests.send(requestSpec);
      sdk2.console.log(
        `jxscout-caido: request ${request.getUrl()} sent to ${settings.host}:${settings.port}`
      );
    } catch (err) {
      sdk2.console.error(`jxscout-caido: failed to send request ${err}`);
    }
  });
}
export {
  init
};
